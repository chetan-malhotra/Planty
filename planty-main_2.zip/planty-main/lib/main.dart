import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:planty_homes/controllers/user_controller.dart';
import 'package:planty_homes/modules/home/bindings/home_binding.dart';
import 'data/constants/export.dart';
import 'modules/login/bindings/login_binding.dart';
import 'routes/app_pages.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // SystemChrome.setSystemUIOverlayStyle(
  //   SystemUiOverlayStyle.light,
  // );
  // SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
  //   statusBarColor: Colors.transparent,
  // ));
  //
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp, // Locks the orientation to portrait
  ]);


  await Firebase.initializeApp();
  Get.put(UserController(), permanent: true);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus &&
            currentFocus.focusedChild != null) {
          FocusManager.instance.primaryFocus!.unfocus();
        }
      },
      child: ScreenUtilInit(
        builder: (context, widget) => GetMaterialApp(
          theme: themeData,
          initialBinding: FirebaseAuth.instance.currentUser == null
              ? LoginBinding()
              : HomeBinding(),
          initialRoute: FirebaseAuth.instance.currentUser == null
              ? Routes.LOGIN
              : Routes.HOME,
          getPages: AppPages.routes,
          debugShowCheckedModeBanner: false,
          enableLog: true,
          defaultTransition: Transition.cupertino,
        ),
      ),
    );
  }
}

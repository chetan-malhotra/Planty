import 'package:planty_homes/data/constants/export.dart';
import 'package:planty_homes/data/utils/server_utils.dart';

import '../models/user_model.dart';
import '../utils/logger.dart';

class AuthSignService extends ServerNoAuth {
  Future<Result> updateProfile() async {
    try {
      return Result.fail("Not implemented yet");
    } catch (error) {
      return Result.fail("Unkonwn error", error);
    }
  }

  Future<Result> requestOtp(String number, [bool isSignup = true]) async {
    final res = await handlePostRequest(
      isSignup ? ServerRoute.signup : ServerRoute.signin,
      {"number": number},
    );

    if (res.isPass) {
      if (res.data["status"] == 400) {
        return Result.fail("User not found. You need to create an account");
      }

      if (res.data?["status"] == 200) {
        return Result.pass("Otp Sent Successfully.");
      }

      if (res.msg.isNotEmpty) return Result.fail(res.msg, res.data);
    }
    if (res.data == "User already Registered!") return Result.fail(res.data);

    return res;
  }

  // TODO: request call Otp
  Future<Result> requestOtpOverCall(String number) async {
    final res = await handlePostRequest("otpOverCall", {"number": number});

    if (res.data["msg"]) return Result.pass(res.data["msg"], res.data);
    return res;
  }

  Future<Result<User?>> verifyRegisterOtp(String number, String otp) async {
    try {
      final response = await handlePostRequest(
        ServerRoute.verifyOtp,
        {
          "number": number,
          "otp": otp,
        },
      );
      final body = response.data;
      logger.i(body);

      if (body is Map<String, dynamic>) {
        if (response.isPass && body["status"] == 200) {
          return Result.pass(
              getMessage(body) ?? "OTP veified successfully?",
              User(
                uid: body["uid"] ?? "No Id",
                name: "",
                phone: number,
              ));
        }
        return Result.fail(getMessage(body) ?? "Unknown error");
      } else {
        return Result.fail("Failed to read server");
      }
    } catch (error) {
      return Result.fail("Unknown Error: $error");
    }
  }

  Future<Result<User?>> verifySigninOtp(String number, String otp) async {
    try {
      final res = await handlePostRequest(ServerRoute.verifyOtp, {
        "number": number,
        "otp": otp,
        "signin": true,
      });
      final body = res.data;

      if (body is Map<String, dynamic>) {
        if (res.isPass && body["status"] == 200) {
          return Result.pass(
              getMessage(body) ?? "OTP veified successfully?",
              User(
                uid: body["user"]["_id"],
                name: "",
                phone: number,
              ));
        }
        return Result.fail(getMessage(body) ?? "Unknown error");
      } else {
        return Result.fail("Failed to read server");
      }
    } catch (error) {
      return Result.fail("Unknown Error: $error");
    }
  }
}

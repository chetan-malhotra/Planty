import 'package:planty_homes/data/models/address_model.dart';
import 'package:planty_homes/data/models/nursery_model.dart';

import '../models/plants_model.dart';

const addressTest = Address(
  id: "randomId",
  name: "Test",
  addressLine1: "H.No. 30/093, Fake Nagar, Bola Mandi",
  city: "Chandigarh",
  country: "India",
  zipcode: 534809,
);

final testPlant = Plant(
  id: "asdfas",
  name: "Palm Tree",
  category: "Ceramic",
  price: 90,
  imageURL: "https://picsum.photos/100",
  description: "",
  rating: 4.5,
  ratingCount: 167,
  tags: [],
);

final testNursery1 = Nursery(
  id: "test1",
  name: "Meta Green House Nursery",
  rating: 4.7,
  reviewCount: 123,
  distance: 100,
  location: "Chandigarh",
  distanceInTime: "30 min.",
  categories: ["ceramic", "indoor", "decor", "sapling"],
);

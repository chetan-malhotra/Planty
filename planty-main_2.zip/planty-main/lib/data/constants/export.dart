
//getx
export 'package:flutter/material.dart';
export 'package:get/get.dart';
export 'dart:async';
export 'package:flutter/services.dart';

//plugins
export 'package:flutter_screenutil/flutter_screenutil.dart';

//constants
export 'package:planty_homes/data/constants/theme.dart';
export 'package:planty_homes/data/constants/strings.dart';
export 'package:planty_homes/data/constants/assets.dart';
export 'package:planty_homes/data/constants/dimens.dart';
export 'package:planty_homes/data/constants/colors.dart';


//routes
// export 'package:planty/routes/screen_routes.dart';
// export 'package:planty/routes/pages.dart';

//bindings
// export 'package:planty/screens/authentication/binding/login_binding.dart';
//
//
// //controllers
// export 'package:planty/screens/authentication/controllers/edit_profile_controller.dart';
// export 'package:planty/screens/authentication/controllers/login_controller.dart';
// export 'package:planty/screens/authentication/controllers/otp_verify_controller.dart';
// export 'package:planty/screens/authentication/controllers/profile_controller.dart';
//
//
// //screens
//
// export 'package:planty/screens/authentication/views/customer/otp_verify_screen.dart';
// export 'package:planty/screens/authentication/views/customer/address.dart';
// export 'package:planty/screens/authentication/views/customer/login_screen.dart';
// export 'package:planty/screens/authentication/views/customer/edit_profile_screen.dart';






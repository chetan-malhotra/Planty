class ServerRoute {
  static const String baseUrl = "https://www.plantyhomes.com";
  
  static const String signup = "/signup";
  static const String signin = "/signin";
  static const String verifyOtp = "/verify";

  static const String updateProfile = "/updateProfile";
  static const String getUserDetails = "/getProfile";

  static const String getAllNurseries = "/getAllNursery";

  static const String getCartItems = "/getCartItems";
  static const String addToCart = "/addToCart";
  static const String updateCartItem = "/updateCart";
  static const String removeCartItem = "/deleteCart";
}

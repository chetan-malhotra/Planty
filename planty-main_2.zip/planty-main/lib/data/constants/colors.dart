
import 'export.dart';

const Color appColor = Color.fromARGB(255, 21, 156, 22);
const Color dividerColor = Color.fromARGB(255, 190, 190, 190);

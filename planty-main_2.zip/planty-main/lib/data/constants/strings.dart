const String stringLoginOrSignup = "Log in or Sign up";
const String stringLoginHeading =
    "One Stop Solution \n For All Your Planting Needs";
String stringLoginPolicy =
    " By continuing, you agree to our \n Terms of Service\tPrivacy Policy\tContent Policy";

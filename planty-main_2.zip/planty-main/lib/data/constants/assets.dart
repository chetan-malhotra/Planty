

const String icPic = "assets/images/1.png";

const String iconGoogle = "assets/icons/google_icon.png";

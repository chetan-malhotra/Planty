import 'package:planty_homes/data/constants/export.dart';

ThemeData themeData = ThemeData(
  // brightness: Brightness.light,
  // primaryColor: Colors.white,
  // scaffoldBackgroundColor: Colors.white,
  fontFamily: 'Roboto',
  useMaterial3: true,
  colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
  scaffoldBackgroundColor: Colors.white,
  navigationBarTheme: NavigationBarThemeData(
    backgroundColor: Colors.white,
    elevation: 0,
    labelTextStyle: MaterialStatePropertyAll(
      TextStyle(
          color: Colors.black.withOpacity(.8), fontWeight: FontWeight.w400),
    ),
    indicatorColor: Colors.green,
    iconTheme: MaterialStateProperty.resolveWith((state) {
      if (state.contains(MaterialState.pressed)) {
        return IconThemeData(color: Colors.black.withOpacity(.4));
      } else if (state.contains(MaterialState.selected)) {
        return const IconThemeData(color: Colors.white);
      }
      return IconThemeData(color: Colors.black.withOpacity(.7));
    }),
  ),

  appBarTheme: const AppBarTheme(
    backgroundColor: Colors.white,
    foregroundColor: Colors.black,
    surfaceTintColor: Colors.white,
    elevation: margin_0,
  ),
  // colorScheme: const ColorScheme(
  //   background: Colors.white,
  //   brightness: Brightness.light,
  //   primary: Colors.white,
  //   onPrimary: Colors.white,
  //   secondary: Colors.white,
  //   onSecondary: Colors.white,
  //   error: Colors.white,
  //   onBackground: Colors.white,
  //   onError: Colors.white,
  //   surface: Colors.white,
  //   onSurface: Colors.white,
  // ),
  // textTheme: TextTheme(
  //   headlineLarge: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_24,
  //       fontWeight: FontWeight.w900,
  //       fontFamily: 'Roboto'),
  //   headlineMedium: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_20,
  //       fontWeight: FontWeight.w700,
  //       fontFamily: 'Roboto'),
  //   headlineSmall: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_18,
  //       fontWeight: FontWeight.w700,
  //       fontFamily: 'Roboto'),
  //   displayLarge: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_16,
  //       fontWeight: FontWeight.w500,
  //       fontFamily: 'Roboto'),
  //   displayMedium: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_15,
  //       fontWeight: FontWeight.w500,
  //       fontFamily: 'Roboto'),
  //   displaySmall: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_14,
  //       fontWeight: FontWeight.w500,
  //       fontFamily: 'Roboto'),
  //   bodyLarge: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_13p5,
  //       fontWeight: FontWeight.w500,
  //       fontFamily: 'Roboto'),
  //   bodyMedium: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_13,
  //       fontWeight: FontWeight.w500,
  //       fontFamily: 'Roboto'),
  //   bodySmall: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_12p5,
  //       fontWeight: FontWeight.w500,
  //       fontFamily: 'Roboto'),
  //   titleLarge: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_15,
  //       fontWeight: FontWeight.w700,
  //       fontFamily: 'Roboto'),
  //   titleMedium: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_14,
  //       fontWeight: FontWeight.w700,
  //       fontFamily: 'Roboto'),
  //   titleSmall: TextStyle(
  //       color: Colors.black,
  //       fontSize: font_15,
  //       fontWeight: FontWeight.w700,
  //       fontFamily: 'Roboto'),
  // ),
  // iconTheme: IconThemeData(color: Colors.black, size: height_20),
);

class TextStyles {
  static const heading1 = TextStyle(
    fontSize: 22,
    fontWeight: FontWeight.w500,
  );
  static const heading2 = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w500,
  );
  static const heading3 =
      TextStyle(fontSize: 16, fontWeight: FontWeight.w500);

  static const body1 =
      TextStyle(fontSize: 14, fontWeight: FontWeight.w400);
}

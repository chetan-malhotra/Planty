import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SnackBarHelper {
  static void showSuccess(String msg, [title = "Success"]) {
    Get.snackbar(title, msg,
        backgroundColor: Colors.green,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(16));
  }

  static void showError(String msg, [title = "Error"]) {
    Get.snackbar(title, msg,
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(16));
  }
}

import 'package:get_storage/get_storage.dart';
import 'package:planty_homes/data/models/order_model.dart';

import '../models/address_model.dart';
import '../models/generated_models.dart';
import '../models/nursery_model.dart';
import '../models/plants_model.dart';
import '../models/user_model.dart';
import 'logger.dart';

/// Note that this is a singleton class
/// and only one instance is initialised througout the lifetime of the app
class CacheHelper {
  static final GetStorage _box = GetStorage();

  static const String _userCacheKey = 'userCache';
  static const String _plantCacheKey = 'plantCache';
  static const String _nurseryCacheKey = 'nurseryCache';
  static const String _addressCacheKey = 'addressCache';
  static const String _cartKey = 'cartCache';
  static const String _bookmarkNurseriesKey = 'bookmarkNurseries';
  static const String _bookmarkPlantsKey = 'bookmarkPlants';

  static void cacheUser(User user) {
    final userData = user.toJson();
    _box.write(_userCacheKey, userData);
  }

  static void clearUserCache() {
    _box.remove(_userCacheKey);
  }

  static User? getUserFromCache() {
    final userData = _box.read(_userCacheKey);
    if (userData != null) {
      return User.fromJson(Map<String, dynamic>.from(userData));
    }
    return null;
  }

  static Future<void> cachePlants(String nurseryId, List<Plant> plants) async {
    final plantListJson = plants.map((plant) => plant.toJson()).toList();
    await _box.write('${_plantCacheKey}_$nurseryId', plantListJson);
  }

  static void clearPlantsCache(String nurseryId) {
    _box.remove('${_plantCacheKey}_$nurseryId');
  }

  static List<Plant> getPlantsFromCache(String nurseryId) {
    final plantListJson = _box.read('${_plantCacheKey}_$nurseryId');
    if (plantListJson != null) {
      final plantList = List<Map<String, dynamic>>.from(plantListJson);
      return plantList.map((plantMap) => Plant.fromJson(plantMap)).toList();
    }
    return [];
  }

  static Future<void> cacheNurseries(List<SNursery> nurseries) async {
    final nurseryListJson =
        nurseries.map((nursery) => nursery.toJson()).toList();
    await _box.write(_nurseryCacheKey, nurseryListJson);
  }

  static void clearNurseriesCache() {
    _box.remove(_nurseryCacheKey);
  }

  static List<Nursery> getNurseriesFromCache() {
    final nurseryListJson = _box.read(_nurseryCacheKey);
    if (nurseryListJson != null) {
      final nurseryList = List<Map<String, dynamic>>.from(nurseryListJson);
      return nurseryList
          .map((nurseryMap) => Nursery.fromJson(nurseryMap))
          .toList();
    }
    return [];
  }

  static Future<void> cacheCart(List<Order> orders) async {
    final ordersListJson = orders.map((order) => order.toJson()).toList();
    await _box.write(_cartKey, ordersListJson);
  }

  static void clearCart() {
    _box.remove(_cartKey);
  }

  static List<Order> getCartFromCache() {
    final orderListJson = _box.read(_cartKey);
    if (orderListJson != null) {
      final ordersList = List<Map<String, dynamic>>.from(orderListJson);
      return ordersList.map((ordersMap) => Order.fromJson(ordersMap)).toList();
    }
    return [];
  }

  static Future<void> cacheAddresses(List<Address> addresses) async {
    final addressListJson =
        addresses.map((address) => address.toJson()).toList();
    await _box.write(_addressCacheKey, addressListJson);
  }

  static void clearAddressesCache() {
    _box.remove(_addressCacheKey);
  }

  static List<Address> getAddressesFromCache() {
    final addressListJson = _box.read(_addressCacheKey);
    if (addressListJson != null) {
      final addressList = List<Map<String, dynamic>>.from(addressListJson);
      return addressList
          .map((addressMap) => Address.fromJson(addressMap))
          .toList();
    }
    return [];
  }

  static void addBookmarkedNursery(String nurseryId) {
    final List<String> nurseries = _box.read(_bookmarkNurseriesKey) ?? [];
    nurseries.add(nurseryId);
    _box.write(_bookmarkNurseriesKey, nurseries);
  }

  static void removeBookmarkedNursery(String nurseryId) {
    final List<String> nurseries = _box.read(_bookmarkNurseriesKey) ?? [];
    nurseries.remove(nurseryId);
    _box.write(_bookmarkNurseriesKey, nurseries);
  }

  static List<String> getBookmarkedNurseries() {
    return _box.read(_bookmarkNurseriesKey) ?? [];
  }

  static void addBookmarkedPlant(String plantId) {
    final List<String> plants = _box.read(_bookmarkPlantsKey) ?? [];
    plants.add(plantId);
    _box.write(_bookmarkPlantsKey, plants);
  }

  static void removeBookmarkedPlant(String plantId) {
    final List<String> plants = _box.read(_bookmarkPlantsKey) ?? [];
    plants.remove(plantId);
    _box.write(_bookmarkPlantsKey, plants);
  }

  static List<String> getBookmarkedPlants() {
    return _box.read(_bookmarkPlantsKey) ?? [];
  }
}

import 'package:get/get.dart';
import 'package:planty_homes/controllers/user_controller.dart';
import 'package:planty_homes/data/models/server_result_model.dart';
import 'package:planty_homes/data/utils/logger.dart';

import '../constants/server_constants.dart';

export '../models/server_result_model.dart';
export 'package:planty_homes/data/constants/server_constants.dart';

class ServerNoAuth extends GetConnect {
  @override
  bool get allowAutoSignedCert => true;

  @override
  String? get baseUrl => ServerRoute.baseUrl;

  @override
  void onInit() {
    httpClient.baseUrl = ServerRoute.baseUrl;
    httpClient.defaultContentType = "application/json";
    httpClient.addResponseModifier((request, response) {
      logger.i({response.statusCode, response.statusText, response.body});
      return response;
    });
    httpClient.timeout = const Duration(seconds: 8);
    allowAutoSignedCert = true;
    logger.i("initialised server ${httpClient.baseUrl}");
    super.onInit();
  }

  Future<Result> handlePostRequest(
    String nestUrl,
    Map<String, dynamic>? data,
  ) async {
    try {
      final res = await post(nestUrl, data);
      if (res.hasError) {
        if (res.body.runtimeType != Map<String, dynamic>) {
          logger.e(res.body);
          return Result.fail("cannot read from server", res.body);
        }
        if (res.body.runtimeType == String) Result.fail("server error");
        return Result.fail(
            getMessage(res.body) ?? res.statusText ?? "Unknown error",
            res.body);
      } else {
        return Result.pass(getMessage(res.body) ?? "", res.body);
      }
    } catch (error) {
      logger.e(error);
      return Result.fail("Unkonwn error", error);
    }
  }

  Future<Result> handleGetRequest(String nestUrl,
      [Map<String, String>? headers]) async {
    try {
      final res = await get(nestUrl, headers: headers);
      if (res.statusCode != 200) {
        return Result.fail(
            getMessage(res.body) ?? "Something went wrong", res.body);
      } else {
        return Result.pass(getMessage(res.body) ?? "", res.body);
      }
    } catch (error) {
      return Result.fail("Unkonwn error", error);
    }
  }

  String? getMessage(dynamic body) {
    if (body is Map<String, dynamic>) {
      if (body.containsKey("message")) return body["message"];
      if (body.containsKey("msg")) return body["msg"];
    }
    return null;
  }
}

class ServerAuth extends GetConnect {
  @override
  bool get allowAutoSignedCert => true;

  @override
  String? get baseUrl => ServerRoute.baseUrl;

  @override
  void onInit() async {
    httpClient.baseUrl = ServerRoute.baseUrl;
    httpClient.defaultContentType = "application/json";
    httpClient.timeout = const Duration(seconds: 12);
    allowAutoSignedCert = true;
    httpClient.addResponseModifier((request, response) {
      logger.i({response.statusCode, response.statusText, response.body});
      return response;
    });
    final user = Get.find<UserController>();
    var headers = {'Authorization': await user.getIdToken()?? ""};
    httpClient.addAuthenticator<Object?>((request) async {
      request.headers.addAll(headers);
      return request;
    });

    super.onInit();
  }

  Future<Result> handlePostRequest(
      String nestUrl, Map<String, dynamic>? data) async {
    try {
      final res = await post(nestUrl, data);
      if (res.hasError) {
        if (res.body.runtimeType == String) Result.fail("server error");
        return Result.fail(res.body?["msg"] ?? res.statusText, res.body);
      } else {
        return Result.pass(res.body?["msg"] ?? "", res.body);
      }
    } catch (error) {
      logger.e(error);
      return Result.fail("Unkonwn error", error);
    }
  }

  Future<Result> handleGetRequest(String nestUrl,
      [Map<String, String>? data]) async {
    try {
      final res = await get(nestUrl, headers: data);
      if (res.hasError) {
        return Result.fail(res.body["msg"] ?? "Something went wrong", res.body);
      } else {
        return Result.pass(res.body["msg"] ?? "", res.body);
      }
    } catch (error) {
      return Result.fail("Unkonwn error", error);
    }
  }
}

const tempAddr = "https://planty-server.vercel.app";

// const tempAddr = "https://mirus.serveo.net";
class NewServer extends GetConnect {
  @override
  bool get allowAutoSignedCert => true;

  @override
  String? get baseUrl => tempAddr;

  @override
  void onInit() async {
    httpClient.baseUrl = tempAddr;
    httpClient.defaultContentType = "application/json";
    httpClient.timeout = const Duration(seconds: 8);
    allowAutoSignedCert = true;
    httpClient.addResponseModifier((request, response) {
      logger.i({response.statusCode, response.statusText, response.body});
      return response;
    });
    final user = Get.find<UserController>();
    var headers = {'token': await user.getIdToken() ?? ""};
    httpClient.addAuthenticator<Object?>((request) async {
      request.headers.addAll(headers);
      logger.e(request.headers);
      return request;
    });

    super.onInit();
  }

  Future<Result> handlePostRequest(
      String nestUrl, Map<String, dynamic>? data) async {
    try {
      final user = Get.find<UserController>();
      final res = await post(nestUrl, data,
          headers: {'token': await user.getIdToken() ?? ""});
      if (res.hasError) {
        if (res.body.runtimeType == String) Result.fail("server error");
        return Result.fail(res.body?["msg"] ?? res.statusText, res.body);
      } else {
        return Result.pass(
            res.body?["msg"] ?? "", res.body["data"] ?? res.body);
      }
    } catch (error) {
      logger.e(error);
      return Result.fail("Unkonwn error", error);
    }
  }

  Future<Result> handleGetRequest(String nestUrl,
      [Map<String, String>? data]) async {
    try {
      final res = await get(nestUrl, headers: data);
      if (res.hasError) {
        return Result.fail(res.body["msg"] ?? "Something went wrong", res.body);
      } else {
        return Result.pass(res.body["msg"] ?? "", res.body);
      }
    } catch (error) {
      return Result.fail("Unkonwn error", error);
    }
  }
}

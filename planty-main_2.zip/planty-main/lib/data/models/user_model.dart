class User {
  String uid;
  String name;
  String? phone;
  String? specialAnniversary;
  String? email;
  String? dob;
  String? profilePicUrl;
  String? countryCode;

  User({
    required this.uid,
    required this.name,
    this.phone,
    this.specialAnniversary,
    this.email,
    this.dob,
    this.profilePicUrl,
    this.countryCode,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    String phone = json["phone"] ?? "";
      if(json['phone'].length > 12) phone = phone.substring(phone.length - 10);
    return User(
      uid: json['uid'],
      name: json['name'],
      phone: phone,
      specialAnniversary: json['specialAnniversary'],
      email: json['email'],
      dob: json['dob'] ?? json["birthday"],
      profilePicUrl: json['profilePicUrl'],
      countryCode: json['countryCode'] ?? "91",
    );
  }

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{
      'uid': uid,
      'name': name,
    };

    if (phone != null) json['phone'] = phone;
    if (specialAnniversary != null) json['specialAnniversary'];
    if (email != null) json['email'] = email;
    if (dob != null) json['dob'] = dob;
    if (profilePicUrl != null) json['profilePicUrl'] = profilePicUrl;
    if (countryCode != null) json['countryCode'] = countryCode;

    return json;
  }

  @override
  String toString() {
    return toJson().toString();
  }
}

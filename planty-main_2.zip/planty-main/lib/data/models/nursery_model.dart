class Nursery {
  String id;
  String nurseryName;
  String address;
  String city;
  String country;
  String googleLocation;
  String nurseryContact;
  String nurseryEmail;
  String ownerName;
  int ownerContact;
  String ownerEmail;
  String state;
  String street;

  Nursery({
    required this.id,
    required this.nurseryName,
    required this.address,
    required this.city,
    required this.country,
    required this.googleLocation,
    required this.nurseryContact,
    required this.nurseryEmail,
    required this.ownerName,
    required this.ownerContact,
    required this.ownerEmail,
    required this.state,
    required this.street,
  });

  factory Nursery.fromJson(Map<String, dynamic> json) {
    return Nursery(
      id: json['id'] ?? "",
      nurseryName: json['nurseryName'] ?? "",
      address: json['address'] ?? "",
      city: json['city'] ?? "",
      country: json['country'] ?? "",
      googleLocation: json['googleLocation'] ?? "",
      nurseryContact: json['nurseryContact'] ?? "",
      nurseryEmail: json['nurseryEmail'] ?? "",
      ownerName: json['ownerName'] ?? "",
      ownerContact: json['ownerContact'] ?? 0,
      ownerEmail: json['ownerEmail'] ?? "",
      state: json['state'] ?? "",
      street: json['street'] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nurseryName': nurseryName,
      'address': address,
      'city': city,
      'country': country,
      'googleLocation': googleLocation,
      'nurseryContact': nurseryContact,
      'nurseryEmail': nurseryEmail,
      'ownerName': ownerName,
      'ownerContact': ownerContact,
      'ownerEmail': ownerEmail,
      'state': state,
      'street': street,
    };
  }
}

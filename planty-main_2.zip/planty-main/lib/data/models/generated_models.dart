class SNursery {
  String id;
  String address;
  String city;
  String country;
  String googleLocation;
  String nurseryContact;
  String nurseryEmail;
  String nurseryName;
  int ownerContact;
  String ownerEmail;
  String ownerName;
  String state;
  String street;
  List<List<AvailablePlant>> availablePlants;

  SNursery({
    required this.id,
    required this.address,
    required this.city,
    required this.country,
    required this.googleLocation,
    required this.nurseryContact,
    required this.nurseryEmail,
    required this.nurseryName,
    required this.ownerContact,
    required this.ownerEmail,
    required this.ownerName,
    required this.state,
    required this.street,
    required this.availablePlants,
  });

  factory SNursery.fromJson(Map<String, dynamic> json) {
    List<List<AvailablePlant>> availablePlants = [];
    if (json['available_plants'] != null) {
      var plantsJson = json['available_plants'] as List<dynamic>;
      availablePlants = plantsJson.map((plants) {
        return (plants as List<dynamic>).map((plant) {
          return AvailablePlant.fromJson(plant);
        }).toList();
      }).toList();
    }

    return SNursery(
      id: json['_id'] ?? "",
      address: json['address'] ?? "",
      city: json['city'] ?? "",
      country: json['country'] ?? "",
      googleLocation: json['google_location'] ?? "",
      nurseryContact: json['nursery_contact '] ?? "",
      nurseryEmail: json['nursery_email: '] ?? "",
      nurseryName: json['nursery_name '] ?? "",
      ownerContact: json['owner_contact'] ?? "",
      ownerEmail: json['owner_email'] ?? "",
      ownerName: json['owner_name'] ?? "",
      state: json['state'] ?? "",
      street: json['street'] ?? "",
      availablePlants: availablePlants,
    );
  }
  Map<String, dynamic> toJson() {
    List<List<Map<String, dynamic>>> availablePlantsJson =
        availablePlants.map((plants) {
      return plants.map((plant) => plant.toJson()).toList();
    }).toList();

    return {
      '_id': id,
      'address': address,
      'city': city,
      'country': country,
      'google_location': googleLocation,
      'nursery_contact ': nurseryContact,
      'nursery_email: ': nurseryEmail,
      'nursery_name ': nurseryName,
      'owner_contact': ownerContact,
      'owner_email': ownerEmail,
      'owner_name': ownerName,
      'state': state,
      'street': street,
      'available_plants': availablePlantsJson,
    };
  }
}

class AvailablePlant {
  String id;
  String nurseryId;
  String nurseryName;
  String name;
  int price;
  List<Category> category;
  String diversification;
  int potsPrice;
  List<DeliveryPot> deliveryPots;
  PlantDetails details;

  AvailablePlant({
    required this.id,
    required this.nurseryId,
    required this.nurseryName,
    required this.name,
    required this.price,
    required this.category,
    required this.diversification,
    required this.potsPrice,
    required this.deliveryPots,
    required this.details,
  });

  factory AvailablePlant.fromJson(Map<String, dynamic> json) {
    List<Category> categories = [];
    if (json['category'] != null) {
      var categoryJson = json['category'] as List<dynamic>;
      categories = categoryJson.map((category) {
        return Category.fromJson(category);
      }).toList();
    }

    List<DeliveryPot> deliveryPots = [];
    if (json['delivery_pots'] != null) {
      var deliveryPotsJson = json['delivery_pots'] as List<dynamic>;
      deliveryPots = deliveryPotsJson.map((deliveryPot) {
        return DeliveryPot.fromJson(deliveryPot);
      }).toList();
    }

    PlantDetails plantDetails = PlantDetails.fromJson(json['details']);

    return AvailablePlant(
      id: json['_id'] ?? "",
      nurseryId: json['nursery_id'] ?? "",
      nurseryName: json['nursery_name'] ?? "",
      name: json['name'] ?? "",
      price: json['price'] ?? "",
      category: categories,
      diversification: json['diversification'] ?? "",
      potsPrice: json['pots_price'] ?? "",
      deliveryPots: deliveryPots,
      details: plantDetails,
    );
  }
  Map<String, dynamic> toJson() {
    List<Map<String, dynamic>> categoryJson =
        category.map((category) => category.toJson()).toList();
    List<Map<String, dynamic>> deliveryPotsJson =
        deliveryPots.map((deliveryPot) => deliveryPot.toJson()).toList();
    Map<String, dynamic> plantDetailsJson = details.toJson();

    return {
      '_id': id,
      'nursery_id': nurseryId,
      'nursery_name': nurseryName,
      'name': name,
      'price': price,
      'category': categoryJson,
      'diversification': diversification,
      'pots_price': potsPrice,
      'delivery_pots': deliveryPotsJson,
      'details': plantDetailsJson,
    };
  }
}

class Category {
  String categoryId;
  String categoryName;

  Category({
    required this.categoryId,
    required this.categoryName,
  });

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(
      categoryId: json['category_id'] ?? "",
      categoryName: json['category_name'] ?? "",
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'category_id': categoryId,
      'category_name': categoryName,
    };
  }
}

class DeliveryPot {
  String potsId;
  int price;
  String potsType;

  DeliveryPot({
    required this.potsId,
    required this.price,
    required this.potsType,
  });

  factory DeliveryPot.fromJson(Map<String, dynamic> json) {
    return DeliveryPot(
      potsId: json['pots_id'] ?? "",
      price: json['price'] ?? "",
      potsType: json['pots_type'] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'pots_id': potsId,
      'price': price,
      'pots_type': potsType,
    };
  }
}

class PlantDetails {
  String plantName;
  String USPS;
  List<Category> category;
  String description;
  String instructions;
  String plantDescription;
  String plantId;

  PlantDetails({
    required this.plantName,
    required this.USPS,
    required this.category,
    required this.description,
    required this.instructions,
    required this.plantDescription,
    required this.plantId,
  });

  factory PlantDetails.fromJson(Map<String, dynamic> json) {
    List<Category> categories = [];
    if (json['category'] != null) {
      var categoryJson = json['category'] as List<dynamic>;
      categories = categoryJson.map((category) {
        return Category.fromJson(category);
      }).toList();
    }

    return PlantDetails(
      plantName: json['plant_name'] ?? "",
      USPS: json['USPS'] ?? "",
      category: categories,
      description: json['description'] ?? "",
      instructions: json['instructions'] ?? "",
      plantDescription: json['plant_description'] ?? "",
      plantId: json['plant_id'] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    List<Map<String, dynamic>> categoryJson =
        category.map((category) => category.toJson()).toList();

    return {
      'plant_name': plantName,
      'USPS': USPS,
      'category': categoryJson,
      'description': description,
      'instructions': instructions,
      'plant_description': plantDescription,
      'plant_id': plantId,
    };
  }
}

import 'package:planty_homes/data/models/plants_model.dart';
import 'package:planty_homes/modules/orders/coupons/models/coupon_model.dart';

import '../utils/logger.dart';
import 'address_model.dart';

class Delivery {
  String nurseryId;
  String nurseryName;
  double fee;
  Address to;

  Delivery({
    required this.nurseryId,
    required this.nurseryName,
    required this.fee,
    required this.to,
  });

  Map<String, dynamic> toJson() {
    return {
      'nurseryId': nurseryId,
      'nurseryName': nurseryName,
      'fee': fee,
      'to': to.toJson(),
    };
  }

  factory Delivery.fromJson(Map<String, dynamic> json) {
    return Delivery(
      nurseryId: json['nurseryId'],
      nurseryName: json['nurseryName'],
      fee: json['fee'],
      to: Address.fromJson(json['to']),
    );
  }
}

class Order {
  Plant plant;
  int count;
  int price;
  Delivery? delivery;
  DateTime expectedArrival;
  int? discountPrice;
  int? discountPercentage;
  OrderStatus status;
  List<Coupon>? coupons;

  Order({
    required this.plant,
    required this.count,
    required this.price,
    this.delivery,
    required this.expectedArrival,
    this.discountPrice,
    this.discountPercentage,
    required this.status,
    this.coupons,
  });

  // Convert Order object to a JSON map
  Map<String, dynamic> toJson() {
    return {
      'plant': plant.toJson(),
      'count': count,
      'price': price,
      'delivery': delivery?.toJson(),
      'expectedArrival': expectedArrival.toIso8601String(),
      'discountPrice': discountPrice,
      'discountPercentage': discountPercentage,
      'status': status.toString(),
      'coupons': coupons?.map((coupon) => coupon.toJson()).toList(),
    };
  }

  Map<String, dynamic> toServer() {
    return {
      'plantId': plant.id,
      'quantity': count,
      'price': price,
      'status': status.toString(),
    };
  }

  // Factory constructor to create an Order object from a JSON map
  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      plant: Plant.fromJson(json['plant']),
      count: json['count'] ?? json['quantity'] ?? 0,
      price: json['price'] ?? 0,
      delivery:
          json['delivery'] != null ? Delivery.fromJson(json['delivery']) : null,
      expectedArrival:
          DateTime.parse(json['expectedArrival'] ?? "2023-07-09T01:40:45.570Z"),
      // discountPrice: json['discountPrice'],
      // discountPercentage: json['discountPercentage'],
      status: orderStatusFromString(json['status']),
      coupons: json['coupons'] == null
          ? []
          : List<Coupon>.from(
              json['coupons'].map((couponJson) => Coupon.fromJson(couponJson))),
    );
  }
}

enum OrderStatus {
  failed,
  notOrdered,
  packaging,
  reachedToNearest,
  outForDelivery,
  delivered,
  cancelled,
  preparing,
}

OrderStatus orderStatusFromString(String statusString) {
  switch (statusString) {
    case 'failed':
      return OrderStatus.failed;
    case 'notOrdered':
      return OrderStatus.notOrdered;
    case 'packaging':
      return OrderStatus.packaging;
    case 'reachedToNearest':
      return OrderStatus.reachedToNearest;
    case 'outForDelivery':
      return OrderStatus.outForDelivery;
    case 'delivered':
      return OrderStatus.delivered;
    case 'cancelled':
      return OrderStatus.cancelled;
    case 'preparing':
      return OrderStatus.preparing;
    case 'OrderStatus.failed':
      return OrderStatus.failed;
    case 'OrderStatus.notOrdered':
      return OrderStatus.notOrdered;
    case 'OrderStatus.packaging':
      return OrderStatus.packaging;
    case 'OrderStatus.reachedToNearest':
      return OrderStatus.reachedToNearest;
    case 'OrderStatus.outForDelivery':
      return OrderStatus.outForDelivery;
    case 'OrderStatus.delivered':
      return OrderStatus.delivered;
    case 'OrderStatus.cancelled':
      return OrderStatus.cancelled;
    case 'OrderStatus.preparing':
      return OrderStatus.preparing;
    default:
      return OrderStatus.notOrdered;
  }
}

String getStatusString(OrderStatus status) {
  switch (status) {
    case OrderStatus.failed:
      return 'failed';
    case OrderStatus.notOrdered:
      return 'notOrdered';
    case OrderStatus.packaging:
      return 'packaging';
    case OrderStatus.reachedToNearest:
      return 'reachedToNearest';
    case OrderStatus.outForDelivery:
      return 'outForDelivery';
    case OrderStatus.delivered:
      return 'delivered';
    case OrderStatus.cancelled:
      return 'cancelled';
    case OrderStatus.preparing:
      return 'preparing';
    default:
      throw Exception('Invalid OrderStatus value');
  }
}

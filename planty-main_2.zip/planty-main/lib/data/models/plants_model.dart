class Plant {
  String id;
  String nurseryId;
  String nurseryName;
  String name;
  int price;
  List<String> category;
  String diversification;
  int potsPrice;
  List<DeliveryPot> deliveryPots;
  String description;

  Plant({
    required this.id,
    required this.nurseryId,
    required this.nurseryName,
    required this.name,
    required this.price,
    required this.category,
    required this.diversification,
    required this.potsPrice,
    required this.deliveryPots,
    required this.description,
  });

  factory Plant.fromJson(Map<String, dynamic> json) {
    return Plant(
      id: json['id'] ?? "", 
      nurseryId: json['nurseryId'] ?? "",
      nurseryName: json['nurseryName'] ?? "",
      name: json['name'] ?? "",
      price: json['price'] ?? 0,
      category: List<String>.from(json['category'] ?? []),
      diversification: json['diversification'] ?? "",
      potsPrice: json['potsPrice'] ?? 0,
      deliveryPots: List<DeliveryPot>.from(json['deliveryPots']?.map((x) => DeliveryPot.fromJson(x)) ?? []),
      description: json['description'] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nurseryId': nurseryId,
      'nurseryName': nurseryName,
      'name': name,
      'price': price,
      'category': category,
      'diversification': diversification,
      'potsPrice': potsPrice,
      'deliveryPots': List<dynamic>.from(deliveryPots.map((x) => x.toJson())),
      'description': description,
    };
  }
}

class DeliveryPot {
  String id;
  String potsId;
  int price;
  String potsType;

  DeliveryPot({
    required this.id,
    required this.potsId,
    required this.price,
    required this.potsType,
  });

  factory DeliveryPot.fromJson(Map<String, dynamic> json) {
    return DeliveryPot(
      id: json['id'] ?? "",
      potsId: json['potsId'] ?? "",
      price: json['price'] ?? 0,
      potsType: json['potsType'] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'potsId': potsId,
      'price': price,
      'potsType': potsType,
    };
  }
}


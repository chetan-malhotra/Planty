class Address {
  final String id;
  final String name;
  final String addressLine1;
  final String? addressLine2;
  final String country;
  final String city;
  final int zipcode;

  const Address({
    required this.id,
    required this.name,
    required this.addressLine1,
    required this.country,
    required this.city,
    required this.zipcode,
    this.addressLine2,
  });

  factory Address.fromJson(Map<String, dynamic> json) {
    return Address(
      id: json['id'] ?? "",
      name: json['name'] ?? "",
      addressLine1: json['addressLine1'] ?? "",
      addressLine2: json['addressLine2'] ?? "",
      country: json['country'] ?? "",
      city: json['city'] ?? "",
      zipcode: json["zipcode"],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'addressLine1': addressLine1,
      'addressLine2': addressLine2,
      'country': country,
      'city': city,
      'zipcode': zipcode,
    };
  }

  @override
  String toString() {
    var result = addressLine1;

    if (addressLine2 != null && addressLine2!.isNotEmpty) {
      result = "$result, $addressLine2, $city, $zipcode";
    }

    result = "$result, $city, $zipcode,";

    return result;
  }
}

class Result<T> {
  String msg;
  bool isPass;
  T? data;

  Result(this.isPass, this.msg, this.data);

  static Result<U?> pass<U>(String message, [U? data]) {
    return Result(true, message, data);
  }

  static Result<U?> fail<U>(String message, [U? data]) {
    return Result<U>(false, message, data);
  }

  @override
  String toString() {
    return """\n  
      ${isPass ? "pass" : "fail"}
      message: $msg
      data: $data\n""";
  }
}

part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const HOME = _Paths.HOME;
  static const LOGIN = _Paths.LOGIN;
  static const SETTINGS = _Paths.SETTINGS;
  static const EDIT_PROFILE = _Paths.EDIT_PROFILE;
  static const NURSERY = _Paths.NURSERY;
  static const ORDERS = _Paths.ORDERS;
  static const COUPONS = _Paths.ORDERS + _Paths.COUPONS;
  static const CART = _Paths.CART;
  static const AFFILIATE = _Paths.AFFILIATE;
  static const SEARCH = _Paths.HOME + _Paths.SEARCH;
}

abstract class _Paths {
  _Paths._();
  static const HOME = '/home';
  static const LOGIN = '/login';
  static const SETTINGS = '/settings';
  static const EDIT_PROFILE = '/edit-profile';
  static const NURSERY = '/nursery';
  static const ORDERS = '/orders';
  static const COUPONS = '/coupons';
  static const CART = '/cart';
  static const AFFILIATE = '/affiliate';
  static const SEARCH = '/search';
}

import 'package:get/get.dart';

import '../modules/affiliate/bindings/affiliate_binding.dart';
import '../modules/affiliate/views/affiliate_view.dart';
import '../modules/cart/bindings/cart_binding.dart';
import '../modules/cart/views/cart_view.dart';
import '../modules/edit_profile/bindings/edit_profile_binding.dart';
import '../modules/edit_profile/views/edit_profile_view.dart';
import '../modules/home/bindings/home_binding.dart';
import '../modules/home/search/bindings/search_binding.dart';
import '../modules/home/search/views/search_view.dart';
import '../modules/home/views/home_view.dart';
import '../modules/login/bindings/login_binding.dart';
import '../modules/login/views/login_view.dart';
import '../modules/nursery/bindings/nursery_binding.dart';
import '../modules/nursery/views/nursery_view.dart';
import '../modules/orders/bindings/orders_binding.dart';
import '../modules/orders/coupons/bindings/coupons_binding.dart';
import '../modules/orders/coupons/views/coupons_view.dart';
import '../modules/orders/views/orders_view.dart';
import '../modules/settings/bindings/settings_binding.dart';
import '../modules/settings/views/settings_view.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.LOGIN;

  static final routes = [
    GetPage(
      name: _Paths.HOME,
      page: () => const HomeView(),
      binding: HomeBinding(),
      children: [
        GetPage(
          name: _Paths.SEARCH,
          page: () => const SearchView(),
          binding: SearchBinding(),
        ),
      ],
    ),
    GetPage(
      name: _Paths.LOGIN,
      page: () => const LoginView(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: _Paths.SETTINGS,
      page: () => const SettingsView(),
      binding: SettingsBinding(),
    ),
    GetPage(
      name: _Paths.EDIT_PROFILE,
      page: () => const EditProfileView(),
      binding: EditProfileBinding(),
    ),
    GetPage(
      name: _Paths.NURSERY,
      page: () => const NurseryView(),
      binding: NurseryBinding(),
    ),
    GetPage(
      name: _Paths.ORDERS,
      page: () => const OrdersView(),
      binding: OrdersBinding(),
      children: [
        GetPage(
          name: _Paths.COUPONS,
          page: () => const CouponsView(),
          binding: CouponsBinding(),
        ),
      ],
    ),
    GetPage(
      name: _Paths.CART,
      page: () => const CartView(),
      binding: CartBinding(),
    ),
    GetPage(
      name: _Paths.AFFILIATE,
      page: () => const AffiliateView(),
      binding: AffiliateBinding(),
    ),
  ];
}

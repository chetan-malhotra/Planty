import 'package:firebase_auth/firebase_auth.dart' hide User;
import 'package:get/get.dart';
import 'package:planty_homes/data/utils/cache_helper.dart';
import 'package:planty_homes/data/utils/snackbar.dart';

import '../data/models/user_model.dart';
import '../data/utils/logger.dart';

class UserController extends GetxController {
  final Rx<User?> _user = Rx<User?>(null);

  @override
  void onInit() {
    super.onInit();
    print("finding user");
    _user.value = CacheHelper.getUserFromCache();
    final fUser = FirebaseAuth.instance.currentUser;
    if (_user.value == null && fUser != null) {
      _user.value = User(uid: fUser.uid, name: fUser.displayName ?? "");
    }
    logger.w(_user.value);
  }

  @override
  void onClose() {
    _user.close();
    super.onClose();
  }

  User? get user => _user.value;
  void setUser(User user) {
    _user.value = user;
    CacheHelper.cacheUser(user);
    print("cache: ${CacheHelper.getUserFromCache()}");
    update();
  }

  Future<String?> getIdToken() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser != null) {
      final idTokenResult = await currentUser.getIdTokenResult();
      final isExpired = idTokenResult.expirationTime
          ?.isAfter(DateTime.now().subtract(const Duration(days: 1)));
      if (isExpired ?? true) {
        return (await currentUser.getIdTokenResult(true)).token;
      }
      return idTokenResult.token;
    }
    return null;
  }

  Future<void> updateEmail(String newEmail) async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser != null) {
        await currentUser.updateEmail(newEmail);
        await currentUser.reload();
        SnackBarHelper.showSuccess(
          "An email has been sent, verify the email by clicking on the link",
        );
        // setUser(FirebaseAuth.instance.currentUser!);
      }
    } on FirebaseException catch (error) {
      SnackBarHelper.showError(error.message ?? "Unknown error");
    } catch (error) {
      SnackBarHelper.showError("Unknown error $error");
    }
  }

  Future<void> updateProfile(String displayName) async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser != null) {
        await currentUser.updateDisplayName(displayName);
        currentUser.reload();
        // setUser(FirebaseAuth.instance.currentUser!);
      }
    } on FirebaseException catch (error) {
      SnackBarHelper.showError(error.message ?? "Unknown error");
    } catch (error) {
      SnackBarHelper.showError("Unknown error $error");
    }
  }

  Future<void> logout() async {
    await FirebaseAuth.instance.signOut();
    _user.value = null;
    update();
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../data/constants/theme.dart';
import '../../../../data/utils/logger.dart';

class DigitTextField extends StatefulWidget {
  final int digitCount;
  final ValueChanged<String> onChanged;
  final Function(String)? onComplete;

  const DigitTextField({
    super.key,
    required this.digitCount,
    required this.onChanged,
    this.onComplete,
  });

  @override
  DigitTextFieldState createState() => DigitTextFieldState();
}

class DigitTextFieldState extends State<DigitTextField> {
  late TextEditingController _controller;
  late FocusNode _focusNode;
  late List<String> digits;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController();
    _controller.addListener(() {
      if (_controller.text.length == widget.digitCount) {
        widget.onComplete?.call(_controller.text);
        logger.i("OTP Complete");
      }
    });
    digits = List.filled(widget.digitCount, '');

    _focusNode = FocusNode();
    _focusNode.addListener(_onFocusChanged);
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onFocusChanged() {
    if (_focusNode.hasFocus) {
      SystemChannels.textInput.invokeMethod('TextInput.show');
    }
  }

  void _onDigitChanged(int index, String value) {
    setState(() {
      digits[index] = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusScope.of(context).requestFocus(_focusNode);
      },
      child: SizedBox(
        width: 56.0 * widget.digitCount,
        height: 40.0,
        child: Stack(
          children: [
            Positioned.fill(
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: widget.digitCount,
                itemBuilder: (context, index) {
                  bool isFocused = false;
                  if (_focusNode.hasFocus && _controller.text.length == index) {
                    isFocused = true;
                  }
                  if (_focusNode.hasFocus &&
                      _controller.text.length == 6 &&
                      index == 5) {
                    isFocused = true;
                  }
                  return Container(
                    width: 40,
                    height: 40,
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: isFocused ? Colors.green : Colors.grey,
                        width: isFocused ? 2 : 1,
                      ),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      digits[index],
                      style: TextStyles.heading1
                          .copyWith(fontWeight: FontWeight.w400),
                    ),
                  );
                },
              ),
            ),
            AbsorbPointer(
              absorbing: true,
              child: TextFormField(
                controller: _controller,
                focusNode: _focusNode,
                autofocus: true,
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  if (value.length <= widget.digitCount) {
                    for (int i = 0; i < widget.digitCount; i++) {
                      String digit = (i < value.length) ? value[i] : '';
                      _onDigitChanged(i, digit);
                    }

                    widget.onChanged(digits.join());
                  } else {
                    _controller.text = value.substring(0, widget.digitCount);
                    _controller.selection = TextSelection.collapsed(
                      offset: widget.digitCount,
                    );
                  }
                },
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(widget.digitCount),
                ],
                style: const TextStyle(
                  color: Colors.transparent,
                  decoration: TextDecoration.none,
                ),
                decoration: const InputDecoration.collapsed(hintText: ""),
                showCursor: false,
                cursorColor: Colors.transparent,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:planty_homes/modules/login/views/components/digit_text_field.dart';

import '../../../global_components/primary_button.dart';
import '../controllers/login_controller.dart';

class OtpVerifyView extends GetView<LoginController> {
  const OtpVerifyView({Key? key}) : super(key: key);

  String formatDuration(int seconds) {
    DateTime duration = DateTime(0);
    duration = duration.add(Duration(seconds: seconds));
    return DateFormat("mm:ss").format(duration);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('OTP Verification'),
      ),
      floatingActionButton: Obx(() {
        bool loading = controller.verifyOtpLoading.value;
        return PrimaryButton(
          "Verify and login",
          width: double.infinity,
          // height: 75,
          onTap: controller.handleFinalVerify,
          color: loading ? Colors.grey : Colors.green,
          childOverride: loading
              ? const SizedBox.square(
                  dimension: 25,
                  child: CircularProgressIndicator(color: Colors.white))
              : null,
        );
      }),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
                padding: const EdgeInsets.only(top: 40),
                child: const Text(
                  "We have sent a Verification Code to",
                  style: TextStyle(
                    fontSize: 19,
                  ),
                )),
            Container(
              padding: const EdgeInsets.all(8),
              child: Text(
                "+${controller.currentPhoneCountry.value.dialCode} ${controller.phone.text}",
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
            ),
            const SizedBox(height: 30),
            Form(
              key: controller.otpFormKey,
              child: FittedBox(
                fit: BoxFit.cover,
                child: DigitTextField(
                  digitCount: controller.otpLength,
                  onChanged: controller.otp,
                  onComplete: (otp) => controller.handleFinalVerify(null, otp),
                ),
              ),
            ),
            const SizedBox(height: 40, width: double.infinity,),

            const Text("Didn't get verification code?"),
            Obx(() {
              final value = controller.smsSecondsRemaining.value;
              final isDisabled = value > 0;
              final formatted = formatDuration(value);
              var trailing = "";
              if (isDisabled) {
                trailing = " in $formatted";
              }
              // if (!controller.isLoading.value) {
              //   return const SizedBox.square(
              //       child: CircularProgressIndicator());
              // }
              return TextButton(
                onPressed: controller.handleResendOtp,
                style: ButtonStyle(
                  backgroundColor: MaterialStatePropertyAll(
                      isDisabled ? Colors.grey.shade100 : Colors.white),
                ),
                child: Text("Resend OTP$trailing"),
                // textStyle: TextStyles.body1,
                // color: isDisabled ? Colors.grey : Colors.green,
                // padding: const EdgeInsets.symmetric(
                //     vertical: 16, horizontal: 16),
                // childOverride: controller.isLoading.value
                //     ? const SizedBox.square(
                //         dimension: 20, child: CircularProgressIndicator())
                //     : null,
              );
            }),
            // Expanded(
            //   child: Obx(() {
            //     final value = controller.callSecondsRemaining.value;
            //     final isDisabled = value > 0;
            //     final formatted = formatDuration(value);
            //
            //     var trailing = "";
            //     if (isDisabled) {
            //       trailing = " in $formatted";
            //     }
            //     return PrimaryButton(
            //       "OTP Call$trailing",
            //       onTap: controller.handleResendOtp,
            //       textStyle: TextStyles.body1,
            //       color: isDisabled ? Colors.grey : Colors.green,
            //       padding: const EdgeInsets.symmetric(
            //           vertical: 16, horizontal: 16),
            //       childOverride: controller.isLoading.value
            //           ? const SizedBox.square(
            //               dimension: 20, child: CircularProgressIndicator())
            //           : null,
            //     );
            //   }),
            // ),

            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

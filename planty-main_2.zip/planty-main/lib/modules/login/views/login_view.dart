import 'package:planty_homes/global_components/primary_button.dart';

import '../../../data/constants/export.dart';

import '../controllers/login_controller.dart';

class LoginView extends GetView<LoginController> {
  const LoginView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: controller.loginFormKey,
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              _loginImage(),
              _loginHeading(),
              _loginOrSignupText(),
              const SizedBox(
                height: 20,
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border:
                              Border.all(color: Colors.black.withOpacity(.4))),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: () {},
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 12),
                          child: Text(
                            "${controller.currentPhoneCountry.value.flag}  +${controller.currentPhoneCountry.value.dialCode} ",
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w500),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: TextFormField(
                          controller: controller.phone,
                          validator: controller.validateNumber,
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(
                                controller.currentPhoneCountry.value.maxLength)
                          ],
                          style: const TextStyle(
                              fontWeight: FontWeight.w500, fontSize: 16),
                          decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderSide: const BorderSide(),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              contentPadding: const EdgeInsets.all(12)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                child: Obx(() {
                  return Row(
                    children: [
                      Expanded(
                        child: PrimaryButton("Log In",
                            color: controller.isLoading.value
                                ? Colors.grey
                                : Colors.green,
                            margin: EdgeInsets.zero,
                            onTap: () => controller.loginPageSubmit(false),
                            childOverride: controller.isLoading.value &&
                                    !controller.newUser.value
                                ? const SizedBox(
                                    width: 24,
                                    height: 24,
                                    child: CircularProgressIndicator(
                                        color: Colors.white))
                                : null),
                      ),
                      // const SizedBox(
                      //   width: 16,
                      // ),
                      // Expanded(
                      //   child: PrimaryButton("Create Account",
                      //       color: controller.isLoading.value
                      //           ? Colors.grey
                      //           : Colors.green,
                      //       margin: EdgeInsets.zero,
                      //       onTap: controller.loginPageSubmit,
                      //       childOverride: controller.isLoading.value &&
                      //               controller.newUser.value
                      //           ? const SizedBox(
                      //               width: 24,
                      //               height: 24,
                      //               child: CircularProgressIndicator(
                      //                   color: Colors.white))
                      //           : null),
                      // ),
                    ],
                  );
                }),
              ),
              const SizedBox(
                height: 20,
              ),
              // Row(children: [
              //   const Expanded(
              //       child: Divider(
              //     thickness: 2,
              //   )),
              //   const Text(
              //     "or",
              //     style: TextStyle(color: Colors.green),
              //   ).paddingSymmetric(horizontal: 3),
              //   const Expanded(
              //       child: Divider(
              //     thickness: 2,
              //   )),
              // ]).paddingSymmetric(horizontal: 35),
              // const SizedBox(
              //   height: 10,
              // ),
              // Container(
              //   height: 55,
              //   width: 55,
              //   decoration: BoxDecoration(
              //     border: Border.all(width: 1, color: Colors.grey),
              //     borderRadius: BorderRadius.circular(100),
              //   ),
              //   child: IconButton(
              //       onPressed: null,
              //       icon: Image.asset(
              //         'assets/icons/google_icon.png',
              //       )),
              // ),
              _stringLoginPolicy(),
              const SizedBox(height: 14),
              // Align(
              //   alignment: Alignment.bottomCenter,
              //   child: Text(
              //     stringLoginPolicy,
              //     style: const TextStyle(
              //       color: Colors.grey,
              //     ),
              //     textAlign: TextAlign.center,
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _loginImage() => SizedBox(
        height: Get.size.height * .4,
        width: Get.width,
        child: Image.asset(icPic, fit: BoxFit.cover),
      ).paddingOnly(bottom: margin_30);

  Widget _loginHeading() => Text(
        stringLoginHeading,
        style: TextStyles.heading1.copyWith(color: Colors.green),
        textAlign: TextAlign.center,
      ).paddingOnly(bottom: margin_30);

  Widget _stringLoginPolicy() => Align(
        alignment: Alignment.bottomCenter,
        child: Text(
          stringLoginPolicy,
          style: const TextStyle(
            color: Colors.grey,
          ),
          textAlign: TextAlign.center,
        ).paddingOnly(top: margin_20),
      );

  Widget _loginOrSignupText() => Row(children: [
        const Expanded(
            child: Divider(
          thickness: margin_2,
          color: dividerColor,
        )),
        Text(
          stringLoginOrSignup,
          style: themeData.textTheme.bodySmall?.copyWith(color: appColor),
        ).paddingSymmetric(horizontal: 3),
        const Expanded(
            child: Divider(
          thickness: margin_2,
          color: dividerColor,
        )),
      ]).paddingSymmetric(
        horizontal: margin_15,
      );
}

import 'package:get/get.dart';
import 'package:planty_homes/data/services/auth_service.dart';

import '../controllers/login_controller.dart';

class LoginBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(AuthSignService());
    Get.lazyPut<LoginController>(
      () => LoginController(),
    );
  }
}

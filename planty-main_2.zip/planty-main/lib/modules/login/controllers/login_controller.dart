import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart' hide User;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/controllers/user_controller.dart';
import 'package:planty_homes/data/services/auth_service.dart';
import 'package:planty_homes/data/utils/snackbar.dart';
import 'package:planty_homes/routes/app_pages.dart';
import 'package:planty_homes/utils/countries.dart';

import '../../../data/models/user_model.dart';
import '../../../data/utils/logger.dart';
import '../bindings/login_binding.dart';
import '../views/otp_verify_view.dart';

const startingTime = 60;

class LoginController extends GetxController {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final authServer = Get.find<AuthSignService>();
  final userController = Get.find<UserController>();
  final otpLength = 6;

  var verificId = Rx<String?>(null);
  var rensendVerificToken = Rx<int?>(null);

  var loginFormKey = GlobalKey<FormState>();
  var otpFormKey = GlobalKey<FormState>();
  var currentPhoneCountry = countries[99].obs;
  var phone = TextEditingController();
  var email = ''.obs;
  var otp = "".obs;

  var isLoading = false.obs;
  var verifyOtpLoading = false.obs;

  var newUser = false.obs;

  Timer? _smsTimer;
  Timer? _callTimer;

  RxInt smsSecondsRemaining = 0.obs;
  RxInt callSecondsRemaining = 0.obs;

  String? validateNumber(String? number) {
    if (number == null || number.isEmpty) {
      return "number cannot be empty";
    }
    final country = currentPhoneCountry.value;
    if (country.minLength > number.length) {
      return "Number is too short.";
    } else if (country.maxLength < number.length) {
      return "Number is too long.";
    }
    return null;
  }

  Future<void> verifyPhoneNumber(String phoneNumber, [isResend = false]) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      timeout: const Duration(seconds: startingTime),
      verificationCompleted: (PhoneAuthCredential credential) async {
        isLoading(false);
      },
      verificationFailed: (FirebaseAuthException e) {
        SnackBarHelper.showError(
            e.message ?? "Something went wrong while requesting otp");
        isLoading(false);
      },
      codeSent: (String verificationId, int? resendToken) {
        verificId(verificationId);
        rensendVerificToken(resendToken);
        SnackBarHelper.showSuccess("Verification code sent");
        isLoading(false);
        if (!isResend) Get.to(const OtpVerifyView(), binding: LoginBinding());
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        isLoading(false);
      },
    );
  }

  Future<void> signInWithPhoneNumber(
      String verificationId, String smsCode) async {
    PhoneAuthCredential credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );

    try {
      final uuser = await _auth.signInWithCredential(credential);
      logger.i('Phone number authentication successful $uuser');
      logger.i(uuser.user);
      if (uuser.user != null) {
        final user = uuser.user!;
        userController.setUser(User(
          uid: user.uid,
          phone: user.phoneNumber,
          countryCode: currentPhoneCountry.value.dialCode.toString(),
          name: "",
        ));
      }
      isLoading(false);
      if (uuser.user?.displayName != null) {
        Get.offAllNamed(Routes.HOME);
      } else if (uuser.user != null) {
        Get.offAllNamed(Routes.EDIT_PROFILE);
      } else {
        SnackBarHelper.showError(
            "Cannot verify user you may need to login again.");
      }
    } catch (e) {
      SnackBarHelper.showError("Failed to Authenticate: $e");
      print('Phone number authentication failed: ${e.toString()}');
    }
  }

  // ! warning: do not call this function when the form is out of scope
  void loginPageSubmit([bool isNewUser = true]) async {
    newUser(isNewUser);
    final isValid = loginFormKey.currentState!.validate();
    if (isValid) {
      isLoading(true);
      await verifyPhoneNumber(
          "+${currentPhoneCountry.value.dialCode}${phone.text}");
      resetTimer(TimerType.sms);
    }
  }

  @override
  void onInit() {
    super.onInit();
    resetTimer(TimerType.sms);
  }

  @override
  void onClose() {
    phone.dispose();
    super.onClose();
  }

  void startTimer(TimerType type) {
    if (type == TimerType.sms) {
      _smsTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (smsSecondsRemaining > 0) {
          smsSecondsRemaining--;
        } else {
          stopTimer(type);
        }
      });
    } else {
      _callTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (callSecondsRemaining > 0) {
          callSecondsRemaining--;
        } else {
          stopTimer(type);
        }
      });
    }
  }

  void stopTimer(TimerType type) {
    if (type == TimerType.sms) _smsTimer?.cancel();
    if (type == TimerType.call) _callTimer?.cancel();
  }

  void resetTimer(TimerType type) {
    stopTimer(type);
    if (type == TimerType.sms) {
      smsSecondsRemaining.value = startingTime;
    } else {
      callSecondsRemaining.value = startingTime;
    }
    startTimer(type);
  }

  void handleResendOtp() async {
    if (smsSecondsRemaining.value == 0) {
      isLoading(true);
      await Future.delayed(const Duration(milliseconds: 600));
      logger.e(phone.text);
      await verifyPhoneNumber(phone.text, true);
      resetTimer(TimerType.sms);
      isLoading(false);
    } else {
      SnackBarHelper.showError("You need to wait for timer to finish");
    }
  }

  void handleResendCall() {
    logger.i("handle resend call");
    if (callSecondsRemaining.value == 0) resetTimer(TimerType.call);
  }

  void handleFinalVerify([String? number, String? otp]) async {
    if (verifyOtpLoading.value) return;
    if (verificId.value == null) {
      SnackBarHelper.showError("Something went wrong you need to relogin");
      return;
    }

    if (otp?.length == otpLength || this.otp.value.length == otpLength) {
      verifyOtpLoading(true);
      await signInWithPhoneNumber(verificId.value!, otp ?? this.otp.value);
      verifyOtpLoading(false);
    } else {
      SnackBarHelper.showError("OTP must contain $otpLength digits");
    }
  }
}

enum TimerType { call, sms }

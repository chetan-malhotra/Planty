class Coupon {
  String title;
  String code;
  String? subtitle;
  String? description;
  List<Coupon>? children;

  Coupon({
    required this.title,
    required this.code,
    this.subtitle,
    this.description,
    this.children,
  });

  factory Coupon.fromJson(Map<String, dynamic> json) {
    return Coupon(
      title: json['title'] ?? "",
      code: json['code'] ?? "",
      subtitle: json['subtitle'] ?? "",
      description: json['description'] ?? "",
      children: json['children'] != null
          ? List<Coupon>.from(
              json['children'].map((childJson) => Coupon.fromJson(childJson)))
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'code': code,
      'subtitle': subtitle,
      'description': description,
      'children': children?.map((child) => child.toJson()).toList(),
    };
  }
}

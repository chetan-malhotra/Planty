import 'package:get/get.dart';

import '../models/coupon_model.dart';

class CouponsController extends GetxController {
  var coupons = [
    Coupon(
        title: "MobiKwik",
        subtitle: "Upto Rs. 100 MobiKwik cashback",
        code: "HARITA_HARAM"),
    Coupon(
      title: "Flat Rs.100 OFF",
      subtitle: "Save Rs.100 with this code",
      code: "PLANTY_20",
    ),
    Coupon(
      title: "20% OFF upto Rs.50",
      subtitle: "Add items worth Rs.49 or more",
      code: "GOGREEN",
    ),
    Coupon(
        title: "Fi",
        subtitle: "20% upto Rs.75 OFF",
        code: "FI_23432",
        children: [
          Coupon(
            title: "testing",
            code: "Yo",
          ),
        ]),
  ].obs;



}

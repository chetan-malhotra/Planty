import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:planty_homes/modules/orders/coupons/models/coupon_model.dart';

import '../controllers/coupons_controller.dart';

class CouponsView extends GetView<CouponsController> {
  const CouponsView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Coupan for you",
        ),
        foregroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        child: Obx(() {
          return Column(children: [
            for (final coupon in controller.coupons) CouponCard(coupon),
          ]);
        }),
      ),
    );
  }
}

class CouponCard extends StatelessWidget {
  const CouponCard(
    this.coupon, {
    super.key,
  });

  final Coupon coupon;

  @override
  Widget build(BuildContext context) {
    final showChildren = coupon.children != null && coupon.children!.isNotEmpty;
    return Container(
      margin: const EdgeInsets.all(16),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(.1), blurRadius: 4)
          ]),
      child: showChildren
          ? ExpansionTile(
              shape: const RoundedRectangleBorder(side: BorderSide.none),
              title: Text(
                coupon.title,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              ),
              subtitle: coupon.subtitle != null
                  ? Text(
                      coupon.subtitle!,
                      style: const TextStyle(color: Colors.blue),
                    )
                  : null,
              leading: const Icon(
                Symbols.local_offer,
                fill: 1,
                color: Colors.blue,
              ),
              children: [
                ListTile(
                    title: Row(children: [
                  Text(
                    coupon.code,
                    style: const TextStyle(fontSize: 16),
                  )
                ]))
              ],
            )
          : Column(children: [
              Row(
                children: [
                  const SizedBox(width: 12),
                  const Icon(Symbols.local_offer, fill: 1, size: 24),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Text(
                        coupon.title,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w600),
                      ),
                    ),
                  )
                ],
              ),
              if (coupon.subtitle != null)
                Container(
                  width: double.infinity,
                  // this padding is calculated from the above widget
                  padding: const EdgeInsets.only(left: 12 + 24 + 6),
                  child: Text(
                    coupon.subtitle!,
                    style: const TextStyle(
                        color: Colors.blue, fontWeight: FontWeight.w400),
                  ),
                ),
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                shape: const RoundedRectangleBorder(side: BorderSide.none),
                collapsedShape:
                    const RoundedRectangleBorder(side: BorderSide.none),
                title: Row(
                  children: [
                    const SizedBox(width: 24 + 12 + 6),
                    Container(
                      decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.grey.withOpacity(.4),
                          ),
                          borderRadius: BorderRadius.circular(4)),
                      padding: const EdgeInsets.all(4),
                      child: Text(
                        coupon.code,
                        style: const TextStyle(fontSize: 12),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.all(4),
                        child: const FittedBox(
                          child: Text(
                            "View Details",
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () {},
                  style: ButtonStyle(
                    shape: const MaterialStatePropertyAll(
                        RoundedRectangleBorder(
                            borderRadius: BorderRadius.vertical(
                                bottom: Radius.circular(12)))),
                    padding: const MaterialStatePropertyAll(EdgeInsets.all(18)),
                    backgroundColor:
                        MaterialStatePropertyAll(Colors.blueGrey.shade50),
                  ),
                  child: const Text(
                    "TAP TO APPLY",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      letterSpacing: 2
                    ),
                  ),
                ),
              )
            ]),
    );
  }
}

import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:planty_homes/data/constants/theme.dart';
import 'package:planty_homes/modules/cart/views/cart_view.dart';
import 'package:planty_homes/modules/orders/models/prev_orders_model.dart';

import '../../../data/models/address_model.dart';
import '../../../data/models/order_model.dart';

class OrderItemView extends GetView {
  const OrderItemView(this.orders, {Key? key}) : super(key: key);

  final PrevOrder orders;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('OrderItemsView'),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Column(children: [
            ..._render(),
            OrderSummary(orders.orders)
          ]),
        ));
  }

  List<Widget> _render() {
    final list = <Widget>[];
    for (final order in orders.orders) {
      list.add(CartItemView(
        order,
        delivery: orders.delivery,
      ));
    }
    return list;
  }
}

class CartItemView extends StatelessWidget {
  const CartItemView(
    this.order, {
    super.key,
    this.delivery,
  });

  final Order order;
  final Address? delivery;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.all(16),
      clipBehavior: Clip.antiAlias,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(.1), blurRadius: 16),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              SizedBox(
                width: 100,
                height: 110,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: const SizedBox.expand(
                    child: Image(
                      image: AssetImage("assets/green plant.jpg"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Expanded(
                flex: 3,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        order.plant.name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        order.delivery?.to.toString() ??
                            delivery?.toString() ??
                            "UNKNOWN ADDRESS",
                        maxLines: 1,
                        softWrap: false,
                        overflow: TextOverflow.fade,
                      ),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            vertical: 2, horizontal: 4),
                        decoration: BoxDecoration(
                            color: Colors.green.shade200,
                            borderRadius: BorderRadius.circular(4)),
                        child: Text(
                          order.status.name,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w400),
                        ),
                      ),
                      // Row(
                      //   children: [
                      //     RatingBarIndicator(
                      //         rating: order.plant.rating,
                      //         itemSize: 16,
                      //         unratedColor: Colors.grey,
                      //         itemBuilder: (c, i) => const Icon(
                      //               Symbols.star_rounded,
                      //               fill: 1,
                      //               color: Colors.green,
                      //             )),
                      //     Text(" (${order.plant.ratingCount.toString()})"),
                      //   ],
                      // ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            "₹ ${order.price}",
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w600),
                          ),
                          Text(
                            "Quantity: ${order.count}",
                            style: TextStyles.body1,
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:planty_homes/modules/orders/views/components/order_info_sheet.dart';
import 'package:planty_homes/modules/orders/views/order_items_view.dart';

import '../../../data/constants/theme.dart';
import '../../../data/utils/logger.dart';
import '../controllers/orders_controller.dart';
import '../models/prev_orders_model.dart';

class OrdersView extends GetView<OrdersController> {
  const OrdersView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Orders'),
        bottom: PreferredSize(
          preferredSize: const Size(double.infinity, 70),
          child: Column(children: [
            Container(
              height: 65,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: SearchBar(
                elevation: const MaterialStatePropertyAll(0),
                leading: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 0, horizontal: 8),
                  child: Icon(Icons.search),
                ),
                backgroundColor: MaterialStatePropertyAll(Colors.grey.shade300),
                hintText: "Search...",
                textStyle:
                    const MaterialStatePropertyAll(TextStyle(height: 1.15)),
                hintStyle: const MaterialStatePropertyAll(TextStyle(height: 1)),
                shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12))),
              ),
            ),
          ]),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: controller.refreshOrders,
        child: Obx(() {
          if (controller.isLoading.value) {
            return const Center(
              child: SizedBox.square(
                dimension: 40,
                child: CircularProgressIndicator(),
              ),
            );
          }
          return ListView.builder(
            itemCount: controller.previousOrders.length,
            itemBuilder: (ctx, index) {
              return PrevOrderItem(
                controller.previousOrders[index],
                onTap: () {
                  Get.to(OrderItemView(controller.previousOrders[index]));
                },
              );
            },
          );
        }),
      ),
      // const Text(
      //   'Nothing is here yet.',
      //   style: TextStyle(fontSize: 20),
      // ),
      // FilledButton(
      //     onPressed: () {
      //       Get.to(const CheckoutView());
      //     },
      //     child: const Text("Go To Checkout")),
      // const SizedBox(height: 12),
      // FilledButton(
      //   onPressed: () {
      //     Get.to(const CouponsView(), binding: CouponsBinding());
      //   },
      //   child: const Text("go to coupons"),
      // ),
      // ],
      // ),
    );
  }
}

class PrevOrderItem extends StatelessWidget {
  const PrevOrderItem(
    this.order, {
    super.key,
    this.onTap,
  });

  final Function()? onTap;
  final PrevOrder order;

  @override
  Widget build(BuildContext context) {
    final date = DateFormat("dd-mm-yyyy HH:MM:SS").format(order.createdAt);
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 140,
        padding: const EdgeInsets.all(18),
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.blueGrey.shade200)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
                order.orders.fold("", (p, e) {
                  if (p.isEmpty) return e.plant.name;
                  return "$p, ${e.plant.name}";
                }),
                softWrap: false,
                style:
                    TextStyles.heading3.copyWith(overflow: TextOverflow.fade)),
            Text("ID: ${order.id}",
                maxLines: 2,
                style: TextStyles.body1.copyWith(overflow: TextOverflow.fade)),
            const Spacer(),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text("types of plants: ${order.orders.length}"),
              Text(
                "TOTAL: ₹${order.orders.fold(50, (p, e) {
                  return p + (e.plant.price * e.count);
                })}",
                style: TextStyles.heading3,
              ),
              // FittedBox(
              //   child: Container(
              //     margin: const EdgeInsets.symmetric(vertical: 4),
              //     padding:
              //         const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              //     decoration: BoxDecoration(
              //         color: Colors.blueGrey.shade100,
              //         borderRadius: BorderRadius.circular(8)),
              //     child: Text(order.),
              //   ),
              // ),
            ])
          ],
        ),
      ),
    );

    // return ListTile(
    //   visualDensity: const VisualDensity(vertical: 4),
    //   leading: const AspectRatio(
    //     aspectRatio: 1,
    //       child: Image(
    //        image: AssetImage("assets/images/palm.jpg"),
    //         fit: BoxFit.cover,
    //     ),
    //   ),
    //   title: const Text("Palm Plant", style: TextStyles.heading3),
    //   onTap: () {},
    //   subtitle: Column(
    //     crossAxisAlignment: CrossAxisAlignment.start,
    //     children: [
    //       Container(
    //         padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
    //         decoration: BoxDecoration(
    //           color: Colors.blueGrey.shade100,
    //           borderRadius: BorderRadius.circular(6),
    //         ),
    //         child: const Text(
    //           "Delivered",
    //           style: TextStyles.body1,
    //         ),
    //       ),
    //       SizedBox(height: 12),
    //       Text(
    //         "Home, James Street, Kali City, Chandigarh, 502830",
    //         softWrap: false,
    //         style: TextStyles.body1.copyWith(
    //           color: Colors.grey,
    //           overflow: TextOverflow.fade,
    //         ),
    //       ),
    //     ],
    //   ),
    // );
  }
}

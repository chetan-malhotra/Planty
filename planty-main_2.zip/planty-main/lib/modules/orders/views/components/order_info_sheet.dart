import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/data/constants/theme.dart';

class OrderInfoSheet extends StatelessWidget {
  const OrderInfoSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return BottomSheet(
      onClosing: Get.back,
      builder: (context) {
        return SingleChildScrollView(
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Order Details",
                  style: TextStyles.heading1,
                ),
                SizedBox(height: 12),
                Text("Palm Plant", style: TextStyles.heading2),
                Text("Deliver to:"),
              ],
            ),
          ),
        );
      },
    );
  }
}

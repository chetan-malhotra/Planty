import 'package:planty_homes/data/utils/server_utils.dart';

import '../../../data/utils/logger.dart';
import '../models/prev_orders_model.dart';

class OrdersServer extends NewServer {
  Future<Result<List<PrevOrder>?>> getPreviousOrders(
      int skip, int limit) async {
    final res = await handlePostRequest("/api/getOrders", {
      'skip': skip,
      'limit': limit,
    });

    if (!res.isPass) return Result.fail(res.msg);

    if (res.data == null) {
      return Result.fail("No orders found. The error maybe is from server.");
    }

    try {
      final data = res.data;
      final orders = <PrevOrder>[];
      for (final item in data) {
        final newOrder = PrevOrder.fromServer(item);
        orders.add(newOrder);
      }
      print(orders);
      return Result.pass("Fetched Orders successfully", orders);
    } catch (error) {
      logger.i(error);
      return Result.fail("Error while handling response. $error");
    }
  }
}

import 'package:planty_homes/data/models/address_model.dart';

import '../../../../data/models/order_model.dart';

class PrevOrder {
  String id;
  DateTime createdAt;
  String? orderId;
  String? signature;
  String? paymentId;
  bool cod;
  Address delivery;
  List<Order> orders;

  PrevOrder({
    required this.id,
    DateTime? createdAt,
    this.orderId,
    this.signature,
    this.paymentId,
    required this.cod,
    required this.delivery,
    required this.orders,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'createdAt': createdAt,
      'orderId': orderId,
      'signature': signature,
      'paymentId': paymentId,
      'cod': cod,
      'delivery': delivery.toJson(),
      'orders': orders.map((order) => order.toJson()).toList(),
    };
  }

  Map<String, dynamic> toServer() {
    return {
      'signature': signature,
      'paymentId': paymentId,
      'cod': cod,
      'delivery': delivery.toJson(),
      'cartItems': orders.map((order) => order.toServer()).toList(),
    };
  }

  factory PrevOrder.fromJson(Map<String, dynamic> json) {
    return PrevOrder(
      id: json['id'] ?? "",
      createdAt: json["createdAt"],
      orderId: json['orderId'] ?? json['id'],
      signature: json['signature'],
      paymentId: json['paymentId'],
      cod: json['cod'] ?? true,
      delivery: Address.fromJson(json['delivery']),
      orders: List<Order>.from(
          json['orders'].map((orderJson) => Order.fromJson(orderJson))),
    );
  }

  factory PrevOrder.fromServer(Map<String, dynamic> json) {
    return PrevOrder(
      id: json['id'] ?? "",
      createdAt: DateTime.parse(json["createdAt"]),
      orderId: json['orderId'] ?? json["id"] ?? "",
      signature: json['signature'],
      paymentId: json['paymentId'],
      cod: json['cod'] ?? true,
      delivery: Address.fromJson(json['delivery']),
      orders: List<Order>.from(
          json['cartItems'].map((orderJson) => Order.fromJson(orderJson))),
    );
  }
}

import 'package:get/get.dart';
import 'package:planty_homes/data/utils/snackbar.dart';
import 'package:planty_homes/modules/orders/models/prev_orders_model.dart';
import 'package:planty_homes/modules/orders/services/previous_orders_api.dart';

class OrdersController extends GetxController {
  var previousOrders = <PrevOrder>[].obs;
  var server = Get.find<OrdersServer>();

  var isLoading = false.obs;

  // Pagination
  final limit = 10;
  var skip = 0.obs;

  Future<void> refreshOrders() async {
    isLoading(true);
    final result = await server.getPreviousOrders(skip.value, limit);
    if (!result.isPass) {
      SnackBarHelper.showError(result.msg);
      isLoading(false);
      return;
    }

    if (result.data == null) {
      SnackBarHelper.showError("No orders found");
      isLoading(false);
      return;
    }

    previousOrders.removeRange(0, previousOrders.length);
    previousOrders.addAll(result.data!);
    isLoading(false);
  }

  @override
  void onInit() {
    refreshOrders();
    super.onInit();
  }
}

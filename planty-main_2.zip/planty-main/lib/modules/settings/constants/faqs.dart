

class FAQ {
  String question;
  String answer;
  FAQ(this.question, this.answer);
}

final faqs = [
  FAQ(
    "Is Cash On Delivery available on Planty App?",
    "Yes. We offer Cash On Delivery as well along with other payment methods as well like Credit/Debit cards, UPI payments, Wallets etc."
  ),
  FAQ(
    "Can I return/replace my plant order placed from Planty app?",
    "For now, there is no facility of returning or replacing your plant order. As Planty Homes team, we ensure that good quality plants or products gets delivered to you."
  ),
  FAQ(
    "How can I reach out to the Customer Care for discussing any concerns?",
    "You can reach out to us at our number 9464210784 for any help/support which is required regarding your order or any other query. We will try to resolve your query at the earliest."
  ),
  FAQ(
    "I forgot my Planty login password, how can I reset my password for logging in successfully?",
    "You can reset your password by clicking here.(hyperlink to be added which will redirect to forgot password). Enter your registered email ID or mobile number, and click on Submit. You will receive a link on your mail id to reset your password."
  ),
  FAQ(
    "I want to gift the ordered plant to someone. Is there an option to gift pack my order?",
    "Yes. You can now get your plant buddies wrapped in a beautiful packaging. We will gift pack your order if you want."
  ),
  FAQ(
    "Are gifting plants also available on your app?",
    "Yes. We have gifting category as well in our Planty app. Along with this, we have flower plants, fruits plants, vegetable plants, ceramic plants, hanging plants, medicinal plants, spice plants, water plants, astrological plants, vastu related plants, interior designing plants, green plants and regional plants also in our plants categories."
  ),
  FAQ(
    "Can I add delivery instructions for my order?",
    "You can add delivery instructions while placing the order. You can record your instructions or you can select from the options provided."
  ),
  FAQ(
    "I don’t know the name of my nearby nursery. How can I find it on app while ordering plants?",
    "You can find your nearby nurseries in the “Nurseries around you” section on the app. This will suggest you all the nurseries which are located in your nearby locations. So no stress of remembering the nursery name."
  ),
  FAQ(
    "How can I update my contact information and address?",
    "You can update your contact information and address by clicking here.(hyperlink to be added for the profile) You can click on Change to update your information. Then tap on Update Profile to save the updated information."
  ),
  FAQ(
    "Can I login using my Google account?",
    "Yes. You can login into the Planty app by using your Google account as well."
  ),
];

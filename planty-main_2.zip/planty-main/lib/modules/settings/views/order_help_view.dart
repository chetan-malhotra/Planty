import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:planty_homes/modules/settings/controllers/settings_controller.dart';

class OrderHelpView extends GetView<SettingsController> {
  const OrderHelpView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      elevation: 0,
      title: const Text("Help"),
      content: SizedBox(
        height: 120,
        child: Column(children: [
          const Text(
              "You can get help via the contact number, or through the whatsapp."),
          const Spacer(),
          Row(
            children: [
              TextButton(
                onPressed: () => controller.handleCallHelp(),
                child: const Text("+91 1234567890"),
              ),
              TextButton(
                onPressed: () => controller.handleWhatsappHelp(),
                child: const Text("WhatsApp"),
              )
            ],
          ),
        ]),
      ),
    );
  }
}

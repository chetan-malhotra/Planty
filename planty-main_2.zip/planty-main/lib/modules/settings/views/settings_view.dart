import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/settings_controller.dart';
import 'components/green_rating.dart';
import 'components/profile_card.dart';
import 'components/settings_card.dart';

class SettingsView extends GetView<SettingsController> {
  const SettingsView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(4),
        child: ListView(
          children: [
            ProfileCard(onTap: () {
              Get.toNamed("/edit-profile");
            }),
            const GreenStarRatingCard(),
            for (final settings in controller.settingsList)
              SettingsMenuCard(settings),
            const SizedBox(height: 26),
          ],
        ),
      ),
    );
  }
}

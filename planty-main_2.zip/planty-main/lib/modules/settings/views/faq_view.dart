import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:planty_homes/data/constants/theme.dart';
import 'package:planty_homes/modules/settings/constants/faqs.dart';
import 'package:planty_homes/modules/settings/views/order_help_view.dart';

class FaqView extends GetView {
  const FaqView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Frequently Asked Question"),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              const SizedBox(height: 10),
              const Text(
                "FAQs",
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              for (int i = 0; i < faqs.length; i++)
                ExpansionTile(
                  leading: Text(
                    (i + 1).toString(),
                    style: TextStyles.body1,
                  ),
                  title: Text(
                    faqs[i].question,
                    style: const TextStyle(color: Colors.black),
                  ),
                  expandedAlignment: Alignment.topLeft,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 8, horizontal: 16),
                      child: Text(
                        faqs[i].answer,
                        style: const TextStyle(fontWeight: FontWeight.normal),
                      ),
                    )
                  ],
                ),
              ListTile(
              contentPadding: const EdgeInsets.all(18),
                onTap: () {
                  Get.dialog(const OrderHelpView());
                },
                leading: const Icon(Icons.call),
                title: const Text("Need help? Call us"),
              ),
            ],

            // child: ListView.builder(
            //   itemCount: 10,
            //   itemBuilder: (context, index) {
            //     return DropdownButtonFormField(items: items, onChanged: onChanged)
            //   },
            // ),
          ),
        ),
      ),
    );
  }
}

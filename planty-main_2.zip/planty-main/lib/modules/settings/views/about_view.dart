import 'package:flutter/material.dart';

import 'package:get/get.dart';

class AboutView extends GetView {
  const AboutView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About'),
        centerTitle: true,
      ),
      body: const SingleChildScrollView(
        child: Column(children: [
          SizedBox(
            width: 200,
            child: Image(
              image: AssetImage("assets/1024.png"),
              fit: BoxFit.cover,
            ),
          ),
          // Titled("Discover Planty, the app by Planty homes pvt. Ltd."),
          Padding(
            padding: EdgeInsets.all(18.0),
            child: Text(
                """Planty, an app by Planty Homes Pvt. Ltd. aims at connecting the nurseries directly with plant enthusiasts. Our app offers a platform where people can buy plants online from their choice of nursery. 
Not only plants, nurseries can sell all their plant related products under their brand name. We as Planty Homes team, are dedicated towards making this Earth a better place and
also giving back to the environment. 
We believe in nurturing our green spaces and bringing greenery to your homes and gardens. With Planty app, nurseries can effortlessly showcase their unique products and reach out to a wider audience.

On our app, plant enthusiasts can explore a wide variety of plants like flower plants, vegetables plants, vastu related plants, water plants, ceramic plants, gifting plants and many more. 
Join us in our initiative to create a greener tomorrow while supporting local nurseries."""),
          ),
        ]),
      ),
    );
  }
}

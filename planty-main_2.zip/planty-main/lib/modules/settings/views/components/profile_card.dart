import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../controllers/user_controller.dart';

class ProfileCard extends GetView<UserController> {
  const ProfileCard({super.key, this.onTap});

  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.all(12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            color: Colors.white,
            boxShadow: [
              BoxShadow(blurRadius: 8, color: Colors.black.withOpacity(.1))
            ]),
        child: Row(children: [
          Expanded(
              flex: 2,
              child: Obx(() {
                final user = controller.user;
                var name = "No Name";
                var contact = "No Contact";
                if (user?.name.isNotEmpty == true) name = user!.name;
                if (user?.phone?.isNotEmpty == true) {
                  if (user?.countryCode?.isNotEmpty == true) {
                    contact = "+${user!.countryCode} ${user.phone}";
                  } else {
                    contact = user!.phone!;
                  }
                } else if (user?.email?.isNotEmpty == true) {
                  contact = user!.email!;
                }

                return Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      contact,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(height: 12)
                  ],
                );
              })),
          const Expanded(
              child: Icon(
            Icons.verified_user_outlined,
            size: 100,
          ))
        ]),
      ),
    );
  }
}

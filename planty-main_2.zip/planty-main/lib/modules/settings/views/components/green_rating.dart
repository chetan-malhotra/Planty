import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/modules/settings/views/green_star_view.dart';

class GreenStarRatingCard extends StatelessWidget {
  const GreenStarRatingCard({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () {
        Get.dialog(
          const GreenStarView(),
          barrierColor: Colors.black.withOpacity(.5)
        );
      },
      child: Container(
          width: double.infinity,
          margin: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(blurRadius: 8, color: Colors.black.withOpacity(.1))
              ]),
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(.4),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.star_outline_rounded,
                ),
              ),
              const Text(
                "Green Star Rating",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              ),
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: Colors.grey.withOpacity(.3)),
                child: const Row(
                  children: [
                    Text(
                      "4.9",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    Icon(
                      Icons.star_rounded,
                      size: 16,
                      color: Colors.amber,
                    )
                  ],
                ),
              ),
              const Icon(Icons.navigate_next_rounded)
            ],
          )),
    );
  }
}

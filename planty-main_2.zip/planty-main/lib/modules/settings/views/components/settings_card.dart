import 'package:flutter/material.dart';

import '../../models/settings_model.dart';

class SettingsMenuCard extends StatelessWidget {
  const SettingsMenuCard(
    this.settings, {
    super.key,
  });

  final Settings settings;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 16),
      margin: const EdgeInsets.all(8),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: Colors.white,
          boxShadow: [
            BoxShadow(blurRadius: 8, color: Colors.black.withOpacity(.1))
          ]),
      child: Column(children: [
        Row(
          children: [
            Container(
              width: 6,
              height: 26,
              decoration: const BoxDecoration(
                borderRadius:
                    BorderRadius.horizontal(right: Radius.circular(12)),
                color: Colors.green,
              ),
            ),
            const SizedBox(width: 16),
            Text(
              settings.title,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 22,
              ),
            )
          ],
        ),
        const SizedBox(height: 16),
        ..._renderNext(),
      ]),
    );
  }

  List<Widget> _renderNext() {
    final children = settings.children;
    if (children != null) {
      return children.map((e) => SettingsMenuItem(e)).toList();
    }
    return [const SizedBox(height: 5)];
  }
}

class SettingsMenuItem extends StatelessWidget {
  const SettingsMenuItem(
    this.settings, {
    super.key,
  });

  final Settings settings;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: settings.onTap,
      leading: Container(
        decoration: BoxDecoration(
            color: Colors.grey.withOpacity(.2),
            borderRadius: BorderRadius.circular(24)),
        padding: const EdgeInsets.all(8),
        child: Theme(
          data: Theme.of(context)
              .copyWith(iconTheme: const IconThemeData(color: Colors.green)),
          child: settings.icon ??
              const Icon(
                Icons.three_p,
                color: Colors.green,
              ),
        ),
      ),
      title: Text(
        settings.title,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
      ),
      visualDensity: const VisualDensity(horizontal: 1),
      trailing: const Icon(Icons.navigate_next_rounded),
    );
  }
}

import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:planty_homes/controllers/user_controller.dart';
import 'package:planty_homes/data/constants/theme.dart';
import 'package:planty_homes/global_components/primary_button.dart';
import 'package:planty_homes/routes/app_pages.dart';

class LogoutDialogView extends GetView {
  LogoutDialogView({Key? key}) : super(key: key);
  final userController = Get.find<UserController>();
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text(
        "Are you sure?",
        style: TextStyles.heading1,
      ),
      elevation: 0,
      content: const Text(
        "You will be logged out and to access the app you need to login with a different account or the same account",
      ),
      actions: [
        PrimaryButton(
          "Yes Log Out!",
          color: Colors.redAccent,
          onTap: () {
            userController.logout();
            Get.offAllNamed(Routes.LOGIN);
          },
        )
      ],
    );
  }
}

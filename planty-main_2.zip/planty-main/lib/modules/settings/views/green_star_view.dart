import 'dart:ui';

import 'package:flutter/material.dart';

import 'package:get/get.dart';

class GreenStarView extends GetView {
  const GreenStarView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaY: 4, sigmaX: 4),
      child: Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        shadowColor: Colors.transparent,
        child: Container(
          width: double.infinity,
          height: 240,
          margin: const EdgeInsets.symmetric(vertical: 24),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: Colors.transparent),
          clipBehavior: Clip.antiAlias,
          child: Stack(
            children: [
              Positioned(
                top: 18,
                left: 18,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(sigmaY: 25, sigmaX: 25),
                  child: Container(
                    width: 120,
                    height: 120,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [
                        Color(0xff3EA85B),
                        Color(0xff32B18B),
                      ]),
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 18,
                right: 18,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(sigmaY: 25, sigmaX: 25),
                  child: Container(
                    width: 120,
                    height: 120,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [
                        Color(0xff41FFFF),
                        Color(0xff83FF37),
                      ]),
                    ),
                  ),
                ),
              ),
              BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 8, sigmaY: 10),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: const Color(0xff20BF4C).withOpacity(.3),
                    border: Border.all(color: Colors.green)
                  ),
                  padding: const EdgeInsets.only(right: 18),
                  alignment: Alignment.center,
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "HOLD ON,\nWE ARE",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 32),
                      ),
                      Text(
                        "WORKING",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 42),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}



import 'package:flutter/material.dart';

class Settings {
  String title;
  Widget? icon;
  Widget? trailing;
  List<Settings>? children;
  void Function()? onTap;

  Settings(this.title,{this.children, this.icon, this.trailing, this.onTap}); 
}

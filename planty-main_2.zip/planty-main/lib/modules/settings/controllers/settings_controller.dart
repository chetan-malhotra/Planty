import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/modules/settings/views/faq_view.dart';
import 'package:planty_homes/modules/settings/views/order_help_view.dart';
import 'package:planty_homes/routes/app_pages.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/settings_model.dart';
import '../views/about_view.dart';
import '../views/components/logout_dialog_view.dart';

class SettingsController extends GetxController {
  final settingsList = [
    Settings("Orders", children: [
      Settings("Your orders",
          onTap: () => Get.toNamed(Routes.ORDERS),
          icon: const Icon(Icons.yard_rounded)),
      // Settings(
      //   "Bookmarked nurseries",
      //   icon: const Icon(Icons.bookmark_rounded),
      // ),
      // Settings(
      //   "Address book",
      //   icon: const Icon(Icons.perm_contact_calendar),
      // ),
      Settings(
        "Ordering help",
        onTap: () {
          Get.dialog(const OrderHelpView());
        },
        icon: const Icon(Icons.phone_rounded),
      ),
      // Settings(
      //   "Partner programme",
      //   icon: const Icon(Icons.admin_panel_settings),
      //   onTap: () => Get.toNamed("/affiliate"),
      // ),
      Settings(
        "Frequenty Asked Questions",
        icon: const Icon(Icons.question_mark_rounded),
        onTap: () => Get.to(const FaqView()),
      ),
    ]),
    Settings("More", children: [
      Settings("About", icon: const Icon(Icons.info_rounded), onTap: () {
        Get.to(const AboutView());
      }),
      // Settings(
      //   "Send feedback",
      //   icon: const Icon(Icons.rate_review_rounded),
      // ),
      Settings(
        "Log Out",
        icon: const Icon(Icons.logout_rounded),
        onTap: () {
          Get.dialog(LogoutDialogView());
        },
      )
    ])
  ];

  void handleCallHelp() async {
    const phoneNumber = "1234568791";
    const url = 'tel:$phoneNumber';
    launchUrl(Uri.parse(url));
  }

  void handleWhatsappHelp() {
    const phoneNumber = "1234568791";
    const url = 'whatsapp://send/?phone=$phoneNumber';
    launchUrl(Uri.parse(url));
  }
}

import '../../../data/models/plants_model.dart';

class CartItem {
  String id;
  Plant plant;
  int count;

  CartItem({
    required this.id,
    required this.plant,
    required this.count,
  });

  Map<String, dynamic> toMap() {
    return {
      "id": id,
      "count": count,
    };
  }
}

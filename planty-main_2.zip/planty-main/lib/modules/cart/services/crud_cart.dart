import 'package:planty_homes/data/constants/export.dart';
import 'package:planty_homes/modules/orders/models/prev_orders_model.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

import '../../../data/models/address_model.dart';
import '../../../data/models/order_model.dart';
import '../../../data/utils/server_utils.dart';

class CartServer extends NewServer {
  Future<Result> saveOrder(
      List<Order> items, Address address,PaymentSuccessResponse? payment,
      [cod = false]) async {
    final prevOrder = PrevOrder(
      id: "",
      signature: payment?.signature,
      paymentId: payment?.paymentId,
      delivery: address,
      orders: items,
      cod: cod,
    );
    // Map<String, dynamic> map = {
    //   'delivery': address,
    //   'cartItems': [],
    // };
    // var cartItemsList = <Map<String, dynamic>>[];
    // for (final item in items) {
    //   Map<String, dynamic> cartItem = {};
    //   cartItem["plant"] = item.plant.id;
    //   cartItem["price"] = item.plant.price;
    //   cartItem["quantity"] = item.count;
    //
    //   cartItemsList.add(cartItem);
    // }
    // map['cartItems'] = cartItemsList;
    print(prevOrder.toServer());
    final res = await handlePostRequest("/api/saveOrder", prevOrder.toServer());
    return res;
  }
  // Future<Result> addItem(CartItem item) async {
  //   final res = await handlePostRequest(ServerRoute.addToCart, item.toMap());
  //   if (!res.isPass && res.msg.isEmpty) {
  //     return Result.fail("Something went wrong while adding the item");
  //   }
  //   return res;
  // }
  //
  // Future<Result> removeItem(CartItem item) async {
  //   final res = await handlePostRequest(
  //     ServerRoute.removeCartItem,
  //     {"id": item.id},
  //   );
  //   if (res.isPass == false && res.msg.isEmpty) {
  //     return Result.fail("Something went wrong while removing the item.");
  //   }
  //   return res;
  // }
  //
  // Future<Result> updateItem(CartItem item) async {
  //   final res = await handlePostRequest(
  //     ServerRoute.updateCartItem,
  //     {"id": item.id},
  //   );
  //   if (!res.isPass && res.msg.isEmpty) {
  //     return Result.fail("Something went wrong while updating cart item");
  //   }
  //   return res;
  // }
}

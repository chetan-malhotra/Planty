import 'package:planty_homes/data/constants/export.dart';
import 'package:planty_homes/global_components/input_number.dart';
import 'package:planty_homes/global_components/primary_button.dart';
import 'package:planty_homes/modules/home/controllers/bookmarks_controller.dart';
import 'package:planty_homes/modules/home/controllers/home_controller.dart';
import 'package:planty_homes/routes/app_pages.dart';

import '../../../data/models/address_model.dart';
import '../../../data/models/order_model.dart';
import '../controllers/cart_controller.dart';

class CartView extends GetView<CartController> {
  const CartView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Cart',
          style: TextStyles.heading1,
        ),
      ),
      body: CustomScrollView(
        slivers: [
          Obx(() => SliverList.builder(
                itemCount: controller.cart.length,
                itemBuilder: (context, index) {
                  final cartItem = controller.cart[index];
                  return CartItemView(cartItem,
                      controller: controller,
                      changeCount: (int value) =>
                          controller.updateOrderItem(index, value));
                },
              )),
          SliverFillRemaining(
            hasScrollBody: false,
            child: Obx(() {
              if (controller.cart.isEmpty) {
                return Container(
                  alignment: Alignment.center,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                          "Nothing is inside the cart.\n Add items to see the list"),
                      PrimaryButton("ADD ITEMS", onTap: (){
                        if(Get.previousRoute == Get.currentRoute){
                          final homeC = Get.find<HomeController>();
                          homeC.bottomNavIndex.value = 0;
                        } else {
                          Get.offAllNamed(Routes.HOME);
                        }
                      })
                    ],
                  ),
                );
              }
              return Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                                blurRadius: 12,
                                color: Colors.black.withOpacity(.1))
                          ]),
                      child: OrderSummary(controller.cart),
                    ),
                    const SizedBox(height: 16),
                    Obx(() {
                      return AddressSelector(
                        controller.address.value,
                        onTap: controller.handleChangeAddress,
                      );
                    }),
                    const SizedBox(height: 16),
                    SizedBox(
                        width: double.infinity,
                        child: FilledButton(
                          onPressed: controller.openCheckout,
                          style: ButtonStyle(
                            padding: const MaterialStatePropertyAll(
                                EdgeInsets.all(16)),
                            backgroundColor:
                                const MaterialStatePropertyAll(Colors.green),
                            shape: MaterialStatePropertyAll(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12))),
                          ),
                          child: const Text("Place Order"),
                        )),
                  ],
                ),
              );
            }),
          )
        ],
      ),
    );
  }
}

class OrderSummary extends StatelessWidget {
  const OrderSummary(
    this.cart, {
    super.key,
  });

  final List<Order> cart;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Text(
          "Order Summery",
          style: TextStyle(color: Colors.black, fontSize: 18),
        ),
        for (final item in cart)
          ListTile(
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(item.plant.name,
                    style: const TextStyle(
                        overflow: TextOverflow.ellipsis, fontSize: 14)),
                Text(" x${item.count}",
                    style: const TextStyle(fontSize: 14, height: 1)),
              ],
            ),
            trailing: Text(
              "₹${item.price}",
              style: const TextStyle(fontSize: 14, height: 1),
            ),
          ),
        if (cart.isNotEmpty)
          const ListTile(
            title: Text("Delivery fee",
                style:
                    TextStyle(overflow: TextOverflow.ellipsis, fontSize: 14)),
            trailing: Text(
              "₹50",
              style: TextStyle(fontSize: 14, height: 1),
            ),
          ),
        const Divider(),
        ListTile(
            title: const Text(
              "TOTAL PRICE",
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            trailing: Text(
              "₹${cart.fold(40, (prev, e) => e.price + prev)}",
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            )),
      ],
    );
  }
}

class AddressSelector extends StatelessWidget {
  const AddressSelector(this.address, {super.key, this.onTap});

  final Address? address;
  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
        width: double.infinity,
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(.1),
                blurRadius: 16,
              )
            ]),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Deliver To: ",
                          style: TextStyles.body1,
                        ),
                        if (address == null)
                          const Text("Select Address",
                              style: TextStyles.heading2),
                        if (address != null)
                          Text(
                            "${address!.name}, ${address!.zipcode}",
                            style: TextStyles.heading3
                                .copyWith(overflow: TextOverflow.ellipsis),
                          ),
                        if (address != null)
                          Text(
                            "${address!.addressLine1}, ${address!.addressLine2}, ${address!.zipcode}",
                            style: TextStyles.body1.copyWith(
                                color: Colors.grey,
                                overflow: TextOverflow.ellipsis),
                          ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    height: 60,
                    margin: const EdgeInsets.all(8),
                    child: TextButton(
                      style: ButtonStyle(
                          shape: MaterialStatePropertyAll(
                              RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)))),
                      onPressed: onTap,
                      child: const Text("change"),
                    ),
                  ),
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
              child: TextFormField(
                maxLines: 4,
                decoration: InputDecoration(
                    hintText: "Instructions for delivery (if any)",
                    hintStyle: TextStyles.body1,
                    contentPadding: const EdgeInsets.all(8),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide())),
              ),
            ),
          ],
        ));
  }
}

class CartItemView extends StatelessWidget {
  CartItemView(
    this.order, {
    super.key,
    required this.changeCount,
    required this.controller,
  });

  final Order order;
  final void Function(int) changeCount;
  final CartController controller;
  final bookmarks = Get.find<BookmarksController>();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.all(16),
      clipBehavior: Clip.antiAlias,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(.1), blurRadius: 16),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              SizedBox(
                width: 100,
                height: 110,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: const SizedBox.expand(
                    child: Image(
                      image: AssetImage("assets/green plant.jpg"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Expanded(
                flex: 3,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        order.plant.name,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w600),
                      ),
                      Text(
                        order.plant.category.fold("", (p, e) {
                          if (p.isEmpty) return e;
                          return "$p, $e";
                        }),
                        style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 14,
                            fontWeight: FontWeight.w400),
                      ),
                      // Row(
                      //   children: [
                      //     RatingBarIndicator(
                      //         rating: order.plant.rating,
                      //         itemSize: 16,
                      //         unratedColor: Colors.grey,
                      //         itemBuilder: (c, i) => const Icon(
                      //               Symbols.star_rounded,
                      //               fill: 1,
                      //               color: Colors.green,
                      //             )),
                      //     Text(" (${order.plant.ratingCount.toString()})"),
                      //   ],
                      // ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            "₹ ${order.price}",
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w600),
                          ),
                          ConstrainedBox(
                            constraints: const BoxConstraints(
                              maxHeight: 28,
                              maxWidth: 80,
                            ),
                            child: NumberInput(
                              order.count,
                              change: changeCount,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              FilledButton(
                onPressed: () {
                  controller.cart
                      .removeWhere((e) => order.plant.id == e.plant.id);
                },
                style: ButtonStyle(
                  backgroundColor:
                      MaterialStatePropertyAll(Colors.grey.shade200),
                  shape: MaterialStatePropertyAll(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
                child:
                    const Text("Remove", style: TextStyle(color: Colors.black)),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: FilledButton(
                    onPressed: () {
                      bookmarks.plants.addIf(
                          !bookmarks.isPlantBookmark(order.plant.id),
                          order.plant);
                      controller.cart
                          .removeWhere((e) => e.plant.id == order.plant.id);
                    },
                    style: ButtonStyle(
                      backgroundColor:
                          MaterialStatePropertyAll(Colors.grey.shade200),
                      shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      )),
                    ),
                    child: const Text("Move to bookmarks",
                        style: TextStyle(color: Colors.black)),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

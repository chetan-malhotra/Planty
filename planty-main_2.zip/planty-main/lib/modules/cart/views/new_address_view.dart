import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:planty_homes/data/utils/cache_helper.dart';
import 'package:planty_homes/global_components/primary_button.dart';

import '../../../data/constants/theme.dart';
import '../controllers/address_controller.dart';
import '../controllers/cart_controller.dart';

class NewAddressView extends GetView<CartController> {
  NewAddressView({Key? key}) : super(key: key);

  final addressController = AddressController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      insetPadding: const EdgeInsets.all(4),
      scrollable: true,
      contentPadding: const EdgeInsets.all(18),
      backgroundColor: Colors.white,
      elevation: 0,
      title: const Text("New Address", style: TextStyles.heading1),
      content: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Form(
          key: addressController.formKey,
          child: Column(children: [
            TextFormField(
              onChanged: addressController.name,
              decoration: const InputDecoration(labelText: "Full Name *"),
              validator: addressController.validate,
            ),
            TextFormField(
              decoration: const InputDecoration(labelText: "Street Address *"),
              onChanged: addressController.addressline1,
              validator: addressController.validate,
            ),
            TextFormField(
              decoration:
                  const InputDecoration(labelText: "Apt, Sut, etc (Optional)"),
              onChanged: addressController.addressline2,
            ),
            TextFormField(
              decoration: const InputDecoration(labelText: "City *"),
              onChanged: addressController.city,
              validator: addressController.validate,
            ),
            TextFormField(
              decoration: const InputDecoration(labelText: "Country *"),
              enabled: false,
              initialValue: addressController.country.value,
              onChanged: addressController.country,
              validator: addressController.validate,
            ),
            TextFormField(
              decoration: const InputDecoration(labelText: "zipcode *"),
              onChanged: addressController.zipcode,
              validator: addressController.validate,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            ),
            PrimaryButton("Add Address", onTap: () {
              if (addressController.isFormValid()) {
                controller.listAddress.add(addressController.getAddressObject());
                controller.listAddress.refresh();
                CacheHelper.cacheAddresses(controller.listAddress);
                Get.back();
              }
            })
          ]),
        ),
      ),
    );
  }
}

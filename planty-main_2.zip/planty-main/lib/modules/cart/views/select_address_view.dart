import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/data/utils/cache_helper.dart';
import 'package:planty_homes/global_components/primary_button.dart';

import '../../../data/constants/theme.dart';
import '../controllers/cart_controller.dart';

class SelectAddressView extends GetView<CartController> {
  const SelectAddressView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Get.back(), icon: const Icon(Icons.close)),
        title: const Text(
          "Select Address for delivery",
          style: TextStyles.heading2,
        ),
      ),
      body: Obx(
        () => ListView.builder(
          itemCount: controller.listAddress.length + 1,
          itemBuilder: (ctx, index) {
            if (controller.listAddress.length <= index) {
              return Container(
                width: double.maxFinite,
                margin: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Divider(),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: PrimaryButton(
                        "Add new address.",
                        color: Colors.green,
                        margin: EdgeInsets.zero,
                        onTap: controller.handleOpenNewAddress,
                      ),
                    ),
                  ],
                ),
              );
            }

            final item = controller.listAddress[index];
            return Obx(() {
              return RadioListTile(
                value: controller.listAddress[index].id,
                groupValue: controller.address.value?.id,
                onChanged: (val) {
                  controller.address.value = controller.listAddress[index];
                  controller.address.refresh();
                },
                title: Text(
                  "${item.name}, ${item.zipcode}",
                  style: TextStyles.heading3
                      .copyWith(overflow: TextOverflow.ellipsis),
                ),
                subtitle: Text(
                  item.toString(),
                  style: TextStyles.body1.copyWith(
                    overflow: TextOverflow.ellipsis,
                    color: Colors.grey,
                  ),
                ),
                secondary: controller.listAddress.length <= 1
                    ? null
                    : IconButton(
                        onPressed: () {
                          controller.listAddress.removeAt(index);
                          controller.address.value =
                              controller.listAddress.first;
                          CacheHelper.cacheAddresses(controller.listAddress);
                        },
                        icon: const Icon(Icons.delete_outline)),
              );
            });
          },
        ),
      ),
    );
  }
}

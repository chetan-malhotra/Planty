import 'package:get/get.dart';
import 'package:planty_homes/controllers/user_controller.dart';
import 'package:planty_homes/data/utils/cache_helper.dart';
import 'package:planty_homes/data/utils/snackbar.dart';
import 'package:planty_homes/global_components/info_message_dialog.dart';
import 'package:planty_homes/modules/cart/services/crud_cart.dart';
import 'package:planty_homes/modules/cart/views/new_address_view.dart';
import 'package:planty_homes/modules/cart/views/select_address_view.dart';
import 'package:planty_homes/routes/app_pages.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

import '../../../data/models/address_model.dart';
import '../../../data/models/order_model.dart';

class CartController extends GetxController {
  Rx<Address?> address = Rx<Address?>(null);

  var listAddress = <Address>[].obs;
  var server = Get.put(CartServer());
  var userController = Get.find<UserController>();

  var cart = <Order>[].obs;
  final deliveryFee = 50;

  void handleChangeAddress() {
    Get.bottomSheet(const SelectAddressView());
  }

  void handleOpenNewAddress() {
    Get.dialog(NewAddressView());
  }

  Razorpay razorpay = Razorpay();

  @override
  void onInit() {
    super.onInit();
    listAddress.addAll(CacheHelper.getAddressesFromCache());
    cart.addAll(CacheHelper.getCartFromCache());

    ever(cart, (cart) {
      CacheHelper.cacheCart(cart);
    });

    razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void onClose() {
    razorpay.clear();
    super.onClose();
  }

  void openCheckout() async {
    if (cart.isEmpty) {
      SnackBarHelper.showError("Cart is empty");
      return;
    }
    if (address.value == null) {
      SnackBarHelper.showError("Please Select a delivery address");
      return;
    }
    final user = userController.user;
    if(user == null){
      SnackBarHelper.showError("You are not logged in");
      return;
    }
    final totalPrice = cart.fold(deliveryFee, (prev, e) => e.price + prev);
    try {
      razorpay.open({
        "key": "rzp_test_U5wMLiJa6xcV5l",
        "amount": (totalPrice * 100)
            .toString(), // this must be in paise not in rupees.
        "name": "Planty",
        'prefill': {
          'contact': user.phone,
          'email': user.email,
        },
        'external': {
          'wallets': ['paytm']
        },
        'method': {
          'netbanking': true,
          'card': true,
          'upi': true,
          'wallet': true,
        },
        "items": [
          for (final item in cart)
            {
              'plantId': item.plant.id,
              'name': item.plant.name,
              'amount': (item.plant.price * 100).toString(),
              'quantity': item.count.toString(),
            }
        ],
      });
    } catch (error) {
      SnackBarHelper.showError("Unkown Error: $error");
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    final result = await server.saveOrder(cart, address.value!, response);
    if (result.isPass) {
      Get.dialog(InfoMessageDialog(true, result.msg));
      cart.removeRange(0, cart.length);
      Get.toNamed(Routes.ORDERS);
      return;
    }
    Get.dialog(InfoMessageDialog(false,
        "${result.msg}\nIf you think this is an error, then kindly contact us through phone or whatsapp"));
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    Get.dialog(const InfoMessageDialog(false, "Error while handling payment"));
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    // Get.dialog(const InfoMessageDialog(false,"Error while handling payment"));
  }

  void updateOrderItem(int index, [int? count, int? price]) {
    final item = cart[index];
    if (count != null && count >= 1) {
      item.count = count;
      item.price = count * item.plant.price.toInt();
    }
    if (price != null) item.price = price;
    cart.refresh();
    update();
  }
}

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/data/models/address_model.dart';

class AddressController extends GetxController {
  var formKey = GlobalKey<FormState>();
  var name = "".obs;
  var addressline1 = "".obs;
  var addressline2 = "".obs;
  var city = "".obs;
  var country = "India".obs;
  var zipcode = "".obs;

  String? validate(String? value) {
    if (value != null && value.isNotEmpty) return null;
    return "This field cannot be empty.";
  }

  bool isFormValid(){
    return formKey.currentState!.validate();
  }

  Address getAddressObject() {
    return Address(
      id: "some ${Random().nextInt(100).toString()}",
      name: name.value,
      addressLine1: addressline1.value,
      addressLine2: addressline2.value.isEmpty ? null : addressline2.value,
      city: city.value,
      country: country.value,
      zipcode: int.parse(zipcode.value),
    );
  }
}

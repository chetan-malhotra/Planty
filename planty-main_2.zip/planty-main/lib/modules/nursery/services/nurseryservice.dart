


import 'package:planty_homes/data/models/plants_model.dart';
import 'package:planty_homes/data/utils/server_utils.dart';

class NurseryService extends NewServer {
    
    Future<Result<List<Plant>?>> getPlants(String nurseryId) async {
      final res = await handlePostRequest("/api/getPlants", {
        "id": nurseryId
      });

      if(res.isPass){
        final body = res.data;
        final list = <Plant>[];
        for(int i = 0; i < (body.length ?? 0); i++){
          list.add(Plant.fromJson(body[i]));
        }
        return Result.pass("", list);
      }
      return Result.fail(res.msg);
    }
}

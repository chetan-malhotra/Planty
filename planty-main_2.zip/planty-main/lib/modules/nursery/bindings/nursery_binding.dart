import 'package:get/get.dart';

import '../controllers/nursery_controller.dart';

class NurseryBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<NurseryController>(
      () => NurseryController(),
    );
  }
}

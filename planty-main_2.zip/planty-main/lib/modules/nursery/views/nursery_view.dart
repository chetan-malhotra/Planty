import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/nursery_controller.dart';
import 'components/category_plants_list.dart';
import 'components/nursery_appbar.dart';
import 'components/nursery_card.dart';

class NurseryView extends GetView<NurseryController> {
  const NurseryView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F6FB),
      appBar: const PreferredSize(
          preferredSize: Size(double.infinity, 60), child: NurseryAppBar()),
      // floatingActionButton: Padding(
      //   padding: const EdgeInsets.all(18),
      //   child: TextButton(
      //       onPressed: () => controller.showCategories(),
      //       style: const ButtonStyle(
      //           backgroundColor: MaterialStatePropertyAll(Colors.green),
      //           padding: MaterialStatePropertyAll(
      //               EdgeInsets.symmetric(vertical: 8, horizontal: 16))),
      //       child: const Text(
      //         "Plants",
      //         style: TextStyle(
      //             color: Colors.white,
      //             fontSize: 18,
      //             fontWeight: FontWeight.w500),
      //       )),
      // ),
      // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      body: RefreshIndicator(
        onRefresh: () async =>
            await controller.getPlants(controller.nursery.id),
        child: ListView(
          children: [
            NurseryCard(
              controller.nursery,
            ),
            // CustomCarousel(controller: controller),
            // SingleChildScrollView(
            //   scrollDirection: Axis.horizontal,
            //   child: Padding(
            //     padding: const EdgeInsets.all(8),
            //     child: Row(
            //       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //       children: [
            //         Obx(() {
            //           return Container(
            //             margin: const EdgeInsets.symmetric(horizontal: 8),
            //             padding: const EdgeInsets.symmetric(horizontal: 12),
            //             height: 35,
            //             decoration: BoxDecoration(
            //                 color: Colors.white,
            //                 border: Border.all(width: 1),
            //                 borderRadius: BorderRadius.circular(8)),
            //             child: DropdownButton<String>(
            //               value: controller.sort.value,
            //               underline: const SizedBox(),
            //               items: controller.sortList
            //                   .map<DropdownMenuItem<String>>(
            //                       (e) => DropdownMenuItem(
            //                             value: e,
            //                             child: Text(e),
            //                           ))
            //                   .toList(),
            //               onChanged: (item) {
            //                 controller.sort.value = item ?? "sort";
            //               },
            //             ),
            //           );
            //         }),
            //         const SizedBox(width: 16),
            //         for (final item in controller.totalFilters)
            //           Row(
            //             children: [
            //               Chip(
            //                 label: Text(item),
            //               ),
            //               const SizedBox(width: 16)
            //             ],
            //           )
            //       ],
            //     ),
            //   ),
            // ),
            const SizedBox(height: 16),
            CategoryPlantsList(controller.nursery.id),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

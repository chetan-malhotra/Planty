import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:planty_homes/global_components/bookmark_button.dart';
import 'package:planty_homes/global_components/input_number.dart';
import 'package:planty_homes/global_components/primary_button.dart';
import 'package:planty_homes/modules/cart/controllers/cart_controller.dart';
import 'package:planty_homes/routes/app_pages.dart';

import '../../../data/models/order_model.dart';
import '../../../data/models/plants_model.dart';

class TempController extends GetxController {
  var count = 1.obs;
}

class PlantView extends GetView<CartController> {
  PlantView(this.plant, {Key? key}) : super(key: key);

  final Plant plant;
  final counter = TempController();

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: Container(
          margin: const EdgeInsets.all(8),
          decoration: const BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(40),
            onTap: () => Get.back(),
            child: const Icon(Icons.arrow_back),
          ),
        ),
        backgroundColor: Colors.transparent,
      ),
      floatingActionButton: PrimaryButton(
        "Add & Goto Cart",
        width: double.infinity,
        onTap: () {
          // if(controller.address.value == null){
          //   Get.bottomSheet(const SelectAddressView());
          //   return;
          // }
          controller.cart.addIf(
            !controller.cart.any((e) => e.plant.id == plant.id),
            Order(
              count: counter.count.value,
              coupons: [],
              expectedArrival: DateTime(2023),
              plant: plant,
              price: plant.price,
              status: OrderStatus.notOrdered,
            ),
          );
          Get.toNamed(Routes.CART);
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              height: size.height * .4,
              child: const Stack(
                children: [
                  SizedBox.expand(
                    child: Image(
                      image: AssetImage("assets/images/palm.jpg"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          plant.name,
                          style: const TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w500),
                        ),
                      ),
                      BookmarkButton(
                        plant.id,
                        true,
                        plant: plant,
                      ),
                    ],
                  ),
                  Text(
                    plant.category.fold("", (p, e) {
                      if (p.isEmpty) return e;
                      return "$p, $e";
                    }),
                    style: const TextStyle(
                        color: Colors.grey, fontWeight: FontWeight.w400),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "₹ ${plant.price}",
                        style: const TextStyle(fontSize: 22),
                      ),
                      Obx(() {
                        var count = counter.count.value;
                        int? index;
                        if (controller.cart
                            .any((element) => element.plant.id == plant.id)) {
                          index = controller.cart
                              .indexWhere((p0) => plant.id == p0.plant.id);
                        }
                        return SizedBox(
                          width: 120,
                          height: 30,
                          child: NumberInput(
                            index != null
                                ? controller.cart[index].count
                                : count,
                            change: (int val) {
                              if (val <= 0) {
                                if (index != null) {
                                  controller.updateOrderItem(index, 1);
                                  return;
                                }
                                counter.count(1);
                                return;
                              }
                              if (index != null) {
                                controller.updateOrderItem(index, val);
                              }

                              counter.count(val);
                            },
                          ),
                        );
                      }),
                    ],
                  ),
                  const SizedBox(height: 18),
                  const Text("Details:"),
                  Text(
                    plant.description,
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w400),
                  ),
                  const SizedBox(height: 120),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

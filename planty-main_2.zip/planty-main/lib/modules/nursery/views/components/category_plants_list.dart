import 'package:planty_homes/data/constants/export.dart';
import 'package:planty_homes/modules/nursery/controllers/nursery_controller.dart';
import 'package:planty_homes/modules/nursery/views/plant_view.dart';

import 'plant_item_card.dart';

class CategoryPlantsList extends GetView<NurseryController> {
  const CategoryPlantsList(
    this.nurseryId, {
    super.key,
  });

  final String nurseryId;

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if(controller.isLoading.value){
        return SizedBox(
        height: Get.height * .4,
        width: double.infinity,
        child: const Center(
          child: SizedBox.square(
          dimension: 40,
          child: CircularProgressIndicator()),
        ));
      }
      return Container(
          width: double.infinity,
          color: Colors.white,
          margin: const EdgeInsets.only(top: 16),
          padding: const EdgeInsets.fromLTRB(0, 16, 0, 16),
          child: Column(
            children: [
              ExpansionTile(
                tilePadding: const EdgeInsets.only(right: 16),
                initiallyExpanded: true,
                title: Row(
                  children: [
                    Container(
                      width: 4,
                      height: 24,
                      margin: const EdgeInsets.only(right: 8),
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.horizontal(
                              right: Radius.circular(8)),
                          color: Colors.green),
                    ),
                    const Text(
                      "Recommended",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                shape: Border.all(width: 0, color: Colors.transparent),
                collapsedShape: Border.all(width: 0, color: Colors.transparent),
                children: _renderItems(),
              ),
            ],
          ));
    });
  }

  List<Widget> _renderItems() {
    final list = <Widget>[];

    for (final item in controller.plants) {
      list.add(
        PlantItemCard(
          item,
          onTap: () => Get.to(PlantView(item)),
        ),
      );
      list.add(Divider(
        indent: 8,
        endIndent: 8,
        thickness: 1,
        color: Colors.grey.withOpacity(.2),
      ));
    }
    return list;
  }
}


import 'package:flutter/material.dart';

import '../../../../data/models/nursery_model.dart';

class CategoryPopUp extends StatelessWidget {
  const CategoryPopUp({
    super.key,
    required this.categories,
  });

  final List<Category> categories;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      alignment: Alignment.bottomCenter,
      backgroundColor: Colors.white,
      elevation: 0,
      insetPadding: const EdgeInsets.all(16),
      child: SizedBox(
        height: 300,
        child: Column(
          children: [
            const SizedBox(height: 16),
            const Text(
              "Categories",
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w600),
            ),
            SingleChildScrollView(
              child: Column(children: [
                const ListTile(
                  title: Text(
                    "Recommended (30)",
                    style: TextStyle(
                        color: Colors.green,
                        fontSize: 20,
                        fontWeight: FontWeight.w600),
                  ),
                ),
                for (final item in categories)
                  ListTile(
                      title: Text(
                        item.name,
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 18),
                      ),
                      trailing: Text(
                        item.plants.length.toString(),
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w600),
                      ))
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

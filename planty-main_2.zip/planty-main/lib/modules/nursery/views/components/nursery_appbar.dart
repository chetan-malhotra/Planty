import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:planty_homes/modules/nursery/controllers/nursery_controller.dart';
import 'package:planty_homes/routes/app_pages.dart';

class NurseryAppBar extends GetView<NurseryController> {
  const NurseryAppBar({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.transparent,
      actions: [
        Container(
          width: 200,
          height: 50,
          margin: const EdgeInsets.all(8),
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(20)),
          child: TextField(
            onSubmitted: (txt){
              Get.toNamed(Routes.SEARCH, arguments: txt);
            },
            decoration: const InputDecoration(
              contentPadding: EdgeInsets.fromLTRB(0, 4, 4, 0),
              hintText: "search plants",
              hintStyle: TextStyle(color: Colors.green),
              iconColor: Colors.green,
              icon: Icon(Icons.search),
              border: OutlineInputBorder(
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        PopupMenuButton(
          onSelected: (val) => controller.openReportNursery(),
          elevation: 0,
          itemBuilder: (ctx) {
            return [
              const PopupMenuItem(
                  value: "report", child: Text("Report Nursery"))
            ];
          },
        ),
      ],
    );
  }
}

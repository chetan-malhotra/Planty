import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:planty_homes/modules/cart/controllers/cart_controller.dart';

import '../../../../data/constants/theme.dart';
import '../../../../data/models/order_model.dart';
import '../../../../data/models/plants_model.dart';

class PlantItemCard extends StatelessWidget {
  const PlantItemCard(
    this.plant, {
    super.key,
    this.onTap,
  });

  final Plant plant;
  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 130,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          plant.name.isEmpty ? "noname": plant.name,
                          style: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(2),
                              decoration: BoxDecoration(
                                  color: Colors.amber.withOpacity(.2),
                                  borderRadius: BorderRadius.circular(4)),
                              child: RatingBarIndicator(
                                rating: 2.75,
                                unratedColor: Colors.white,
                                itemBuilder: (context, index) => const Icon(
                                  Icons.star_outlined,
                                  color: Colors.amber,
                                ),
                                itemCount: 5,
                                itemSize: 15.0,
                              ),
                            ),
                            const SizedBox(
                              width: 8,
                            ),
                            // Expanded(
                            //   child: Text("${plant.ratingCount} ratings",
                            //       softWrap: false,
                            //       style: const TextStyle(
                            //           overflow: TextOverflow.fade)),
                            // ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Text(
                          " ₹ ${plant.price}",
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        Text(
                          plant.description,
                          maxLines: 2,
                          style:
                              const TextStyle(overflow: TextOverflow.ellipsis),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: const Image(
                            width: 130,
                            height: 130,
                            image: AssetImage("assets/images/palm.jpg"),
                            // image: NetworkImage(plant.imageURL),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          height: 150,
                          alignment: Alignment.bottomCenter,
                          child: AddToCartCountButton(
                            plant,
                            onTap: () {},
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class AddToCartCountButton extends GetView<CartController> {
  const AddToCartCountButton(
    this.plant, {
    super.key,
    this.onTap,
  });

  final Function()? onTap;
  final Plant plant;

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
        init: controller,
        builder: (ctx) {
          Widget widget;
          if (ctx.cart.any((element) => element.plant.id == plant.id)) {
            final index = ctx.cart.indexWhere((p0) => p0.plant.id == plant.id);
            widget = Container(
              height: 35,
              width: 100,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    FittedBox(
                      child: IconButton(
                        onPressed: () {
                          ctx.updateOrderItem(index, ctx.cart[index].count - 1);
                          ctx.update();
                        },
                        icon: const Icon(
                          Icons.remove,
                          color: Colors.white,
                          size: 16,
                        ),
                      ),
                    ),
                    Text(
                      "${ctx.cart[index].count}",
                      style: const TextStyle(color: Colors.white),
                    ),
                    FittedBox(
                      child: IconButton(
                          onPressed: () {
                            ctx.updateOrderItem(
                                index, ctx.cart[index].count + 1);
                            ctx.update();
                          },
                          icon: const Icon(
                            Icons.add,
                            color: Colors.white,
                            size: 16,
                          )),
                    )
                  ]),
            );
          } else {
            widget = InkWell(
                onTap: () {
                  // if(ctx.address.value== null){
                  //   Get.bottomSheet(const SelectAddressView());
                  //   return;
                  // }
                  ctx.cart.add(Order(
                    status: OrderStatus.notOrdered,
                    expectedArrival: DateTime(2023),
                    // delivery: Delivery(
                    //   nurseryId: plant.nurseryId,
                    //   nurseryName: plant.nurseryName,
                    //   fee: controller.deliveryFee.toDouble(),
                    //   to: controller.address.value!,
                    // ),
                    coupons: [],
                    plant: plant,
                    price: plant.price,
                    count: 1,
                  ));
                  ctx.update();
                },
                child: Container(
                  height: 35,
                  width: 100,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.green, width: 2),
                  ),
                  child: Text(
                    "Add +",
                    style: TextStyles.heading3.copyWith(color: Colors.green),
                  ),
                ));
          }
          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            transitionBuilder: (child, animation) {
              return FadeTransition(opacity: animation, child: child);
            },
            child: widget,
          );
        });
  }
}

class TempController extends GetxController {
  var count = 0.obs;
}

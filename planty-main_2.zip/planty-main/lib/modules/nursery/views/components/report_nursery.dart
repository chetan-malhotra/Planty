import 'package:planty_homes/data/constants/export.dart';
import 'package:url_launcher/url_launcher.dart';

class ReportNurseryPopUp extends StatelessWidget {
  const ReportNurseryPopUp({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      elevation: 0,

      title: const Text(
        "Report Nursery:",
        style: TextStyles.heading1,
      ),
      content: SizedBox(
        height: 80,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Report nursery to this number"),
            const SizedBox(height: 8),
            TextButton(
                onPressed: () async {
                  const phoneNumber = "+919464210784";
                  const url = 'tel:$phoneNumber';
                  launchUrl(Uri.parse(url));
                },
                child: const Text("+91 94642 10784"))
          ],
        ),
      ),
      // actions: [PrimaryButton("Report Now", onTap: () {})],
      // content: TextFormField(
      //   keyboardType: TextInputType.multiline,
      //   decoration: const InputDecoration(
      //     hintText: "Write a message"
      //   ),
      //   maxLines: null,
      // ),
    );
  }
}

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

import '../../controllers/nursery_controller.dart';

class CustomCarousel extends StatelessWidget {
  const CustomCarousel({
    super.key,
    required this.controller,
  });

  final NurseryController controller;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: CarouselSlider(
        items: [
          for (final item in controller.offers)
            ClipRRect(
              clipBehavior: Clip.antiAlias,
              borderRadius: BorderRadius.circular(16),
              child: Container(
                color: Colors.white,
                margin: EdgeInsets.zero,
                padding: EdgeInsets.zero,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 50,
                        height: double.infinity,
                        alignment: Alignment.center,
                        child: const Image(
                          image: AssetImage("assets/icons/paytm.jpg"),
                          fit: BoxFit.cover,
                        ),
                      ),
                      Expanded(
                        flex: 6,
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Text(
                                item.title,
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.w600),
                              ),
                              Text(
                                item.subtitle,
                                style: const TextStyle(color: Colors.grey),
                              )
                            ],
                          ),
                        ),
                      )
                    ]),
              ),
            )
        ],
        options: CarouselOptions(
          viewportFraction: 1,
          autoPlay: true,
          height: 70,
        ),
      ),
    );
  }
}

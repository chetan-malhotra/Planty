import 'package:flutter/material.dart';
import 'package:planty_homes/global_components/bookmark_button.dart';

import '../../../../data/models/nursery_model.dart';

class NurseryCard extends StatelessWidget {
  const NurseryCard(
    this.nursery, {
    super.key,
    this.onTap,
  });
  final Function()? onTap;
  final Nursery nursery;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          flex: 3,
                          child: Text(
                            nursery.nurseryName,
                            softWrap: false,
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w700,
                              overflow: TextOverflow.fade,
                            ),
                          ),
                        ),
                        BookmarkButton(
                          nursery.id,
                          false,
                          nursery: nursery,
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    Text(
                      nursery.city,
                      // nursery.categories.fold<String>("", (prev, element) {
                      //   if (prev.isEmpty) return element;
                      //   return "$prev, $element";
                      // }),
                      softWrap: false,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        overflow: TextOverflow.fade,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      nursery.ownerContact.toString(),
                      softWrap: false,
                      style: const TextStyle(overflow: TextOverflow.fade),
                    ),
                    const SizedBox(height: 4),
                    // Row(
                    //   children: [
                    //     const Icon(
                    //       Icons.timer,
                    //       size: 16,
                    //     ),
                    //     const SizedBox(width: 8),
                    //     Expanded(
                    //       child: Text(
                    //         "${nursery.distanceInTime} | ${nursery.distance} km away",
                    //         softWrap: false,
                    //         style: const TextStyle(
                    //             fontWeight: FontWeight.w500,
                    //             overflow: TextOverflow.fade),
                    //       ),
                    //     ),
                    //   ],
                    // )
                  ],
                ),
              ),
            ),
            // Column(
            //   crossAxisAlignment: CrossAxisAlignment.end,
            //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //   children: [
            //     const SizedBox(height: 16),
            //     Container(
            //       decoration: BoxDecoration(
            //           borderRadius: BorderRadius.circular(18),
            //           border: Border.all(color: Colors.grey, width: 1)),
            //       clipBehavior: Clip.antiAlias,
            //       child: Column(
            //         children: [
            //           Container(
            //             color: Colors.green,
            //             padding: const EdgeInsets.symmetric(
            //                 horizontal: 12, vertical: 4),
            //             child: Row(
            //               children: [
            //                 Text(
            //                   nursery.rating.toString(),
            //                   style: const TextStyle(
            //                     fontSize: 22,
            //                     fontWeight: FontWeight.w500,
            //                     color: Colors.white,
            //                   ),
            //                 ),
            //                 const SizedBox(width: 4),
            //                 const Icon(
            //                   Icons.star,
            //                   size: 18,
            //                   color: Colors.white,
            //                 )
            //               ],
            //             ),
            //           ),
            //           const SizedBox(height: 4),
            //           // Text(
            //           //   nursery.reviewCount.toString(),
            //           //   style: const TextStyle(
            //           //       fontWeight: FontWeight.w600, height: 1),
            //           // ),
            //           const Text("Reviews"),
            //           const SizedBox(height: 4),
            //         ],
            //       ),
            //     ),
            //   ],
            // ),
          ],
        ),
      ),
    );
  }
}

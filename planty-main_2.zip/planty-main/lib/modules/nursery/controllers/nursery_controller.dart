import 'package:get/get.dart';
import 'package:planty_homes/modules/nursery/services/nurseryservice.dart';

import '../../../data/models/nursery_model.dart';
import '../../../data/models/plants_model.dart';
import '../views/components/report_nursery.dart';

// final plant = Plant(
//   id: "lkhi",
//   name: "Palm",
//   price: 439,
//   tags: ["gifts", "ceramic"],
//   description: "Palm is one of the most favourite indoor plant",
//   category: "Ceramic",
//   rating: 4.5,
//   ratingCount: 162,
//   imageURL: "https://picsum.photos/200",
// );

class NurseryController extends GetxController {
  final Nursery nursery = Get.arguments;
  final server = Get.put(NurseryService());

  var plants = <Plant>[].obs;
  var isLoading = false.obs;

  Future<void> getPlants(String nurseryId) async {
    isLoading(true);
    final res = await server.getPlants(nurseryId);
    if (res.isPass) {
      plants.removeRange(0, plants.length);
      plants.addAll(res.data ?? []);
    }

    isLoading(false);
  }

  @override
    void onInit() {
      getPlants(nursery.id);
      super.onInit();
    }

  // List<String> totalFilters = ["Gifts", "Ceramic", "FastDelivery"].obs;
  // List<String> filters = <String>[].obs;
  // List<String> sortList = ["sort", "from low to high price"].obs;
  // var sort = "sort".obs;
  // var offers = [
  //   Offer(
  //       title: "Up to \$100 MobiKwik cashback",
  //       subtitle: "use code MBKFEST | above \$199",
  //       imageURL: "https://picsum.photos/200/300")
  // ].obs;

  // var currentNuresery = SNursery(
  //   id: "some",
  //   name: "Nursery 1",
  //   rating: 4.0,
  //   reviewCount: 2111,
  //   categories: ["Ceramic", "Flower", "Fruits"],
  //   location: "Balongi, Maohali",
  //   distance: 8,
  //   distanceInTime: "40-45 min",
  //   plants: [plant, plant, plant, plant],
  // ).obs;

  // void showCategories() {
  //   Get.dialog(
  //     CategoryPopUp(categories: categories),
  //   );
  // }

  void openReportNursery() {
    Get.dialog(const ReportNurseryPopUp());
  }
}

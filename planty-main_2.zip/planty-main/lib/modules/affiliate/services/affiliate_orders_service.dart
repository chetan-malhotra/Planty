
import '../models/affiliate_order.dart';

class OrdersService {
  static Future<AffiliateOrder> getFakeOrder() async {
    var newOrder = AffiliateOrder(
      id: 102,
      customer: Customer(name: "Some Name", totalOrders: 3),
      items: [
        OrderItem(count: 2, name: "Chapati", price: 20, isVeg: true),
        OrderItem(count: 1, name: "Dal curry", price: 30, isVeg: true),
      ],
      status: OrderStatus.notAccepted,
      orderedAt: DateTime.now(),
      totalPaid: 50,
    );
    return newOrder;
  }
}

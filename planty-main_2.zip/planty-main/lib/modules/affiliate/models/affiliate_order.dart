class AffiliateOrder {
  int id;
  Customer customer;
  List<OrderItem> items;
  double totalPaid;
  double? preperationTime; // this will be set later
  DateTime orderedAt;
  OrderStatus status;

  AffiliateOrder({
    required this.id,
    required this.customer,
    required this.items,
    required this.totalPaid,
    required this.orderedAt,
    required this.status,
    this.preperationTime,
  });

  double totalPrice() {
    var price = 0.0;
    for (int i = 0; i < items.length; i++) {
      price += items[i].price;
    }
    return price;
  }

  bool get hasPaid => totalPaid == totalPrice();

  String orderStatusName() {
    if (status == OrderStatus.preparing) {
      return "Preparing";
    } else if (status == OrderStatus.ready) {
      return "Ready";
    } else if (status == OrderStatus.pickedUp) {
      return "Picked up";
    } else {
      return "Not Accepted";
    }
  }
}

enum OrderStatus {
  preparing,
  ready,
  pickedUp,
  notAccepted,
}

class OrderItem {
  int count;
  String name;
  double price;
  bool isVeg;
  OrderItem({
    required this.count,
    required this.name,
    required this.price,
    required this.isVeg,
  });
}

class Customer {
  String name;
  int totalOrders;
  int? phone;
  Customer({
    required this.name,
    required this.totalOrders,
    this.phone,
  });
}

import 'package:get/get.dart';

import '../models/affiliate_order.dart';
import '../services/affiliate_orders_service.dart';

class AffiliateController extends GetxController {
  var bottomNavIndex = 0.obs;
  var isOnline = true.obs;
  void toggle() {
    isOnline(!isOnline.value);
  }

  var _orders = <AffiliateOrder>[];
  var unacceptedOrders = <AffiliateOrder>[].obs;

  OrderStatus? _filter = OrderStatus.preparing; // null represents no filter
  var filteredOrders = <AffiliateOrder>[].obs;

  OrderStatus? get filter => _filter;

  List<AffiliateOrder> get orders => _orders;

  void setOrders(List<AffiliateOrder> list) {
    _orders = list;
    updateFilterdOrders();
    update();
  }

  void addOrder(AffiliateOrder order) {
    _orders.add(order);
    updateFilterdOrders();
    update();
  }

  set filter(OrderStatus? newFilter) {
    _filter = newFilter;
    updateFilterdOrders();
  }

  void updateFilterdOrders() {
    if (_filter == null) {
      filteredOrders.clear();
      filteredOrders.addAll(orders);
      update();
      return;
    }
    filteredOrders.clear();
    for (final item in orders) {
      if (item.status == _filter) {
        filteredOrders.add(item);
      }
    }
    update();
  }

  void fakeOrder() async {
    final newOrder = await OrdersService.getFakeOrder();
    unacceptedOrders.add(newOrder);
  }

  int getLength(OrderStatus status) {
    if (status == OrderStatus.notAccepted) {
      return unacceptedOrders.length;
    } else {
      int length = 0;
      for (int i = 0; i < orders.length; i++) {
        if (orders[i].status == status) length++;
      }
      return length;
    }
  }
}

import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:planty_homes/modules/affiliate/views/components/online_switch_view.dart';

import '../controllers/affiliate_controller.dart';
import 'components/chip_tabs.dart';
import 'components/order_card_view.dart';
import 'new_orders_view.dart';

class AffiliateView extends GetView<AffiliateController> {
  const AffiliateView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        title: const OnlineSwitch(),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.search),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.menu),
          ),
        ],
        bottom: const PreferredSize(
          preferredSize: Size(50, 40),
          child: TabsHome(),
        ),
      ),
      body: Obx(() {
        if (controller.filteredOrders.isEmpty) {
          return Center(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(24),
                    child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 400),
                        transitionBuilder: (child, animation) {
                          return FadeTransition(
                              opacity: animation, child: child);
                        },
                        child: controller.isOnline.value
                            ? const Image(
                                key: Key("assets/open.png"),
                                image: AssetImage("assets/open.png"))
                            : const Image(
                                key: Key("assets/close.png"),
                                image: AssetImage("assets/close.png"))),
                  ),
                  Text(
                    "You are ${controller.isOnline.value ? "Online" : "Offline"}",
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  Text(controller.isOnline.value
                      ? "Waiting for new orders"
                      : "Change status to Online to get orders"),
                  const SizedBox(height: 100),
                  IconButton(
                    icon: const Text("goto new orders"),
                    onPressed: () {
                      Get.to(const NewOrdersView());
                    },
                  )
                ],
              ),
            ),
          );
        }
        return ListView(
          children: [
            for (final order in controller.filteredOrders)
              OrderCard(order: order),
            IconButton(
              icon: const Text("goto new orders"),
              onPressed: () {
                Get.to(const NewOrdersView());
              },
            )
          ],
        );
      }),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          controller.fakeOrder();
        },
        child: Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(8),
            child: const Text("fake order")),
      ),
      bottomNavigationBar: Obx(() {
        return BottomNavigationBar(
          fixedColor: Colors.red,
          backgroundColor: Colors.white,
          type: BottomNavigationBarType.fixed,
          currentIndex: controller.bottomNavIndex.value,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.room_service),
              label: "Home",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.article),
              label: "Menu",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.bar_chart),
              label: "Insights",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.monetization_on),
              label: "Growth",
            ),
          ],
          onTap: (index) {
            controller.bottomNavIndex.value = index;
          },
        );
      }),
    );
  }
}

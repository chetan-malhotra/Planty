import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:planty_homes/modules/affiliate/controllers/affiliate_controller.dart';

class OnlineSwitch extends GetView<AffiliateController> {
  const OnlineSwitch({Key? key}) : super(key: key);
   
  final duration = const Duration(milliseconds: 200);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        controller.toggle();
      },
      child: Obx(() {
        return AnimatedContainer(
          duration: duration,
          width: 86,
          height: 28,
          decoration: BoxDecoration(
            color: controller.isOnline.value ? Colors.green : Colors.grey,
            borderRadius: BorderRadius.circular(16),
          ),
          // padding: const EdgeInsets.all(4),
          child: Stack(
            alignment: Alignment.centerLeft,
            children: [
              AnimatedPositioned(
                duration: duration,
                right: controller.isOnline.value ? 2 : 60,
                child: Container(
                  width: 20,
                  height: 20,
                  margin: const EdgeInsets.only(right: 2),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                  ),
                ),
              ),
              Positioned(
                left: 12,
                child: AnimatedOpacity(
                  opacity: controller.isOnline.value ? 1 : 0,
                  duration: duration,
                  child: const Text(
                    "Online",
                    style: TextStyle(
                        fontSize: 14,
                        color: Colors.white,
                        fontWeight: FontWeight.w300),
                  ),
                ),
              ),
              Positioned(
                right: 12,
                child: AnimatedOpacity(
                  opacity: controller.isOnline.value ? 0 : 1,
                  duration: duration,
                  child: const Text(
                    "Offline",
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.white,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                ),
              )
              // Text("Offline"),
            ],
          ),
        );
      }),
    );
  }
}

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../models/affiliate_order.dart';

class OrderCard extends StatelessWidget {
  OrderCard({
    super.key,
    required this.order,
    this.onReject,
    this.onAccept,
  });

  final AffiliateOrder order;
  final Function()? onReject;
  final Function()? onAccept;
  final textController = TextEditingController(text: "20");

  Widget _footer() {
    if (order.status == OrderStatus.notAccepted) {
      return Container(
        margin: const EdgeInsets.only(top: 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // const Text("Set food preperation time"),
          // const SizedBox(height: 12),
          // Container(
          //   decoration: BoxDecoration(
          //       border: Border.all(width: 2, color: Colors.grey),
          //       borderRadius: BorderRadius.circular(12)),
          //   child: Row(
          //     children: [
          //       InkWell(
          //         onTap: () {},
          //         child: Container(
          //           width: 60,
          //           height: 46,
          //           decoration: const BoxDecoration(
          //             border: Border(
          //               right: BorderSide(
          //                 width: 2,
          //                 color: Colors.grey,
          //               ),
          //             ),
          //           ),
          //           child: const Icon(Icons.remove),
          //         ),
          //       ),
          //       const Expanded(flex: 1, child: SizedBox()),
          //       Expanded(
          //         child: TextField(
          //           textAlignVertical: TextAlignVertical.center,
          //           controller: textController,
          //           textAlign: TextAlign.center,
          //           decoration: const InputDecoration(
          //             contentPadding: EdgeInsets.fromLTRB(0, 14, 0, 17),
          //             border: InputBorder.none,
          //           ),
          //           inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          //           style: const TextStyle(fontSize: 16),
          //           keyboardType: TextInputType.number,
          //         ),
          //       ),
          //       const Expanded(
          //         flex: 2,
          //         child: Align(
          //           alignment: Alignment.center,
          //           child: Text(
          //             "minutes",
          //             style: TextStyle(
          //               fontSize: 17,
          //             ),
          //           ),
          //         ),
          //       ),
          //       const Expanded(flex: 1, child: SizedBox()),
          //       InkWell(
          //         onTap: () {},
          //         child: Container(
          //           width: 60,
          //           height: 46,
          //           decoration: const BoxDecoration(
          //             border: Border(
          //               left: BorderSide(
          //                 width: 2,
          //                 color: Colors.grey,
          //               ),
          //             ),
          //           ),
          //           child: const Icon(Icons.add),
          //         ),
          //       ),
          //     ],
          //   ),
          // ),
          const SizedBox(height: 12),
          Row(
            children: [
              OutlinedButton(
                  style: ButtonStyle(
                    shape: MaterialStateProperty.all<OutlinedBorder>(
                      RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    overlayColor:
                        MaterialStateProperty.all(Colors.red.withOpacity(.1)),
                    side: MaterialStateProperty.resolveWith<BorderSide>(
                        (Set<MaterialState> states) {
                      final Color color = states.contains(MaterialState.pressed)
                          ? Colors.red
                          : Colors.red;
                      return BorderSide(color: color, width: 1.2);
                    }),
                    padding:
                        MaterialStateProperty.all(const EdgeInsets.all(26)),
                  ),
                  onPressed: onReject,
                  child: const Text(
                    "Reject",
                    style: TextStyle(
                      color: Colors.red,
                      fontSize: 16,
                    ),
                  )),
              const SizedBox(width: 12),
              Expanded(
                child: AcceptButton(
                  order.orderedAt,
                  onAccept: onAccept,
                ),
              )
            ],
          )
        ]),
      );
    }
    return const SizedBox();
  }

  @override
  Widget build(BuildContext context) {
    const priceTextStyle = TextStyle(fontSize: 15, fontWeight: FontWeight.w500);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      alignment: Alignment.topLeft,
      child: Column(children: [
        Row(
          children: [
            Text(
              "ID: ${order.id}",
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
            const Expanded(child: SizedBox()),
            Text(
              DateFormat("hh:mm a").format(order.orderedAt),
              style: priceTextStyle,
            ),
            if (order.status != OrderStatus.notAccepted)
              const SizedBox(width: 16, child: Icon(Icons.more_vert)),
          ],
        ),
        const SizedBox(height: 4),
        Row(children: [
          if (order.status != OrderStatus.notAccepted)
            Container(
              padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 6),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: Colors.blueGrey),
              child: Text(
                order.orderStatusName().toUpperCase(),
                style: const TextStyle(
                    fontSize: 12,
                    color: Colors.white,
                    fontWeight: FontWeight.w100),
              ),
            ),
          if (order.status != OrderStatus.notAccepted)
            const Expanded(child: SizedBox()),
          Text(
            "${order.customer.totalOrders + 1}th order by ${order.customer.name}",
            style: const TextStyle(
              color: Color(0xff1bc4ab),
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
        ]),
        const Divider(),
        for (final item in order.items)
          ListTile(
            visualDensity: const VisualDensity(vertical: -4),
            horizontalTitleGap: 8,
            contentPadding: const EdgeInsets.all(0),
            leading: IsVegIcon(item.isVeg),
            title: Text(
              "${item.count}x ${item.name}",
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
            trailing: Text(
              "₹${item.price.round()}",
              style: priceTextStyle,
            ),
          ),
        const Divider(),
        Row(
          children: [
            const Text(
              "Total bill",
              style: TextStyle(
                fontSize: 15,
              ),
            ),
            Container(
              margin: const EdgeInsets.all(4),
              padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 4),
              decoration: BoxDecoration(
                color: const Color(0x201edfe6),
                borderRadius: BorderRadius.circular(2),
                border: Border.all(
                  color: const Color(0xff148d91),
                  width: 1.2,
                ),
              ),
              child: const Text(
                "PAID",
                style: TextStyle(
                  fontSize: 12,
                  color: Color(0xff148d91),
                ),
              ),
            ),
            const Expanded(child: SizedBox()),
            Text(
              "₹${order.totalPrice().round()}",
              style: priceTextStyle,
            ),
          ],
        ),
        _footer()
      ]),
    );
  }
}

class AcceptButton extends StatefulWidget {
  const AcceptButton(
    this.orderTime, {
    this.onAccept,
    super.key,
  });
  final DateTime orderTime;
  final Function()? onAccept;

  @override
  State<AcceptButton> createState() => _AcceptButtonState();
}

class _AcceptButtonState extends State<AcceptButton> {
  double progress = 10.0;
  late Timer timer;

  @override
  void initState() {
    if (DateTime.now().difference(widget.orderTime).inSeconds > 10) {
      progress = 0;
      timer = Timer(const Duration(seconds: 0), () {});
      timer.cancel();
    } else {
      progress = 10.0 - DateTime.now().difference(widget.orderTime).inSeconds;
      timer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
        if (progress <= 0) {
          setState(() {
            progress = 0;
          });
          return timer.cancel();
        }
        setState(() {
          progress -= .05;
        });
      });
    }
    super.initState();
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constr) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Material(
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: widget.onAccept,
            child: Ink(
              height: 60,
              color: progress == 0 ? Colors.grey : Colors.green,
              child: Stack(
                children: [
                  Positioned(
                    left: 0,
                    right:
                        constr.maxWidth - (constr.maxWidth * (progress / 10)),
                    top: 0,
                    bottom: 0,
                    child: Container(
                      decoration: BoxDecoration(
                          color: const Color(0xff138f34),
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  Center(
                    child: Text(
                      "Accept (0:${progress.round()})",
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    });
  }
}

class IsVegIcon extends StatelessWidget {
  const IsVegIcon(this.isVeg, {super.key, this.size = 16});

  final bool isVeg;
  final double size;

  @override
  Widget build(BuildContext context) {
    final color = isVeg ? Colors.green : Colors.red;

    return Container(
      width: size,
      height: size,
      padding: EdgeInsets.all(size * .1),
      decoration: BoxDecoration(
          border: Border.all(color: color, width: 2),
          borderRadius: BorderRadius.circular(2)),
      child: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
        ),
      ),
    );
  }
}

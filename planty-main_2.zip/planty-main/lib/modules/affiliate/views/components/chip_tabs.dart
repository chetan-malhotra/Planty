import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:planty_homes/modules/affiliate/controllers/affiliate_controller.dart';

import '../../models/affiliate_order.dart';

class TabsHome extends GetView<AffiliateController> {
  const TabsHome({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AffiliateController>(
      builder: (controller) => Container(
        height: 40,
        width: double.infinity,
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.fromLTRB(8, 0, 0, 0),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomChip(
                "Preparing (${controller.getLength(OrderStatus.preparing)})",
                isActive: controller.filter == OrderStatus.preparing,
                onTap: () => controller.filter = OrderStatus.preparing,
              ),
              CustomChip(
                "Ready (${controller.getLength(OrderStatus.ready)})",
                isActive: controller.filter == OrderStatus.ready,
                onTap: () => controller.filter = OrderStatus.ready,
              ),
              CustomChip(
                "Picked up (${controller.getLength(OrderStatus.pickedUp)})",
                isActive: controller.filter == OrderStatus.pickedUp,
                onTap: () => controller.filter = OrderStatus.pickedUp,
              ),
              CustomChip(
                "All (${controller.orders.length})",
                isActive: controller.filter == null,
                onTap: () => controller.filter = null,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CustomChip extends StatelessWidget {
  const CustomChip(
    this.text, {
    super.key,
    this.color = const Color(0x80000000),
    this.isActive = false,
    this.activeColor = Colors.red,
    this.onTap,
  });
  final String text;
  final bool isActive;
  final Color color;
  final Color activeColor;
  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.only(left: 8),
        child: Chip(
          side: BorderSide(color: isActive ? activeColor : color),
          padding: const EdgeInsets.all(0),
          label: Text(text,
              style: TextStyle(color: isActive ? activeColor : color)),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:planty_homes/modules/affiliate/controllers/affiliate_controller.dart';

import '../models/affiliate_order.dart';
import 'components/order_card_view.dart';

class NewOrdersView extends GetView<AffiliateController> {
  const NewOrdersView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final list = controller.unacceptedOrders;

    return Scaffold(
      appBar: AppBar(
        leading: null,
        automaticallyImplyLeading: false,
        title: Obx(() {
          return Text(
            "${list.length} new order${list.length > 1 ? "s" : ""}",
            style: const TextStyle(color: Colors.white),
          );
        }),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
              onPressed: () {
                Get.back();
              },
              icon: const Padding(
                padding: EdgeInsets.all(8),
                child: Icon(
                  Icons.close,
                  size: 26,
                  color: Colors.white,
                ),
              ))
        ],
      ),
      body: Obx(() {
        if (list.isEmpty) {
          return const Center(
            child: Text("Waiting for orders"),
          );
        }
        return ListView(
          children: [
            for (final item in list)
              OrderCard(
                order: item,
                onReject: () {
                  list.remove(item);
                },
                onAccept: () {
                  var acceptedOrder = item;
                  acceptedOrder.status = OrderStatus.preparing;
                  controller.addOrder(acceptedOrder);
                  list.remove(item);
                },
              ),
          ],
        );
      }),
    );
  }}

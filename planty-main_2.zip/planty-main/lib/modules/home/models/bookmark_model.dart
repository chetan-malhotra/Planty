import 'package:planty_homes/data/models/nursery_model.dart';

import '../../../data/models/plants_model.dart';

class Bookmark<T> {
  String id;
  T value;
  Bookmark(this.id, this.value);
}

class BookmarkPlant extends Bookmark {
  BookmarkPlant(super.id, Plant super.value);
}

class BookmarkNursery extends Bookmark {
  BookmarkNursery(super.id, Nursery super.value);
}

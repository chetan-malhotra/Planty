

import 'package:planty_homes/data/models/plants_model.dart';
import 'package:planty_homes/data/utils/server_utils.dart';

import '../../../../data/models/nursery_model.dart';
import '../../../../data/utils/logger.dart';

class SearchReturn {
  List<Nursery> nursery;
  List<Plant> plant;
  SearchReturn(this.nursery, this.plant);
}

class SearchServer extends NewServer {
  Future<Result<SearchReturn?>> search(String query, [skip = 0]) async {
    final res = await handlePostRequest("/api/search", {
      'searchQuery': query,
      'skip': skip,
    });
    
    if(!res.isPass) return Result.fail(res.msg);

    final nurseries = <Nursery>[];
    final plants = <Plant>[];

    final rn = res.data["nurseries"];
    final rp = res.data["plants"];
    for(int i = 0; i < (rn.length ?? 0); i++){
      nurseries.add(Nursery.fromJson(rn[i]));
    }
    for(int i = 0; i < (rp.length ?? 0); i++){
      plants.add(Plant.fromJson(rp[i]));
    }
    
    return Result.pass("", SearchReturn(nurseries, plants));

  }
}

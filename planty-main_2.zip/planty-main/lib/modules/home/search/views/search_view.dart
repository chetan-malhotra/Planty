import 'package:flutter/material.dart' hide SearchController;
import 'package:get/get.dart';
import 'package:planty_homes/data/constants/theme.dart';
import 'package:planty_homes/data/models/plants_model.dart';
import 'package:planty_homes/global_components/titled.dart';
import 'package:planty_homes/modules/home/search/views/search_grid_view.dart';
import 'package:planty_homes/modules/home/views/components/nursery_card.dart';
import 'package:planty_homes/modules/home/views/components/searchbar.dart';

import '../../../../data/models/nursery_model.dart';
import '../controllers/search_controller.dart';

class SearchView extends GetView<SearchController> {
  const SearchView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (controller.isPlantOnly.value) {
          controller.handleOnlyPlants(false);
          return false;
        } else {
          return true;
        }
      },
      child: Scaffold(
        body: Obx(() {
          return CustomScrollView(
            slivers: [
              SliverAppBar(
                floating: true,
                snap: true,
                centerTitle: false,
                pinned: true,
                bottom: PreferredSize(
                  preferredSize: const Size(double.infinity, 75),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SearchBarWidget(
                        controller: controller.searchController,
                        onSubmit: controller.search,
                        height: 50,
                        fontSize: 18,
                        margin: const EdgeInsets.symmetric(
                            vertical: 8, horizontal: 16),
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.all(8.0),
                      //   child: CategoryList(),
                      // ),
                    ],
                  ),
                ),
              ),
              ..._renderPage(),
            ],
          );
        }),
      ),
    );
  }

  List<Widget> _renderPage() {
    if (controller.isPageLoading.value) {
      return _renderLoadingPage();
    }

    if (controller.resultedPlants.isEmpty &&
        controller.resultedNurseries.isEmpty) {
      return [
        const SliverFillRemaining(
          hasScrollBody: false,
          child: Center(
            child: Titled("Nothing Found"),
          ),
        )
      ];
    }

    if (!controller.isPlantOnly.value) {
      return _renderFirst();
    }

    List<Widget> list = [SearchGridView(controller)];
    return list;
  }

  List<Widget> _renderLoadingPage() {
    return [
      const SliverFillRemaining(
        hasScrollBody: false,
        child: Center(child: CircularProgressIndicator.adaptive()),
      )
    ];
  }

  List<Widget> _renderFirst() {
    final list = <Widget>[];
    if (controller.resultedPlants.isNotEmpty) {
      list.addAll([
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Text("Latest Plants", style: TextStyles.heading1),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 340,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: controller.resultedPlants.length + 1,
              itemBuilder: (context, index) {
                if (index >= controller.resultedPlants.length) {
                  return ViewMoreButton(
                    onTap: controller.handleOnlyPlants,
                  );
                }
                return PlantHorizontalCard(controller.resultedPlants[index]);
              },
            ),
          ),
        ),
      ]);
    }

    if (controller.resultedNurseries.isNotEmpty) {
      list.addAll([
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text("Related Nurseries", style: TextStyles.heading1),
          ),
        ),
        SliverList.builder(
          itemCount: controller.resultedNurseries.length,
          itemBuilder: (ctx, index) {
            return NurseryHorizontalCard(controller.resultedNurseries[index]);
          },
        ),
      ]);
    }
    return list;
  }
}

class ViewMoreButton extends StatelessWidget {
  const ViewMoreButton({
    super.key,
    this.onTap,
  });

  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
          width: 120,
          height: 120,
          margin: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 16)
            ],
          ),
          alignment: Alignment.center,
          child: const Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.skip_next),
              Text(
                "View More",
                style: TextStyles.body1,
              ),
            ],
          )),
    );
  }
}

class NurseryHorizontalCard extends StatelessWidget {
  const NurseryHorizontalCard(this.nursery, {super.key});

  final Nursery nursery;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 160,
      width: double.infinity,
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 16)
          ]),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Row(
          children: [
            const Expanded(
                flex: 2,
                child: SizedBox.expand(
                  child: Image(
                    image: AssetImage("assets/green_house.jpg"),
                    fit: BoxFit.cover,
                  ),
                )),
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      nursery.nurseryName,
                      maxLines: 2,
                      style: TextStyles.heading3
                          .copyWith(overflow: TextOverflow.ellipsis),
                    ),
                    SizedBox(
                      width: 120,
                      child: Text(
                        nursery.city,
                        style: TextStyles.body1.copyWith(
                            color: Colors.grey,
                            overflow: TextOverflow.ellipsis),
                      ),
                    ),
                    const Spacer(),
                    const MiniRatingTag(
                      4.6,
                      size: 14,
                      iconColor: Colors.amber,
                      reviews: 1100,
                      textColor: Colors.black,
                      color: Colors.transparent,
                      padding: EdgeInsets.zero,
                    ),
                    const Spacer(),
                    Text(
                      "₹60 - ₹600",
                      style: TextStyles.heading2.copyWith(color: Colors.green),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class PlantHorizontalCard extends StatelessWidget {
  const PlantHorizontalCard(
    this.plant, {
    super.key,
    this.maxLines = 2,
    this.margin = const EdgeInsets.all(16),
    this.height = 300,
    this.width = 200,
  });

  final Plant plant;
  final EdgeInsets margin;
  final int maxLines;
  final double height;
  final double width;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      width: width,
      height: height,
      decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 16)
          ],
          borderRadius: BorderRadius.circular(16)),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Column(children: [
          const Expanded(
              child: SizedBox.expand(
            child: Image(
              image: AssetImage("assets/arnold_plant.jpg"),
              fit: BoxFit.cover,
            ),
          )),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.all(12),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                plant.nurseryName,
                style: TextStyles.body1.copyWith(
                    color: Colors.grey, overflow: TextOverflow.ellipsis),
              ),
              Text(plant.name,
                  maxLines: maxLines,
                  style: TextStyles.heading3.copyWith(
                    overflow: TextOverflow.ellipsis,
                  )),
              const Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // MiniRatingTag(
                  //   plant.details.,
                  //   padding: EdgeInsets.zero,
                  //   reviews: 160,
                  //   color: Colors.transparent,
                  //   iconColor: Colors.amber,
                  //   textColor: Colors.black,
                  // ),
                  Text(
                    plant.price.toString(),
                    style: TextStyles.heading2.copyWith(color: Colors.green),
                  ),
                ],
              ),
            ]),
          )),
        ]),
      ),
    );
  }
}

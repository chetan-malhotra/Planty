import 'package:planty_homes/data/constants/export.dart';

import '../../controllers/stt_controller.dart';

class STTDialog extends GetView<STTController> {
  const STTDialog({
    super.key,
    this.onSearch,
    this.listenOnStart = false,
  });

  final void Function(String)? onSearch;
  final bool listenOnStart;

  @override
  Widget build(BuildContext context) {
    if (listenOnStart) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        controller.startListening(onSearch);
      });
    }
    return AlertDialog(
      title: const Text("Speech To Text"),
      actions: [
        IconButton(
            color: Colors.white,
            style: const ButtonStyle(
              backgroundColor: MaterialStatePropertyAll(Colors.green),
            ),
            onPressed: () {
              controller.startListening(onSearch);
            },
            icon: const Icon(Icons.mic)),
      ],
      content: SizedBox(
        height: 120,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Obx(() => Text(controller.recognizedWords.value)),
            ],
          ),
        ),
      ),
    );
  }
}

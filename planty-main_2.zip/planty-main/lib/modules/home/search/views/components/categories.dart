import 'package:flutter/material.dart' hide SearchController;
import 'package:get/get.dart';

class CategoryListController extends GetxController {
  List<String> totalFilters = ["Gifts", "Ceramic", "FastDelivery"].obs;
  List<String> filters = <String>[].obs;
  List<String> sortList = [
    "sort",
    "latest",
    "nearest",
    "fast delivery",
  ].obs;
  var sort = "sort".obs;
}

class CategoryList extends StatelessWidget {
  CategoryList({super.key, this.margin});

  final EdgeInsets? margin;
  final controller = CategoryListController();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: margin,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Obx(() {
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                padding: const EdgeInsets.symmetric(horizontal: 12),
                height: 35,
                decoration: BoxDecoration(
                    border: Border.all(width: 1),
                    borderRadius: BorderRadius.circular(8)),
                child: DropdownButton<String>(
                  value: controller.sort.value,
                  underline: const SizedBox(),
                  items: controller.sortList
                      .map<DropdownMenuItem<String>>((e) => DropdownMenuItem(
                            value: e,
                            child: Text(e),
                          ))
                      .toList(),
                  onChanged: (item) {
                    controller.sort.value = item ?? "sort";
                  },
                ),
              );
            }),
            ..._renderChips()
          ],
        ),
      ),
    );
  }

  List<Widget> _renderChips() {
    final list = <Widget>[];
    for (final item in controller.totalFilters) {
      list.add(Chip(label: Text(item)));
      list.add(const SizedBox(width: 12));
    }
    return list;
  }
}

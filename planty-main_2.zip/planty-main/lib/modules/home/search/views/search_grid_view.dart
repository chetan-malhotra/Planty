import 'package:flutter/material.dart' hide SearchController;

import 'package:planty_homes/modules/home/search/views/search_view.dart';

import '../controllers/search_controller.dart';

class SearchGridView extends StatelessWidget {
  const SearchGridView(
    this.controller, {
    Key? key,
    this.margin = const EdgeInsets.all(16),
  }) : super(key: key);

  final EdgeInsets margin;
  final SearchController controller;

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    int calculateCrossAxisCount() {
      const itemWidth = 230.0;
      // print(size.width / itemWidth);
      final crossAxisCount = (size.width / itemWidth).floor();
      return crossAxisCount > 2 ? crossAxisCount : 2;
    }

    return SliverPadding(
      padding: margin,
      sliver: SliverGrid.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: calculateCrossAxisCount(),
          childAspectRatio: 3 / 5,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
        ),
        itemCount: controller.resultedPlants.length,
        itemBuilder: (BuildContext context, int index) {
          return Transform.scale(
            key: Key("grid index $index"),
            scale: .99,
            child: PlantHorizontalCard(
              controller.resultedPlants[index],
              margin: EdgeInsets.zero,
            ),
          );
        },
      ),
    );
  }
}

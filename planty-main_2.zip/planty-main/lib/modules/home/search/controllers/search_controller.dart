import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/modules/home/controllers/feed_controller.dart';

import '../../../../data/models/nursery_model.dart';
import '../../../../data/models/plants_model.dart';
import '../../../../data/utils/logger.dart';
import '../services/search.dart';

class SearchController extends GetxController {
  String searchText = Get.arguments;
  late TextEditingController searchController;
  final feed = Get.find<FeedController>();
  final server = Get.put(SearchServer());

  final resultedNurseries = <Nursery>[];
  final resultedPlants = <Plant>[];

  void search(String query) async {
    isPageLoading(true);
    FocusScope.of(Get.context!).unfocus();
    final res = await server.search(query);
    if(res.isPass){
      resultedPlants.removeWhere((element) => true);
      resultedNurseries.addAll(res.data?.nursery ?? []);
      resultedPlants.removeWhere((element) => true);
      resultedPlants.addAll(res.data?.plant ?? []);
    }
    // await Future.delayed(const Duration(milliseconds: 600));
    // final nurseries = feed.allNurseries;
    // List<SNursery> nurseriesRes = [];
    // List<AvailablePlant> plantsRes = [];
    //
    // resultedNurseries.removeWhere((e) => true);
    // resultedPlants.removeWhere((e) => true);
    //
    // // Search for nurseries
    // for (Nursery nursery in nurseries) {
    //   if (_matchesSearchQuery(nursery, query)) {
    //     resultedNurseries.add(nursery);
    //   }
    // }
    //
    // // Search for plants
    // for (Nursery nursery in resultedNurseries) {
    //   List<Plant> matchingPlants = nursery.plants
    //       .expand((plants) => plants)
    //       .where((plant) => _matchesSearchQuery(plant, query))
    //       .toList();
    //   resultedPlants.addAll(matchingPlants);
    // }
    //
    // // If nurseries have no matching results, include parent nurseries of plants
    // if (resultedNurseries.isEmpty && resultedPlants.isNotEmpty) {
    //   resultedNurseries.addAll(resultedPlants
    //       .map((plant) =>
    //           nurseries.firstWhere((nursery) => nursery.id == plant.nurseryId))
    //       .toSet());
    // }
    //
    // // If plants have no matching results, include plants from resulted nurseries
    // if (resultedPlants.isEmpty && resultedNurseries.isNotEmpty) {
    //   resultedPlants.addAll(resultedNurseries.expand(
    //       (nursery) => nursery.availablePlants.expand((plants) => plants)));
    // }
    // resultedPlants.addAll(plantsRes);
    // resultedNurseries.addAll(nurseriesRes);
    isPageLoading(false);
    update();
  }

  // bool _matchesSearchQuery(dynamic item, String query) {
  //   if (item is SNursery) {
  //     return _matchesSearchQuery(item.nurseryName, query) ||
  //         _matchesSearchQuery(item.address, query) ||
  //         _matchesSearchQuery(item.city, query) ||
  //         _matchesSearchQuery(item.state, query) ||
  //         _matchesSearchQuery(item.country, query) ||
  //         item.availablePlants.any((plants) =>
  //             plants.any((plant) => _matchesSearchQuery(plant, query)));
  //   } else if (item is AvailablePlant) {
  //     return _matchesSearchQuery(item.name, query) ||
  //         _matchesSearchQuery(item.nurseryName, query) ||
  //         _matchesSearchQuery(item.details.plantName, query) ||
  //         _matchesSearchQuery(item.details.description, query);
  //   } else if (item is String) {
  //     print({item, query, item.toLowerCase().contains(query.toLowerCase())});
  //     return item.toLowerCase().contains(query.toLowerCase());
  //   }
  //   return false;
  // }

  @override
  void onInit() {
    super.onInit();
    logger.e("searching $searchText");
    searchController = TextEditingController(text: searchText);
    search(searchText);
  }

  var isPlantOnly = false.obs;

  var isPageLoading = false.obs;
  var isMoreLoading = false.obs;

  void handleOnlyPlants([bool value = true]) {
    isPageLoading.value = true;
    Future.delayed(const Duration(milliseconds: 600), () {
      isPlantOnly.value = value;
      isPageLoading.value = false;
    });
  }
}

import 'package:get/get.dart';
import 'package:planty_homes/routes/app_pages.dart';

import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../views/components/stt_dialog.dart';

class STTController extends GetxController {
  void showSTTDialog() {
    Get.dialog(const STTDialog(listenOnStart: true));
  }

  late final stt.SpeechToText _speechToText;

  @override
  void onInit() {
    super.onInit();
    _speechToText = stt.SpeechToText();
  }

  bool _isListening = false;

  var recognizedWords = "".obs;

  void startListening([void Function(String)? onDone]) async {
    bool available = await _speechToText.initialize(
      onStatus: (status) {
        // print('Speech status: $status');
        if (status == stt.SpeechToText.listeningStatus) {
          _isListening = true;
        }
      },
      onError: (error) => print('Speech error: $error'),
    );
    if (!available) {
      return;
    }

    recognizedWords.value = "";

    if (!_isListening) {
      _isListening = true;

      _speechToText.listen(
        onResult: (result) {
          recognizedWords.value = result.recognizedWords;
          if (result.finalResult) {
            if (recognizedWords.value.isEmpty) {
              stopListening((str) {});
              print("nothing searched");
            } else if (onDone != null) {
              stopListening();
              onDone.call(recognizedWords.value);
            } else {
              stopListening();
              Get.toNamed(Routes.SEARCH, arguments: recognizedWords.value);
            }
          }
        },
        listenMode: stt.ListenMode.search,
      );
      update();
    } else {
      print("loggnig not listening");
      stopListening(onDone);
      // startListening();
    }
  }

  void stopListening([void Function(String)? onDone]) {
    if (_isListening) {
      _speechToText.stop();
      _isListening = false;
      update();
      if (onDone != null) {
        onDone.call(recognizedWords.value);
      } else {
        Get.offAndToNamed(Routes.SEARCH, arguments: recognizedWords.value);
      }
    }
  }

  @override
  void onClose() {
    _speechToText.cancel();
    super.onClose();
  }
}

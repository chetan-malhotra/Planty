import 'package:get/get.dart';

import 'package:planty_homes/modules/cart/controllers/cart_controller.dart';
import 'package:planty_homes/modules/home/controllers/bookmarks_controller.dart';
import 'package:planty_homes/modules/home/controllers/feed_controller.dart';
import 'package:planty_homes/modules/home/services/home_server.dart';

import '../controllers/home_controller.dart';

class HomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(HomeServer());
    Get.lazyPut<FeedController>(() => FeedController());
    Get.lazyPut<HomeController>(() => HomeController());
    Get.put<BookmarksController>(BookmarksController(), permanent: true);
    Get.put<CartController>(CartController(), permanent: true);
  }
}

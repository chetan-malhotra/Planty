import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:planty_homes/data/constants/theme.dart';
import 'package:planty_homes/modules/home/views/components/nursery_card.dart';

import '../../nursery/views/components/plant_item_card.dart';
import '../../nursery/views/plant_view.dart';
import '../controllers/bookmarks_controller.dart';

class BookmarksView extends GetView<BookmarksController> {
  const BookmarksView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        body: CustomScrollView(slivers: [
          SliverAppBar(
            title: const Text('Bookmarks', style: TextStyles.heading1),
            floating: true,
            snap: true,
            centerTitle: false,
            pinned: true,
            bottom: PreferredSize(
              preferredSize: const Size(double.infinity, 110),
              child: Column(
                children: [
                  Container(
                    height: 65,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: SearchBar(
                      elevation: const MaterialStatePropertyAll(0),
                      leading: const Padding(
                        padding:
                            EdgeInsets.symmetric(vertical: 0, horizontal: 8),
                        child: Icon(Icons.search),
                      ),
                      backgroundColor:
                          MaterialStatePropertyAll(Colors.grey.shade200),
                      hintText: "Search...",
                      textStyle: const MaterialStatePropertyAll(
                          TextStyle(height: 1.15)),
                      hintStyle:
                          const MaterialStatePropertyAll(TextStyle(height: 1)),
                      shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12))),
                    ),
                  ),
                  const TabBar(
                    labelPadding: EdgeInsets.all(8),
                    tabs: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Symbols.potted_plant),
                          SizedBox(width: 8),
                          Text("Plants & Saplings"),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Symbols.nest_multi_room),
                          SizedBox(width: 8),
                          Text("Nurseries"),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
          SliverFillRemaining(
            child: Obx(
              () => TabBarView(
                children: [
                  controller.plants.isEmpty
                      ? const Center(
                          child: Text("No Bookmarks yet"),
                        )
                      : ListView.builder(
                          itemCount: controller.plants.length,
                          itemBuilder: (ctx, index) {
                            return PlantItemCard(
                              controller.plants[index],
                              onTap: () =>
                                  Get.to(PlantView(controller.plants[index])),
                            );
                          },
                        ),
                  controller.nurseries.isEmpty
                      ? const Center(
                          child: Text("No Bookmarks yet"),
                        )
                      : ListView.builder(
                          itemCount: controller.nurseries.length,
                          itemBuilder: (ctx, index) {
                            return NurseryCardHorizontal(
                                controller.nurseries[index]);
                          },
                        )
                ],
              ),
            ),
          )
        ]),
      ),
    );
  }
}

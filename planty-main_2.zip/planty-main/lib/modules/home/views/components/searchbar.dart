import 'package:flutter/material.dart' hide SearchController;
import 'package:get/get.dart';
import 'package:planty_homes/modules/home/search/controllers/stt_controller.dart';

class SearchBarWidget extends StatelessWidget {
  SearchBarWidget({
    Key? key,
    required this.controller,
    this.onSubmit,
    this.height = 50,
    this.width = double.infinity,
    this.margin,
    this.fontSize = 14,
  }) : super(key: key);

  final EdgeInsets? margin;
  final double fontSize;
  final double height;
  final double width;
  final Function(String)? onSubmit;
  final TextEditingController controller;

  final sttController = Get.put(STTController());

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      margin: margin,
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(.2),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: TextFormField(
          controller: controller,
          onFieldSubmitted: onSubmit,
          style: TextStyle(
              height: 1, fontSize: fontSize, fontWeight: FontWeight.w500),
          decoration: InputDecoration(
            alignLabelWithHint: true,
            contentPadding:
                EdgeInsets.symmetric(vertical: (height - fontSize) / 2),
            icon: const InkWell(child: Icon(Icons.search)),
            suffixIcon: GetBuilder<STTController>(
                init: sttController,
                builder: (controller) {
                  return IconButton(
                    onPressed: controller.showSTTDialog,
                    icon: const Icon(Icons.mic),
                  );
                }),
            hintText: 'Try Searching a nursery or a plant..',
            hintStyle: TextStyle(
                height: 1, fontSize: fontSize, fontWeight: FontWeight.w500),
            border: InputBorder.none,
          ),
        ),
      ),
    );
  }
}

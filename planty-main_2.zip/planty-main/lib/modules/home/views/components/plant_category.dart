import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/routes/app_pages.dart';

class Avatars {
  final String search;
  final String image;
  const Avatars(this.search, this.image);
}

const list = <Avatars>[
  Avatars("veg", "assets/avatars/vegies.jpg"),
  Avatars("medicinal", "assets/avatars/medicinal.jpg"),
  Avatars("spices", "assets/avatars/spices.jpg"),
  Avatars("flower", "assets/avatars/flower.jpg"),
];
const list2 = <Avatars>[
  Avatars("fruit", "assets/avatars/fruit.jpg"),
  Avatars("vastu", "assets/avatars/vastu.jpg"),
  Avatars("indoor", "assets/avatars/indoor.jpeg"),
  Avatars("outdoor", "assets/avatars/outdoor.jpg"),
];

class PlantCategory extends StatelessWidget {
  const PlantCategory({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 15,
          vertical: 15,
        ),
        child: Column(
          children: [
            Row(
              children: [
                for (final item in list)
                  InkWell(
                    onTap: () {
                      Get.toNamed(Routes.SEARCH, arguments: item.search);
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 42,
                            backgroundImage: AssetImage(item.image),
                          ),
                          const SizedBox(height: 4),
                          Text(item.search),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
              for(final item in list2)
                InkWell(
                    onTap: () {
                      Get.toNamed(Routes.SEARCH, arguments: item.search);
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 42,
                            backgroundImage: AssetImage(item.image),
                          ),
                          const SizedBox(height: 4),
                          Text(item.search),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

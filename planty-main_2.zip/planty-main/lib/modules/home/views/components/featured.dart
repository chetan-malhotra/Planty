import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:planty_homes/global_components/random_image.dart';
import 'package:planty_homes/modules/home/controllers/feed_controller.dart';

import '../../../../data/models/nursery_model.dart';

class FeaturedWidget extends GetView<FeedController> {
  const FeaturedWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final nurseries = controller.featuredNurseries;
      return Container(
        padding: const EdgeInsets.all(16),
        height: 350,
        child: ListView.builder(
          itemCount: controller.featuredNurseries.length,
          scrollDirection: Axis.horizontal,
          itemBuilder: (ctx, index) {
            return FeaturedCard(nurseries[index]);
          },
        ),
      );
    });
  }
}

class FeaturedCard extends StatelessWidget {
  const FeaturedCard(
    this.nursery, {
    super.key,
  });

  final Nursery nursery;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Get.toNamed("/nursery", arguments: nursery);
      },
      child: Container(
        margin: const EdgeInsets.all(8),
        width: 190,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(.1), blurRadius: 8),
          ],
          borderRadius: BorderRadius.circular(15),
        ),
        child: Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: double.infinity,
                    height: 170,
                    child: RandomImageWidget(),
                  ),
                  Container(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          nursery.nurseryName,
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(Symbols.phone, size: 16),
                            const SizedBox(width: 4),
                            Text(
                              nursery.ownerContact.toString(),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          nursery.city,
                        ),
                        // const Row(
                        //   children: [
                        //     Icon(
                        //       Symbols.distance,
                        //       size: 18,
                        //     ),
                        //     Text("3KM"),
                        //     Spacer(),
                        //     Text("₹ 450 (min.)"),
                        //   ],
                        // )
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // const Positioned(
            //   top: 0,
            //   left: 0,
            //   child: MiniRatingTag(
            //     4.5,
            //     radius: BorderRadius.only(bottomRight: Radius.circular(16)),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}

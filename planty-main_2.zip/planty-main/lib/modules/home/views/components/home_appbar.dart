import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/data/constants/theme.dart';
import 'package:planty_homes/modules/cart/controllers/cart_controller.dart';

import '../../../../routes/app_pages.dart';
import 'searchbar.dart';

class HomeAppBar extends GetView {
  HomeAppBar({
    super.key,
    required this.searchController,
  });

  final TextEditingController searchController;
  final cartController = Get.find<CartController>();

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      floating: true,
      snap: true,
      centerTitle: false,
      pinned: true,
      backgroundColor: Colors.white,
      titleSpacing: 0,
      title: Obx(() {
        Widget addressWidget =
            const Text("Select Address", style: TextStyles.heading2);
        if (cartController.address.value != null) {
          addressWidget = Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                cartController.address.value!.name,
                softWrap: false,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  overflow: TextOverflow.fade,
                ),
              ),
              Text(
                cartController.address.value.toString(),
                softWrap: false,
                style: const TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 14,
                  overflow: TextOverflow.fade,
                ),
              ),
            ],
          );
        }
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.only(left: 16, top: 16, bottom: 16),
          child: InkWell(
            onTap: cartController.handleChangeAddress,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  const Icon(Icons.location_on_rounded,
                      size: 28, color: Colors.green),
                  const SizedBox(width: 20),
                  Expanded(child: addressWidget),
                ],
              ),
            ),
          ),
        );
      }),
      actions: [
        Container(
            margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 16),
            child: InkWell(
              onTap: () {
                Get.toNamed("/settings");
              },
              child: const CircleAvatar(
                child: Icon(Icons.person_2),
              ),
            ))
      ],
      bottom: PreferredSize(
        preferredSize: const Size(double.infinity, 65),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SearchBarWidget(
                controller: searchController,
                fontSize: 16,
                onSubmit: (text) {
                  Get.toNamed(Routes.SEARCH, arguments: text);
                },
                margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 16),
              ),
              // CategoryList(
              //   controller,
              //   margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              // ),
              const SizedBox(height: 4),
            ]),
      ),
    );
  }
}

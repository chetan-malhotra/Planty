import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/global_components/bookmark_button.dart';
import 'package:planty_homes/global_components/random_image.dart';

import '../../../../data/models/nursery_model.dart';
import '../../controllers/bookmarks_controller.dart';

class NurseryCardHorizontal extends StatelessWidget {
  NurseryCardHorizontal(
    this.nursery, {
    super.key,
    this.showBookmark = true,
  });

  final Nursery nursery;
  final bool showBookmark;
  final bookmarks = BookmarksController();

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: () => Get.toNamed("/nursery", arguments: nursery),
      child: Container(
          width: double.infinity,
          height: 150,
          margin: const EdgeInsets.all(16),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: Colors.white,
              boxShadow: [
                BoxShadow(blurRadius: 12, color: Colors.black.withOpacity(.1))
              ]),
          // border: Border.all(width: 1, color: Colors.grey.withOpacity(.4))),
          child: Stack(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: ClipRRect(
                      borderRadius:
                          const BorderRadius.horizontal(left: Radius.circular(16)),
                      child: SizedBox.expand(
                        child: RandomImageWidget(),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 4,
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  nursery.nurseryName,
                                  style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                              showBookmark
                                  ? BookmarkButton(
                                      nursery.id,
                                      false,
                                      nursery: nursery,
                                    )
                                  : const SizedBox(),
                            ],
                          ),
                          ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 150),
                            child: Text(
                              nursery.city,
                              softWrap: false,
                              style:
                                  const TextStyle(overflow: TextOverflow.fade),
                            ),
                          ),
                          // const Spacer(),
                          // Row(
                          //   children: [
                          //     const Icon(
                          //       Symbols.distance,
                          //       size: 16,
                          //     ),
                          //     Expanded(
                          //       child: Text("${nursery.distance} KM"),
                          //     ),
                          //   ],
                          // ),
                          // Row(
                          //   children: [
                          //     const Icon(
                          //       Symbols.clock_loader_20,
                          //       size: 16,
                          //     ),
                          //     Text(" ${nursery.distanceInTime}"),
                          //   ],
                          // ),
                          // const Spacer(),
                        ],
                      ),
                    ),
                  )
                ],
              ),
              Positioned(
                top: 0,
                left: 16,
                child: MiniRatingTag(
                  4.2,
                  color: colorScheme.background,
                  textColor: colorScheme.onBackground,
                  radius: const BorderRadius.vertical(
                    bottom: Radius.circular(12),
                  ),
                ),
              ),
            ],
          )),
    );
  }
}

class MiniRatingTag extends StatelessWidget {
  const MiniRatingTag(
    this.rating, {
    this.color = Colors.green,
    this.size = 16,
    this.textColor = Colors.white,
    this.iconColor,
    this.padding = const EdgeInsets.all(8),
    this.reviews,
    this.margin,
    this.radius,
    this.width,
    this.height,
    this.shadow,
    super.key,
  });

  final double rating;
  final int? reviews;
  final double size;
  final Color color;
  final Color textColor;
  final Color? iconColor;
  final EdgeInsets padding;
  final EdgeInsets? margin;
  final BorderRadius? radius;
  final double? width;
  final double? height;
  final List<BoxShadow>? shadow;

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: padding,
        margin: margin,
        width: width,
        height: height,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: color,
          borderRadius: radius ?? BorderRadius.circular(8),
          boxShadow: shadow,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              Icons.star_rounded,
              size: size,
              color: iconColor ?? textColor,
            ),
            Text(
              " $rating${reviews != null ? " | $reviews" : ""}",
              style: TextStyle(
                height: 1,
                fontSize: size,
                fontWeight: FontWeight.w500,
                color: textColor,
              ),
            ),
          ],
        ));
  }
}

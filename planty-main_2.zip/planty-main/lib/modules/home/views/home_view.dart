import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() {
        return controller.pages[controller.bottomNavIndex.value];
      }),
      bottomNavigationBar: Obx(() {
        return NavigationBar(
          height: 70,
          selectedIndex: controller.bottomNavIndex.value,
          onDestinationSelected: controller.bottomNavIndex,
          destinations: const <NavigationDestination>[
            NavigationDestination(
              selectedIcon: Icon(Icons.home),
              icon: Icon(Icons.home_outlined),
              label: 'Home',
            ),
            // NavigationDestination(
            //   selectedIcon: Icon(Icons.local_post_office),
            //   icon: Icon(Icons.local_post_office_outlined),
            //   label: 'menu',
            // ),
            NavigationDestination(
              selectedIcon: Icon(Icons.bookmark),
              icon: Icon(Icons.bookmark_border),
              label: 'bookmarks',
            ),
            NavigationDestination(
              selectedIcon: Icon(Icons.shopping_cart_rounded),
              icon: Icon(Icons.shopping_cart_outlined),
              label: 'Cart',
            ),
          ],
        );
      }),
    );
  }
}

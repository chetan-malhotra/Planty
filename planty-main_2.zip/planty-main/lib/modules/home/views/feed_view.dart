import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../../../global_components/titled.dart';
import '../controllers/feed_controller.dart';
import 'components/carousel.dart';
import 'components/featured.dart';
import 'components/home_appbar.dart';
import 'components/plant_category.dart';

class FeedView extends GetView<FeedController> {
  const FeedView({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: controller.loadItems,
      child: CustomScrollView(
        // controller: controller.scrollController,
        slivers: [
          HomeAppBar(searchController: controller.searchController),
          SliverList(
              delegate: SliverChildListDelegate([
            const CarouselWidget(),
            // CategoryList(
            //   margin: const EdgeInsets.all(8),
            // ),
            const Titled("What to plant today?"),
            const PlantCategory(),
            const SizedBox(height: 16),
            const Titled("Featured"),
            const FeaturedWidget(),
            const Titled("Nurseries near you."),
          ])),
          Obx(() {
            if (controller.isLoading.value) {
              return SliverToBoxAdapter(
                child: Container(
                  alignment: Alignment.center,
                  child: const SizedBox.square(
                      dimension: 40, child: CircularProgressIndicator()),
                ),
              );
            }
            return SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  if (index < controller.lazyWidgets.length) {
                    return controller.lazyWidgets[index];
                  } else if (controller.isLoading.value ||
                      controller.shouldLoadMore()) {
                    return const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    );
                  } else {
                    return const SizedBox.shrink();
                  }
                },
                childCount: controller.lazyWidgets.length /* + 1 */,
              ),
            );
          }),
          const SliverToBoxAdapter(
              child: SizedBox(
            height: 40,
          ))
        ],
      ),
    );
  }
}

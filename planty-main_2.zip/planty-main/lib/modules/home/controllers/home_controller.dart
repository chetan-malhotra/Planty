import 'package:get/get.dart';
import 'package:planty_homes/modules/home/views/bookmarks_view.dart';
import 'package:planty_homes/modules/home/views/feed_view.dart';

import '../../cart/views/cart_view.dart';

class HomeController extends GetxController {
  final pages = const [
    FeedView(),
    // FeedView(),
    BookmarksView(),
    CartView(),
  ];

  var bottomNavIndex = 0.obs;
}

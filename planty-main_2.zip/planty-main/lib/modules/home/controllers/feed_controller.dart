import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/data/utils/snackbar.dart';
import 'package:planty_homes/modules/home/services/home_server.dart';

import '../../../data/models/generated_models.dart';
import '../../../data/models/nursery_model.dart';
import '../views/components/nursery_card.dart';

class FeedController extends GetxController {
  // final scrollController = ScrollController();
  final searchController = TextEditingController();
  final server = Get.find<HomeServer>();
  final allNurseries = <Nursery>[].obs;

  final featuredNurseries = <Nursery>[].obs;
  final skip = 0.obs;

  var isLoading = false.obs;

  // void _scrollListener() {
  //   if (scrollController.position.pixels ==
  //       scrollController.position.maxScrollExtent) {
  //     loadItems();
  //   }
  // }

  @override
  void onInit() {
    super.onInit();
    // scrollController.addListener(_scrollListener);
    loadItems();
  }

  List<Widget> lazyWidgets = <Widget>[].obs;

  /// This is now used to HARD REFRESH THE ITEMS
  Future<void> loadItems() async {
    try {
      isLoading(true);
      final result = await server.getNurseries(skip.value);
      if (!result.isPass) {
        isLoading(false);
        SnackBarHelper.showError(result.msg);
        return;
      }
      // final list = decodeResponse(result.data);
      final list = result.data ?? [];
      allNurseries.removeWhere((p0) => true);
      allNurseries.addAll(list);
      lazyWidgets = [];
      final limit = list.length > 5 ? 5 : list.length;
      for (int i = 0; i < limit; i++) {
        featuredNurseries.add(list[i]);
      }
      for (final item in list) {
        lazyWidgets.add(NurseryCardHorizontal(item));
      }
      update();
      isLoading(false);
    } catch (error) {
      SnackBarHelper.showError("Unkonwn Error: $error");
    }
    // Future.delayed(const Duration(seconds: 1), () {
    //   lazyWidgets.addAll([
    //     NurseryCardHorizontal(testNursery1),
    //     NurseryCardHorizontal(testNursery1),
    //     NurseryCardHorizontal(testNursery1),
    //   ]);
    //   isLoading.value = false;
    // });
  }

  List<SNursery> decodeResponse(Map<String, dynamic> response) {
    try {
      List<SNursery> nurseries = [];

      var nurseryJsonList = response['nurseries'] as List<dynamic>;

      for (var nurseryJson in nurseryJsonList) {
        var nursery = SNursery.fromJson(nurseryJson);
        nurseries.add(nursery);
      }

      return nurseries;
    } catch (error) {
      print(error);
      return [];
    }
  }

  bool shouldLoadMore() {
    return lazyWidgets.isEmpty || lazyWidgets.length % 5 != 0;
  }
}

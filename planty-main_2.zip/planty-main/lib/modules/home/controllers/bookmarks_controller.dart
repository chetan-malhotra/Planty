import 'package:get/get.dart';

import '../../../data/models/nursery_model.dart';
import '../../../data/models/plants_model.dart';


class BookmarksController extends GetxController {
  var plants = <Plant>[].obs;
  var nurseries = <Nursery>[].obs;

  bool isPlantBookmark(String id){
    return plants.any((element) => element.id == id);
  }

  bool isNurseryBookmark(String id){
    return nurseries.any((element) => element.id == id);
  }
}

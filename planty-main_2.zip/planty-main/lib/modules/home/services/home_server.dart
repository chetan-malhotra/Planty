import 'package:planty_homes/data/utils/server_utils.dart';

import '../../../data/models/nursery_model.dart';
import '../../../data/utils/logger.dart';

class HomeServer extends NewServer {
  // Future<Result> getAllNurseries() async {
  //   try {
  //     final res = await handleGetRequest(ServerRoute.getAllNurseries);
  //     return Result.pass("WOrks", res.data);
  //   } catch (error) {
  //     return Result.fail("Something went wrong");
  //   }
  // }

  Future<Result<List<Nursery>?>> getNurseries(int skip,
      [int limit = 20]) async {
    final res = await handlePostRequest(
        "/api/getNurseries", {'skip': skip, 'limit': limit});

    try {
      if (!res.isPass) return Result.fail(res.msg);
      final body = res.data;
      final data = List<dynamic>.from(body).map((e) => Nursery.fromJson(e)).toList();
      return Result.pass("Fetched", data);
    } catch (error) {
     return Result.fail("Something went wrong: $error");
    }
  }
}

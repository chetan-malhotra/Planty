import 'dart:convert';
import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart' hide User;
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:get/get.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:planty_homes/data/utils/cache_helper.dart';
import 'package:planty_homes/modules/edit_profile/views/componets/changeProfile.dart';
import 'package:planty_homes/routes/app_pages.dart';

import '../../../controllers/user_controller.dart';
import '../../../data/utils/logger.dart';
import '../../../data/utils/snackbar.dart';
import '../../../data/models/user_model.dart';
import '../../../utils/countries.dart';
import '../services/edit_profile_service.dart';

class EditProfileController extends GetxController {
  final userController = Get.find<UserController>();
  final server = Get.find<ProfileService>();

  var isLoading = false.obs;
  var formKey = GlobalKey<FormState>();
  var name = TextEditingController();
  var phone = TextEditingController();
  var specialAnniversary = TextEditingController();
  var dob = TextEditingController();
  var email = TextEditingController();
  var currentPhoneCountry =
      countries[99].obs; // the element at index 99 is India

  RxString imageBase64 = ''.obs;

  /// ! WARNING: you need to be logged in before you can access this method
  /// TODO: check this function
  User? getUserObject() {
    if (userController.user == null) {
      return null;
    }
    final user = userController.user!;
    if (name.text.isNotEmpty) {
      user.name = name.text;
    }
    if (dob.text.isNotEmpty) user.dob = dob.text;
    if (specialAnniversary.text.isNotEmpty) {
      user.specialAnniversary = specialAnniversary.text;
    }
    // userController.setUser(user);
    return user;
  }

  void pickImageFromGallery() async {
    try {
      final pickedFile =
          await ImagePicker().pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        await _cropImage(pickedFile.path);
      }
    } catch (e) {
      SnackBarHelper.showError('Failed to pick image from gallery');
    }
  }

  void takePhoto() async {
    try {
      final pickedFile =
          await ImagePicker().pickImage(source: ImageSource.camera);
      if (pickedFile != null) {
        await _cropImage(pickedFile.path);
      }
    } catch (e) {
      SnackBarHelper.showError('Failed to take photo');
    }
  }

  Future<void> _cropImage(String imagePath) async {
    try {
      final croppedImage = await ImageCropper().cropImage(
        sourcePath: imagePath,
        aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
        compressQuality: 70,
        uiSettings: [
          AndroidUiSettings(
            toolbarTitle: 'Crop Image',
            toolbarColor: Colors.green,
            toolbarWidgetColor: Colors.white,
            initAspectRatio: CropAspectRatioPreset.square,
            lockAspectRatio: true,
          ),
          IOSUiSettings(
            title: 'Crop Image',
          ),
        ],
      );
      if (croppedImage != null) {
        await _compressImage(croppedImage.path);
      }
    } catch (e) {
      logger.e(e);
      SnackBarHelper.showError('Failed to crop image');
      await _compressImage(imagePath);
    }
  }

  Future<void> _compressImage(String imagePath) async {
    try {
      final bytes = await File(imagePath).readAsBytes();
      final compressedImage = await FlutterImageCompress.compressWithList(
        bytes,
        quality: 70,
      );
      final base64Image = base64Encode(compressedImage);
      imageBase64.value = base64Image;
    } catch (e) {
      logger.e(e);
      SnackBarHelper.showError('Failed to compress image');
    }
  }

  void changeProfilePic() async {
    Get.bottomSheet(const ProfilePickerDialog());
  }

  void handleEmail() {}

  void handlePhone() {}

  String? validateName(String? name) {
    if (name == null || name.isEmpty) {
      return "Name cannot be empty";
    }
    RegExp regex = RegExp(r'^[a-zA-Z\s]+$');
    var isValid = regex.hasMatch(name);
    if (!isValid) {
      return "Only alphabets and spaces allowed";
    }
    return null;
  }

  String? validateEmail(String? email) {
    if (email == null || email.isEmpty) {
      return "email cannot be empty";
    }
    var isValid = email.isEmail;
    if (!isValid) {
      return "The email is invalid";
    }
    return null;
  }

  String? validateNumber(String? number) {
    if (number == null || number.isEmpty) {
      return "number cannot be empty";
    }
    final country = currentPhoneCountry.value;
    if (country.minLength > number.length) {
      return "Number is too short.";
    } else if (country.maxLength < number.length) {
      return "Number is too long.";
    }
    return null;
  }

  void handleSubmit() async {
    if (formKey.currentState!.validate()) {
      final user = getUserObject();
      if (user == null) {
        SnackBarHelper.showError("Something went wrong");
        return;
      }
      isLoading(true);
      final response = await server.updateProfile(user);
      await FirebaseAuth.instance.currentUser?.updateDisplayName(user.name);
      isLoading(false);
      if (response.isPass) {
        SnackBarHelper.showSuccess(response.msg);
        if (Get.routing.current == Get.routing.previous) {
          Get.offAllNamed(Routes.HOME);
        }
      } else {
        SnackBarHelper.showError(response.msg);
      }
    }
  }

  Future<void> selectDate(BuildContext context, {isDob = false}) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );
    if (picked == null) return;
    final dateString = DateFormat("dd/MM/yyyy").format(picked);
    if (isDob) {
      dob.text = dateString;
    } else {
      specialAnniversary.text = dateString;
    }
  }

  @override
  void onInit() async {
    super.onInit();
    refreshUser(offline: false);
    if (userController.user != null) {
      final user = userController.user!;
      name.text = user.name;
      phone.text = user.phone ?? "";
      email.text = user.email ?? "";
      if (user.dob != null) {
        dob.text = user.dob!;
      }
      if (user.dob != null) {
        specialAnniversary.text = user.dob!;
      }
    }

    currentPhoneCountry.value =
        countries.firstWhere((element) => element.name == "India");
  }

  Future<void> refreshUser({offline = false}) async {
    if (offline) {
      final user = CacheHelper.getUserFromCache();
      if (user != null) {
        name.text = user.name;
        email.text = user.email ?? "";
        if (user.dob != null) {
          dob.text = user.dob!;
        }
      }
    } else {
      try {
        logger.i(userController.user);
        final res = await server.getUser(userController.user!.uid);
        logger.i(res);
      } catch (error) {
        logger.i(error);
        SnackBarHelper.showError(error.toString());
      }
    }
  }

  @override
  void onClose() {
    name.dispose();
    email.dispose();
    phone.dispose();
    specialAnniversary.dispose();
    dob.dispose();
    super.onClose();
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/data/utils/snackbar.dart';
import 'package:planty_homes/modules/edit_profile/controllers/edit_profile_controller.dart';

class ProfilePickerDialog extends GetView<EditProfileController> {
  const ProfilePickerDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 150,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ElevatedButton(
            onPressed: () {
              try {
                controller.pickImageFromGallery();
              } catch (e) {
                SnackBarHelper.showError('Failed to open gallery');
              }
              Get.back();
            },
            child: const Text('Choose from Gallery'),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              try {
                controller.takePhoto();
              } catch (e) {
                SnackBarHelper.showError('Failed to open camera');
              }
              Get.back();
            },
            child: const Text('Take a Photo'),
          ),
        ],
      ),
    );
  }
}

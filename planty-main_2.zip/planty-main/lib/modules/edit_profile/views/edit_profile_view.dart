import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:planty_homes/data/constants/theme.dart';
import 'package:planty_homes/global_components/primary_button.dart';

import '../controllers/edit_profile_controller.dart';

class EditProfileView extends GetView<EditProfileController> {
  const EditProfileView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final textStyle = Theme.of(context)
        .textTheme
        .bodyMedium
        ?.copyWith(fontWeight: FontWeight.w600);
    return Scaffold(
      appBar: AppBar(
        title: const Text("Complete Your Profile"),
        elevation: 0,
      ),
      floatingActionButton: Obx(() {
        return PrimaryButton(
          "Update Profile",
          width: double.infinity,
          color: Colors.green,
          onTap: controller.handleSubmit,
          childOverride: controller.isLoading.value
              ? const CircularProgressIndicator()
              : null,
        );
      }),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      body: RefreshIndicator(
        onRefresh: () async {
          await controller.refreshUser();
        },
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Obx(() {
              return Form(
                key: controller.formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: Column(children: [
                        CircleAvatar(
                          radius: 80,
                          backgroundImage: controller
                                  .imageBase64.value.isNotEmpty
                              ? MemoryImage(
                                  base64Decode(controller.imageBase64.value))
                              : null,
                        ),
                        const SizedBox(height: 16),
                        TextButton(
                          onPressed: controller.changeProfilePic,
                          child: const Text(
                            "Change Photo",
                            style: TextStyle(
                                color: Colors.green,
                                fontSize: 17,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                      ]),
                    ),
                    const SizedBox(height: 16),
                    RichText(
                      text: TextSpan(style: textStyle, children: const [
                        TextSpan(text: "Name: "),
                        TextSpan(text: "*", style: TextStyle(color: Colors.red))
                      ]),
                    ),
                    TextFormField(
                      controller: controller.name,
                      validator: controller.validateName,
                      decoration: const InputDecoration(
                          labelStyle: TextStyle(color: Colors.black)),
                    ),
                    const SizedBox(height: 16),
                    RichText(
                      text: TextSpan(style: textStyle, children: [
                        const TextSpan(text: "Phone Number: "),
                        const TextSpan(
                            text: "*", style: TextStyle(color: Colors.red)),
                        TextSpan(
                            text: "\nPhone number cannot be changed",
                            style:
                                TextStyles.body1.copyWith(color: Colors.grey))
                      ]),
                    ),
                    Row(
                      children: [
                        InkWell(
                          onTap: () {},
                          child: Container(
                              height: 18,
                              margin: const EdgeInsets.all(8),
                              child: Text(
                                "${controller.currentPhoneCountry.value.flag}  +${controller.currentPhoneCountry.value.dialCode} ",
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.w500),
                              )),
                        ),
                        Expanded(
                          child: TextFormField(
                            readOnly: true,
                            controller: controller.phone,
                            // validator: controller.validateNumber,
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                              LengthLimitingTextInputFormatter(controller
                                  .currentPhoneCountry.value.maxLength)
                            ],
                            style: const TextStyle(
                                fontWeight: FontWeight.w500, fontSize: 16),
                          ),
                        ),
                        // SizedBox(
                        //   width: 100,
                        //   child: TextButton(
                        //     onPressed: () {},
                        //     child: const Text("change"),
                        //   ),
                        // ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    // RichText(
                    //     text: TextSpan(
                    //   style: textStyle,
                    //   children: const [
                    //     TextSpan(text: "Email ID: "),
                    //     TextSpan(text: "*", style: TextStyle(color: Colors.red))
                    //   ],
                    // )),
                    // Row(
                    //   children: [
                    //     Expanded(
                    //       flex: 3,
                    //       child: TextFormField(
                    //         validator: controller.validateEmail,
                    //         controller: controller.email,
                    //       ),
                    //     ),
                    //     SizedBox(
                    //         width: 100,
                    //         child: TextButton(
                    //           onPressed: controller.handleEmail,
                    //           child: const Text("change"),
                    //         ))
                    //   ],
                    // ),
                    const SizedBox(height: 16),
                    RichText(
                        text: TextSpan(style: textStyle, children: const [
                      TextSpan(text: "Date of Birth: "),
                      TextSpan(text: "*", style: TextStyle(color: Colors.red)),
                      // TextSpan(
                      //     text: "\nThis value is not editable",
                      //     style: TextStyle(
                      //         color: Colors.grey,
                      //         fontSize: 14,
                      //         fontWeight: FontWeight.w500,
                      //         height: 1.2)),
                    ])),
                    TextFormField(
                      readOnly: true,
                      validator: (val) {
                        if (val == null) return "Date of Birth is required";
                        if (val.isEmpty == true) {
                          return "Date of Birth is required";
                        }
                        return null;
                      },
                      controller: controller.dob,
                      onTap: () => controller.selectDate(context, isDob: true),
                      decoration: const InputDecoration(hintText: "dd/mm/yyyy"),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      margin: const EdgeInsets.symmetric(vertical: 16),
                      width: double.infinity,
                      child: Card(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16)),
                        elevation: 1,
                        color: Colors.grey.shade200,
                        child: Column(
                          children: [
                            const SizedBox(height: 16),
                            const Text(
                              "Any other Special Anniversary",
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontSize: 15,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8),
                              child: TextFormField(
                                controller: controller.specialAnniversary,
                                onTap: () {
                                  controller.selectDate(context);
                                },
                                readOnly: true,
                                decoration: const InputDecoration(
                                  labelText: "dd/mm/yyyy",
                                  floatingLabelBehavior:
                                      FloatingLabelBehavior.never,
                                  alignLabelWithHint: true,
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 40)
                  ],
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

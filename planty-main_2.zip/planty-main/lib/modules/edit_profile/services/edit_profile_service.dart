import 'package:planty_homes/controllers/user_controller.dart';
import 'package:planty_homes/data/constants/export.dart';
import 'package:planty_homes/data/utils/logger.dart';
import 'package:planty_homes/data/utils/server_utils.dart';

import '../../../data/models/user_model.dart';

class ProfileService extends NewServer {
  Future<Result> updateProfile(User user) async {
    logger.i(user.uid);
    var sendBody = {
      "name": user.name,
      "phone": user.phone,
      "email": user.email,
      "birthday": user.dob,
    };
    sendBody.addIf(
      user.specialAnniversary?.isNotEmpty == true,
      "special",
      user.specialAnniversary,
    );
    final res = await handlePostRequest("/api/updateUser", sendBody);
    logger.e('getting /api/updateUser');
    logger.i(res.data);
    return res;
  }

  Future<Result<User?>> getUser(String id) async {
    final res = await handlePostRequest("/api/getUser", {
      "id": id,
    });
    logger.i(res);

    if (res.isPass) {
      logger.i(res.data);
      final user = User.fromJson(res.data);
      final ctrl = Get.find<UserController>();
      ctrl.setUser(user);
      return Result.pass(
        "Fetched Profile",
      );
    } else {
      return Result.fail(res.msg);
    }
  }

  Future<Result> updateProfilePic(String image) async {
    final res = await handlePostRequest(
      ServerRoute.updateProfile,
      {"image": image},
    );
    return res;
  }
}

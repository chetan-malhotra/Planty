import 'package:get/get.dart';
import 'package:planty_homes/modules/edit_profile/services/edit_profile_service.dart';

import '../controllers/edit_profile_controller.dart';

class EditProfileBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(ProfileService());
    Get.lazyPut<EditProfileController>(
      () => EditProfileController(),
    );

  }
}

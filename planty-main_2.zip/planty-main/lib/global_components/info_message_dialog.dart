import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:planty_homes/data/constants/theme.dart';
import 'package:planty_homes/global_components/primary_button.dart';

class InfoMessageDialog extends GetView {
  const InfoMessageDialog(this.isSuccess, this.message, {super.key});
  final bool isSuccess;
  final String message;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: isSuccess ? Colors.green : Colors.red.shade300,
      elevation: 0,
      titleTextStyle: TextStyles.heading1.copyWith(color: Colors.white),
      contentTextStyle: TextStyles.body1.copyWith(
        color: Colors.white,
      ),
      title: Text(isSuccess ? "Success" : "Failed"),
      content: SingleChildScrollView(child: Text(message)),
      actions: [
        PrimaryButton(
          "OK",
          onTap: () => Get.back(),
          color: Colors.black.withOpacity(.6),
        ),
      ],
    );
  }
}

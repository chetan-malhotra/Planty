import 'dart:convert';
import 'package:flutter/material.dart';

class Base64ImageWidget extends StatelessWidget {
  final String base64Image;

  const Base64ImageWidget({super.key, required this.base64Image});

  @override
  Widget build(BuildContext context) {
    final imageBytes = base64Decode(base64Image);
    return Image.memory(imageBytes);
  }
}

import 'package:material_symbols_icons/symbols.dart';
import 'package:planty_homes/data/constants/export.dart';
import 'package:planty_homes/modules/home/controllers/bookmarks_controller.dart';

import '../data/models/nursery_model.dart';
import '../data/models/plants_model.dart';

class BookmarkButton extends GetView<BookmarksController> {
  const BookmarkButton(
    this.id,
    this.isPlant, {
    super.key,
    this.plant,
    this.nursery,
  });

  final String id;
  final bool isPlant;
  final Nursery? nursery;
  final Plant? plant;

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      var isBookmarked = false;
      if (isPlant) {
        isBookmarked = controller.isPlantBookmark(id);
      } else {
        isBookmarked = controller.isNurseryBookmark(id);
      }
      return IconButton(
        onPressed: () {
          if (!isBookmarked) {
            if (isPlant) {
              if (plant != null) controller.plants.add(plant!);
            } else {
              if (nursery != null) controller.nurseries.add(nursery!);
            }
          } else {
            if(isPlant){
              controller.plants.removeWhere((element) => element.id == id);
            } else {
              controller.nurseries.removeWhere((element) => element.id == id);
            }
          }
          isBookmarked = !isBookmarked;
          controller.update();
        },
        icon: Icon(
          Symbols.bookmark,
          fill: isBookmarked ? 1 : 0,
        ),
      );
    });
  }
}

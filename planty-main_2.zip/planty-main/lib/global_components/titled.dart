import 'package:flutter/material.dart';

import '../data/constants/theme.dart';

class Titled extends StatelessWidget {
  const Titled(
    this.title, {
    super.key,
    this.margin = const EdgeInsets.all(18),
  });

  final String title;
  final EdgeInsets margin;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin,
      child: Text(
        title,
        style: TextStyles.heading1,
      ),
    );
  }
}

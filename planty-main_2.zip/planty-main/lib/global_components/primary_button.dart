import 'package:flutter/material.dart';

import '../data/constants/theme.dart';

class PrimaryButton extends StatelessWidget {
  const PrimaryButton(
    this.text, {
    super.key,
    required this.onTap,
    this.childOverride,
    this.margin = const EdgeInsets.all(16),
    this.padding = const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
    this.color = Colors.green,
    this.textStyle = TextStyles.heading3,
    this.height,
    this.width,
  });

  final Function()? onTap;
  final Widget? childOverride;
  final String text;
  final TextStyle textStyle;
  final EdgeInsets margin;
  final EdgeInsets padding;
  final Color color;
  final double? width;
  final double? height;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      padding: margin,
      child: FilledButton(
        onPressed: onTap,
        style: ButtonStyle(
          backgroundColor: MaterialStatePropertyAll(color),
          shape: MaterialStatePropertyAll(RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          )),
          padding: MaterialStatePropertyAll(padding),
        ),
        child: childOverride ??
            Text(
              text,
              style: textStyle,
            ),
      ),
    );
  }
}

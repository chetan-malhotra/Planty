
import 'package:flutter/material.dart';

class NumberInput extends StatelessWidget {
  const NumberInput(
    this.value, {
    super.key,
    required this.change,
    this.width,
    this.height,
  });

  final double? width;
  final double? height;
  final int value;
  final void Function(int) change;

  final border = const BorderSide(
    color: Colors.grey,
  );
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _button(true),
          Expanded(
            flex: 2,
            child: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 8),
              decoration: BoxDecoration(
                border: Border(
                  top: border,
                  bottom: border,
                ),
              ),
              child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Text(value.toString())),
            ),
          ),
          _button(false),
        ],
      ),
    );
  }

  Widget _button(bool isLeft) {
    return Expanded(
      child: IconButton(
        onPressed: () {
          change(isLeft ? value - 1 : value + 1);
        },
        icon: FittedBox(child: Icon(isLeft ? Icons.remove : Icons.add)),
        style: ButtonStyle(
          padding: const MaterialStatePropertyAll(EdgeInsets.all(4)),
          shape: MaterialStatePropertyAll(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.horizontal(
                left: isLeft ? const Radius.circular(8) : Radius.zero,
                right: isLeft ? Radius.zero : const Radius.circular(8),
              ),
              side: border,
            ),
          ),
        ),
      ),
    );
  }
}

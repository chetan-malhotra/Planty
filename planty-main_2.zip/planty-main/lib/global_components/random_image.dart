import 'dart:math';

import 'package:flutter/material.dart';

class RandomImageWidget extends StatelessWidget {
  final List<String> imageList = [
    "assets/temp/1.jpg",
    "assets/temp/2.jpg",
    "assets/temp/3.jpg",
    "assets/temp/4.jpg",
    "assets/temp/5.jpg",
    "assets/temp/6.jpg",
    "assets/temp/7.png",
    "assets/temp/8.jpg",
  ];

  RandomImageWidget({super.key, this.fit});

  final BoxFit? fit;

  @override
  Widget build(BuildContext context) {
    final Random random = Random();
    final int randomIndex = random.nextInt(imageList.length);
    final String imagePath = imageList[randomIndex];

    return Image.asset(imagePath, fit: fit ?? BoxFit.cover,);
  }
}

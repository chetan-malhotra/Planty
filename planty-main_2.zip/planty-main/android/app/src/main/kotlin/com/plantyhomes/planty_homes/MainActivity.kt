package com.plantyhomes.planty_homes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
